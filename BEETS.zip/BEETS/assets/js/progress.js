let weightData = {
    labels: [],
    weights: []
};

let bloodSugarData = {
    labels: [],
    levels: []
};

let currentChart = 'weight';
let progressChart;

// Initialize with data from PHP
function initializeData(data) {
    weightData = data.weightData;
    bloodSugarData = data.bloodSugarData;
}

function initializeChart() {
    const ctx = document.getElementById('progressChart').getContext('2d');
    progressChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: weightData.labels,
            datasets: [{
                label: 'Weight (kg)',
                data: weightData.weights,
                borderColor: '#ac4800',
                backgroundColor: 'rgba(172, 72, 0, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: false
                }
            }
        }
    });
}

function switchChart(type) {
    currentChart = type;
    const weightTab = document.getElementById('weightTab');
    const bloodSugarTab = document.getElementById('bloodSugarTab');

    if (type === 'weight') {
        weightTab.classList.add('active');
        bloodSugarTab.classList.remove('active');
        updateChart(weightData.labels, weightData.weights, 'Weight (kg)');
    } else {
        bloodSugarTab.classList.add('active');
        weightTab.classList.remove('active');
        updateChart(bloodSugarData.labels, bloodSugarData.levels, 'Blood Sugar (mg/dL)');
    }
}

function updateChart(labels, data, label) {
    progressChart.data.labels = labels;
    progressChart.data.datasets[0].label = label;
    progressChart.data.datasets[0].data = data;
    progressChart.update();
}

// Form submission handler
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('progressForm');
    
    form.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent normal form submission
        
        const formData = new FormData(form);
        
        fetch('../save_progress.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update the charts with new data
                const date = data.data.log_date;
                const weight = parseFloat(data.data.weight);
                const bloodSugar = parseInt(data.data.blood_sugar_level);

                if (!isNaN(weight)) {
                    weightData.labels.push(date);
                    weightData.weights.push(weight);
                }

                if (!isNaN(bloodSugar)) {
                    bloodSugarData.labels.push(date);
                    bloodSugarData.levels.push(bloodSugar);
                }

                // Update the current chart
                switchChart(currentChart);
                
                // Show success message
                showMessage('success', 'Progress saved successfully!');
                
                // Reset form
                form.reset();
            } else {
                showMessage('error', data.message || 'Error saving progress');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showMessage('error', 'An error occurred while saving progress');
        });
    });
});

function showMessage(type, text) {
    // Create message element
    const messageDiv = document.createElement('div');
    messageDiv.className = `alert alert-${type} mb-4`;
    messageDiv.textContent = text;
    
    // Insert message before form
    const form = document.getElementById('progressForm');
    form.parentNode.insertBefore(messageDiv, form);
    
    // Remove message after 3 seconds
    setTimeout(() => {
        messageDiv.remove();
    }, 3000);
}

// Initialize on page load
if (typeof initialData !== 'undefined') {
    initializeData(initialData);
}
document.addEventListener('DOMContentLoaded', initializeChart);