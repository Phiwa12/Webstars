<?php
require_once '../db/config.php';
require_once '../functions/planning_function.php';
require_once '../functions/progress_function.php';


// Initialize session and check for user data
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercise Planning</title>
    <link rel="stylesheet" href="../assets/css/exercisePlanning.css">
</head>
<body>
    <div class="exercise-planning-container">
        <div class="top-bar">
        <li>
                <a href="../../actions/logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </li>
            <a href="../view/services.php" class="back-button">← Back to Services</a>
            <div></div> <!-- Empty div for flex spacing -->
        </div>
        <div class="header">Exercise Planning</div>
        <p class="description">
            Access personalized workout routines and maintain an exercise log to track your physical activity and fitness goals.
        </p>

        <!-- User Input Section -->
        <form action="../save_user_details.php" method="POST" id="userDetailsForm">
            <div class="user-details">
                <label for="height">Height (cm):</label>
                <input type="number" id="height" name="height" value="<?php echo isset($_SESSION['user_details']['height']) ? $_SESSION['user_details']['height'] : ''; ?>">

                <label for="age">Age:</label>
                <input type="number" id="age" name="age" value="<?php echo isset($_SESSION['user_details']['age']) ? $_SESSION['user_details']['age'] : ''; ?>">

                <label for="weight">Current Weight (kg):</label>
                <input type="number" id="weight" name="weight" value="<?php echo isset($_SESSION['user_details']['weight']) ? $_SESSION['user_details']['weight'] : ''; ?>">

                <label for="goal">Goal:</label>
                <select id="goal" name="goal">
                    <?php
                    $goals = ['weight_loss' => 'Weight Loss', 'muscle_gain' => 'Muscle Gain', 'maintain_fitness' => 'Maintain Fitness'];
                    foreach ($goals as $value => $label) {
                        $selected = (isset($_SESSION['user_details']['goal']) && $_SESSION['user_details']['goal'] == $value) ? 'selected' : '';
                        echo "<option value='$value' $selected>$label</option>";
                    }
                    ?>
                </select>

                <label for="diabetes">Type of Diabetes:</label>
                <select id="diabetes" name="diabetes">
                    <?php
                    $diabetesTypes = ['none' => 'None', 'type1' => 'Type 1', 'type2' => 'Type 2', 'gestational' => 'Gestational'];
                    foreach ($diabetesTypes as $value => $label) {
                        $selected = (isset($_SESSION['user_details']['diabetes']) && $_SESSION['user_details']['diabetes'] == $value) ? 'selected' : '';
                        echo "<option value='$value' $selected>$label</option>";
                    }
                    ?>
                </select>

                <label for="limitations">Physical Limitations (if any):</label>
                <input type="text" id="limitations" name="limitations" value="<?php echo isset($_SESSION['user_details']['limitations']) ? $_SESSION['user_details']['limitations'] : ''; ?>">
                
                <button type="submit" class="save-details-btn">Save Details</button>
            </div>
        </form>

        <div class="exercise-media">
            <?php '../includes/exercise_media.php'; ?>
        </div>

        <!-- Workout Routine and Exercise Log Section -->
        <div class="routine-log-section">
            <button class="generate-routine-btn" onclick="generateWorkout()">Generate New Workout Routine</button>

            <!-- Workout Routine -->
            <div class="exercise-routine">
                <h3>Today's Workout Routine</h3>
                <ul id="routineList">
                    <?php echo getDefaultRoutine(); ?>
                </ul>
            </div>

            <!-- Exercise Log -->
            <div class="exercise-log">
                <h3>Your Exercise Log</h3>
                <ul id="logList">
                    <?php echo getExerciseLogs(); ?>
                </ul>
                <button class="add-log-btn" onclick="addLogEntry()">Add Log Entry</button>
            </div>
        </div>
    </div>

    <script src="../assets/js/exercisePlanning.js"></script>
</body>
</html>