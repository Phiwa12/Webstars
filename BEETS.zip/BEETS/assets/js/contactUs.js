// Navigation scroll behavior
document.addEventListener('DOMContentLoaded', () => {
    // Smooth scroll for navigation links
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        link.addEventListener('click', smoothScroll);
    });

    // Form validation and enhancement
    setupFormValidation();

    // Add scroll-based nav styling
    setupScrollBehavior();
});

// Smooth scroll function
function smoothScroll(e) {
    e.preventDefault();
    const targetId = this.getAttribute('href');
    const targetSection = document.querySelector(targetId);
    if (targetSection) {
        targetSection.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Form validation setup
function setupFormValidation() {
    const form = document.getElementById('contactForm');
    const inputs = form.querySelectorAll('input, textarea');

    inputs.forEach(input => {
        // Real-time validation
        input.addEventListener('input', () => {
            validateInput(input);
        });

        // Blur validation
        input.addEventListener('blur', () => {
            validateInput(input);
        });
    });
}

// Input validation
function validateInput(input) {
    const errorClass = 'input-error';
    const successClass = 'input-success';

    // Remove existing status classes
    input.classList.remove(errorClass, successClass);

    if (input.validity.valid) {
        input.classList.add(successClass);
    } else {
        input.classList.add(errorClass);
    }

    // Show custom validation message
    updateValidationMessage(input);
}

// Update validation message
function updateValidationMessage(input) {
    let messageElement = input.nextElementSibling;
    if (!messageElement || !messageElement.classList.contains('validation-message')) {
        messageElement = document.createElement('div');
        messageElement.classList.add('validation-message');
        input.parentNode.insertBefore(messageElement, input.nextSibling);
    }

    if (!input.validity.valid) {
        let message = '';
        if (input.validity.valueMissing) {
            message = `${input.name.charAt(0).toUpperCase() + input.name.slice(1)} is required`;
        } else if (input.validity.typeMismatch) {
            message = `Please enter a valid ${input.name}`;
        }
        messageElement.textContent = message;
        messageElement.style.display = 'block';
    } else {
        messageElement.style.display = 'none';
    }
}

// Scroll behavior setup
function setupScrollBehavior() {
    const nav = document.querySelector('nav');
    let lastScroll = 0;

    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;

        // Add shadow to nav when scrolling down
        if (currentScroll > 50) {
            nav.classList.add('nav-shadow');
        } else {
            nav.classList.remove('nav-shadow');
        }

        // Hide/show nav based on scroll direction
        if (currentScroll > lastScroll && currentScroll > 100) {
            nav.style.transform = 'translateY(-100%)';
        } else {
            nav.style.transform = 'translateY(0)';
        }

        lastScroll = currentScroll;
    });
}

// Loading state management
function setLoadingState(isLoading) {
    const submitButton = document.querySelector('.contact-form button[type="submit"]');
    if (isLoading) {
        submitButton.classList.add('loading');
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    } else {
        submitButton.classList.remove('loading');
        submitButton.disabled = false;
        submitButton.innerHTML = 'Submit';
    }
}

// Show success/error messages
function showMessage(type, message) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', `message-${type}`);
    messageElement.textContent = message;

    const form = document.getElementById('contactForm');
    form.parentNode.insertBefore(messageElement, form.nextSibling);

    // Remove message after 5 seconds
    setTimeout(() => {
        messageElement.remove();
    }, 5000);
}

// Add CSS styles for new elements
const style = document.createElement('style');
style.textContent = `
    .nav-shadow {
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        transition: box-shadow 0.3s ease;
    }

    .validation-message {
        color: #dc3545;
        font-size: 0.875rem;
        margin-top: 0.25rem;
    }

    .input-error {
        border-color: #dc3545 !important;
    }

    .input-success {
        border-color: #28a745 !important;
    }

    .message {
        padding: 1rem;
        margin: 1rem 0;
        border-radius: 5px;
        text-align: center;
    }

    .message-success {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }

    .message-error {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }

    nav {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        position: fixed;
        top: 0;
        width: 100%;
        z-index: 1000;
    }

    body {
        padding-top: 60px;
    }
`;

document.head.appendChild(style);