// Exercise Log Management
function addLogEntry() {
    const formData = new FormData();
    formData.append('action', 'add_log');
    formData.append('timestamp', new Date().toISOString());

    fetch('includes/log_handler.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const logList = document.getElementById('logList');
            const newEntry = document.createElement('li');
            newEntry.textContent = data.message;
            logList.appendChild(newEntry);
        } else {
            alert('Error adding log entry: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error adding log entry');
    });
}

// Workout Routine Generation
function generateWorkout() {
    const formData = new FormData();
    formData.append('action', 'generate_routine');

    fetch('includes/routine_handler.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const routineList = document.getElementById('routineList');
            routineList.innerHTML = data.routine;
        } else {
            alert('Error generating routine: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error generating workout routine');
    });
}

// Form Validation
document.getElementById('userDetailsForm').addEventListener('submit', function(e) {
    const height = document.getElementById('height').value;
    const age = document.getElementById('age').value;
    const weight = document.getElementById('weight').value;

    if (height <= 0 || age <= 0 || weight <= 0) {
        e.preventDefault();
        alert('Please enter valid values for height, age, and weight');
        return;
    }
});

// Initialize tooltips or other UI elements
document.addEventListener('DOMContentLoaded', function() {
    // Add any initialization code here
});