// Initialize all dashboard components
document.addEventListener('DOMContentLoaded', function() {
    initializeChart();
    setupNotifications();
    setupReminderActions();
    setupBloodSugarLogging();
    setupMedicationTracking();
    initializeAutoRefresh();
});

// Chart Configuration and Setup
function initializeChart() {
    const ctx = document.getElementById('weeklyChart').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Blood Sugar Levels',
                data: [],
                borderColor: '#ac4800',
                backgroundColor: 'rgba(172, 72, 0, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    grid: {
                        display: true,
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });

    // Load initial chart data
    fetchChartData(chart);
}

// Fetch and update chart data
function fetchChartData(chart) {
    fetch('../actions/user_dash_actions.php', {
        method: 'POST',
        body: JSON.stringify({
            action: 'get_chart_data'
        }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateChart(chart, data.chartData);
        }
    })
    .catch(error => console.error('Error fetching chart data:', error));
}

function updateChart(chart, data) {
    chart.data.labels = data.labels;
    chart.data.datasets[0].data = data.values;
    chart.update();
}

// Notification System
function setupNotifications() {
    const notificationBtn = document.getElementById('notificationBtn');
    let notificationPanel = null;

    notificationBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        if (notificationPanel) {
            notificationPanel.remove();
            notificationPanel = null;
        } else {
            fetchAndShowNotifications();
        }
    });

    document.addEventListener('click', function(e) {
        if (notificationPanel && !notificationPanel.contains(e.target)) {
            notificationPanel.remove();
            notificationPanel = null;
        }
    });
}

function fetchAndShowNotifications() {
    fetch('../actions/user_dash_actions.php', {
        method: 'POST',
        body: JSON.stringify({
            action: 'get_notifications'
        }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotificationPanel(data.notifications);
        }
    })
    .catch(error => console.error('Error fetching notifications:', error));
}

function showNotificationPanel(notifications) {
    const panel = document.createElement('div');
    panel.className = 'notification-panel';

    notifications.forEach(notification => {
        const notificationItem = createNotificationItem(notification);
        panel.appendChild(notificationItem);
    });

    const btn = document.getElementById('notificationBtn');
    const rect = btn.getBoundingClientRect();
    
    panel.style.top = `${rect.bottom + 10}px`;
    panel.style.right = '20px';
    
    document.body.appendChild(panel);
    return panel;
}

function createNotificationItem(notification) {
    const item = document.createElement('div');
    item.className = 'notification-item';
    item.innerHTML = `
        <div class="notification-content">
            <h4 class="notification-title">${notification.title}</h4>
            <p class="notification-message">${notification.message}</p>
            <span class="notification-time">${notification.time}</span>
        </div>
    `;
    
    item.addEventListener('click', () => markNotificationRead(notification.id));
    return item;
}

// Reminder Actions
function setupReminderActions() {
    const reminderButtons = document.querySelectorAll('.reminder-action');
    
    reminderButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const reminderId = this.closest('.reminder-item').dataset.id;
            completeReminder(reminderId);
        });
    });
}

function completeReminder(reminderId) {
    fetch('../actions/user_dash_actions.php', {
        method: 'POST',
        body: JSON.stringify({
            action: 'complete_reminder',
            reminder_id: reminderId
        }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const reminderItem = document.querySelector(`.reminder-item[data-id="${reminderId}"]`);
            reminderItem.classList.add('completed');
            setTimeout(() => reminderItem.remove(), 500);
            showSuccessMessage('Reminder completed successfully');
        } else {
            showErrorMessage(data.message);
        }
    })
    .catch(error => {
        console.error('Error completing reminder:', error);
        showErrorMessage('Error completing reminder');
    });
}

// Blood Sugar Logging
function setupBloodSugarLogging() {
    const logButton = document.getElementById('logBloodSugar');
    if (logButton) {
        logButton.addEventListener('click', showBloodSugarModal);
    }
}

function showBloodSugarModal() {
    // Modal implementation
}

// Medication Tracking
function setupMedicationTracking() {
    const medicationButtons = document.querySelectorAll('.medication-action');
    
    medicationButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const scheduleId = this.dataset.scheduleId;
            const action = this.dataset.action;
            updateMedicationStatus(scheduleId, action);
        });
    });
}

// Auto Refresh
function initializeAutoRefresh() {
    setInterval(() => {
        refreshDashboardData();
    }, 300000); // Refresh every 5 minutes
}

function refreshDashboardData() {
    // Refresh implementation
}

// Utility Functions
function showSuccessMessage(message) {
    showMessage(message, 'success');
}

function showErrorMessage(message) {
    showMessage(message, 'error');
}

function showMessage(message, type) {
    const messageContainer = document.createElement('div');
    messageContainer.className = `message-container ${type}`;
    messageContainer.textContent = message;
    
    document.body.appendChild(messageContainer);
    
    setTimeout(() => {
        messageContainer.remove();
    }, 3000);
}

// Helper Functions
function formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
    });
}

function formatTime(time) {
    return new Date(time).toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
    });
}