class FormHandler {
    constructor(formId) {
      this.form = document.getElementById(formId);
      this.setupEventListeners();
    }
  
    setupEventListeners() {
      this.form.addEventListener('submit', this.handleSubmit.bind(this));
    }
  
    async handleSubmit(event) {
      event.preventDefault();
      
      const formData = new FormData(this.form);
      const data = {
        name: formData.get('name'),
        email: formData.get('email'),
        message: formData.get('message')
      };
  
      try {
        // Send to backend API
        const response = await fetch('/api/contact', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(data)
        });
  
        if (response.ok) {
          alert('Thank you for reaching out! We will get back to you soon.');
          this.form.reset();
        } else {
          throw new Error('Failed to submit form');
        }
      } catch (error) {
        console.error('Error submitting form:', error);
        alert('There was an error submitting your message. Please try again later.');
      }
    }
  }
  
  // Initialize form handler
  new FormHandler('contactForm');