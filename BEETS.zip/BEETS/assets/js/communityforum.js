// Chatbox functionality
        document.getElementById('chat-icon').addEventListener('click', function() {
            const chatbox = document.getElementById('chatbox');
            chatbox.style.display = chatbox.style.display === 'none' ? 'block' : 'none';
        });

        function sendMessage() {
            const input = document.getElementById('user-input');
            const message = input.value.trim();
            
            if (message === '') return;

            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=send_chat&message=${encodeURIComponent(message)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const chatWindow = document.getElementById('chat-window');
                    chatWindow.innerHTML += `<p><strong>You:</strong> ${message}</p>`;
                    input.value = '';
                    chatWindow.scrollTop = chatWindow.scrollHeight;
                }
            });
        }

        function postStory(event) {
            event.preventDefault();
            const storyInput = document.getElementById('story-input');
            const story = storyInput.value.trim();
            
            if (story === '') {
                alert('Please enter a story before posting.');
                return false;
            }
        
            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=post_story&story=${encodeURIComponent(story)}`
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Response:', data); // Add debugging
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'Failed to post story');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to post story. Please try again. Error: ' + error.message);
            });
        
            return false;
        }
        // Like functionality
        function likePost(postId) {
            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=like_post&post_id=${postId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const likeCount = document.querySelector(`[data-post-id="${postId}"] .likes-count`);
                    const currentLikes = parseInt(likeCount.textContent);
                    likeCount.textContent = data.message.includes('unliked') ? currentLikes - 1 : currentLikes + 1;
                }
            });
        }

        // Comment functionality
        function postComment(button, postId) {
            const commentTextArea = button.previousElementSibling;
            const comment = commentTextArea.value.trim();
            
            if (comment === '') {
                alert('Please enter a comment before posting.');
                return;
            }

            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=post_comment&comment=${encodeURIComponent(comment)}&post_id=${postId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload(); // Reload to show new comment
                } else {
                    alert(data.message);
                }
            });
        }

        function deleteStory(storyId) {
            if (confirm("Are you sure you want to delete this story?")) {
                fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=delete_story&story_id=${encodeURIComponent(storyId)}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Remove the story element from the DOM
                        const storyElement = document.querySelector(`.story[data-story-id="${storyId}"]`);
                        storyElement.remove();
                    } else {
                        alert('Failed to delete the story.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Failed to delete the story. Please try again.');
                });
            }
        }

        // Enter key functionality for chat
        document.getElementById('user-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });