// Global variables to store current user context
let currentUserId = null;

// Modal Utility Functions
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
}

// User View Functions
function viewUserDetails(userId) {
    fetch('../actions/admin_actions.php?action=get_user_details&user_id=' + userId)
        .then(response => response.json())
        .then(user => {
            // Populate view modal fields
            document.getElementById('viewUserName').textContent = `${user.fname} ${user.lname}`;
            document.getElementById('viewUserEmail').textContent = user.email;
            document.getElementById('viewUserRole').textContent = getUserRoleName(user.role);
            document.getElementById('viewUserJoinDate').textContent = formatDate(user.created_at);
            
            // Set current user ID for potential edit
            currentUserId = userId;
            
            // Open view modal
            openModal('viewUserModal');
        })
        .catch(error => {
            console.error('Error fetching user details:', error);
            showToast('Error retrieving user details', 'error');
        });
}

function getUserRoleName(roleId) {
    switch(parseInt(roleId)) {
        case 1: return 'Super Admin';
        case 2: return 'Admin';
        case 3: return 'User';
        default: return 'Unknown Role';
    }
}

// User Edit Functions
function editUser(userId) {
    fetch('../actions/admin_actions.php?action=get_user_details&user_id=' + userId)
        .then(response => response.json())
        .then(user => {
            // Populate edit modal fields
            document.getElementById('editUserId').value = user.user_id;
            document.getElementById('editUserName').value = `${user.fname} ${user.lname}`;
            document.getElementById('editUserEmail').value = user.email;
            document.getElementById('editUserRole').value = user.role;
            
            // Close view modal if open
            closeModal('viewUserModal');
            
            // Open edit modal
            openModal('editUserModal');
        })
        .catch(error => {
            console.error('Error fetching user details:', error);
            showToast('Error retrieving user details', 'error');
        });
}

function handleEditUser(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    
    fetch('../actions/admin_actions.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showToast('User updated successfully', 'success');
            closeModal('editUserModal');
            refreshUsersList();
        } else {
            showToast(result.message || 'Error updating user', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('Error updating user', 'error');
    });
}

// User Delete Functions
function confirmDeleteUser(userId) {
    fetch('../actions/admin_actions.php?action=get_user_details&user_id=' + userId)
        .then(response => response.json())
        .then(user => {
            // Populate delete modal details
            document.getElementById('deleteUserName').textContent = `${user.fname} ${user.lname}`;
            document.getElementById('deleteUserEmail').textContent = user.email;
            
            // Set current user ID
            currentUserId = userId;
            
            // Open delete modal
            openModal('deleteUserModal');
        })
        .catch(error => {
            console.error('Error fetching user details:', error);
            showToast('Error retrieving user details', 'error');
        });
}

function handleDeleteUser() {
    if (!currentUserId) {
        showToast('No user selected for deletion', 'error');
        return;
    }

    fetch('../actions/admin_actions.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'delete_user',
            user_id: currentUserId
        })
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showToast('User deleted successfully', 'success');
            closeModal('deleteUserModal');
            refreshUsersList();
        } else {
            showToast(result.message || 'Error deleting user', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('Error deleting user', 'error');
    });
}

// Add User Functions
function handleAddUser(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    
    // Additional client-side validation
    const password = formData.get('password');
    const confirmPassword = formData.get('confirm_password');
    
    if (password !== confirmPassword) {
        showToast('Passwords do not match', 'error');
        return;
    }
    
    fetch('../actions/admin_actions.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showToast('User added successfully', 'success');
            closeModal('addUserModal');
            refreshUsersList();
            event.target.reset(); // Clear form
        } else {
            showToast(result.message || 'Error adding user', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('Error adding user', 'error');
    });
}

// Toast Notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.classList.add('toast', `toast-${type}`);
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Utility function to format dates
function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Add event listener for filter form
    const filterForm = document.getElementById('filterForm');
    if (filterForm) {
        filterForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const formData = new FormData(event.target);
            const queryParams = new URLSearchParams(formData).toString();
            window.location.href = 'user_management.php?' + queryParams;
        });
    }

    // Add event listener for edit form
    const editUserForm = document.getElementById('editUserForm');
    if (editUserForm) {
        editUserForm.addEventListener('submit', handleEditUser);
    }

    // Add event listener for delete button
    const deleteUserButton = document.getElementById('deleteUserButton');
    if (deleteUserButton) {
        deleteUserButton.addEventListener('click', handleDeleteUser);
    }

    // Add event listener for add user form
    const addUserForm = document.getElementById('addUserForm');
    if (addUserForm) {
        addUserForm.addEventListener('submit', handleAddUser);
    }
});