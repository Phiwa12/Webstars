// Initialize charts when document is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeCharts();
    setupEventListeners();
    startAutoRefresh();
});

let userGrowthChart;
let activityChart;

// Chart initialization
function initializeCharts() {
    // User Growth Chart
    const userCtx = document.getElementById('userGrowthChart').getContext('2d');
    userGrowthChart = new Chart(userCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'New Users',
                borderColor: '#ac4800',
                backgroundColor: 'rgba(172, 72, 0, 0.1)',
                data: [],
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        display: false
                    }
                }
            }
        }
    });

    // Activity Chart
    const activityCtx = document.getElementById('activityChart').getContext('2d');
    activityChart = new Chart(activityCtx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'Forum Posts',
                backgroundColor: '#ac4800',
                data: []
            }, {
                label: 'Comments',
                backgroundColor: '#ff6b00',
                data: []
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        display: false
                    }
                }
            }
        }
    });

    // Load initial data
    updateChart('users', 'week');
    updateChart('activity', 'week');
}

// Chart data updates
async function updateChart(chartType, timeframe) {
    try {
        // Update active button state
        updateActiveButton(chartType, timeframe);

        const response = await fetch('../actions/admin_actions.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'get_chart_data',
                chart_type: chartType,
                timeframe: timeframe
            })
        });

        const data = await response.json();
        
        if (data.success) {
            if (chartType === 'users') {
                updateUserGrowthChart(data.data);
            } else {
                updateActivityChart(data.data);
            }
        } else {
            showError('Error loading chart data');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Error updating chart');
    }
}

function updateUserGrowthChart(data) {
    userGrowthChart.data.labels = data.labels;
    userGrowthChart.data.datasets[0].data = data.values;
    userGrowthChart.update();
}

function updateActivityChart(data) {
    activityChart.data.labels = data.labels;
    activityChart.data.datasets[0].data = data.posts;
    activityChart.data.datasets[1].data = data.comments;
    activityChart.update();
}

// Event Listeners Setup
function setupEventListeners() {
    // Chart timeframe buttons
    document.querySelectorAll('.chart-btn').forEach(button => {
        button.addEventListener('click', function() {
            const chartType = this.closest('.chart-card').id.replace('Chart', '').toLowerCase();
            const timeframe = this.dataset.timeframe;
            updateChart(chartType, timeframe);
        });
    });

    // Refresh buttons
    document.querySelectorAll('.refresh-btn').forEach(button => {
        button.addEventListener('click', function() {
            const section = this.dataset.section;
            refreshSection(section);
        });
    });
}

// Auto refresh functionality
function startAutoRefresh() {
    // Refresh system alerts every minute
    setInterval(refreshSystemAlerts, 60000);
    
    // Refresh activity log every 5 minutes
    setInterval(() => refreshSection('activity'), 300000);
}

async function refreshSystemAlerts() {
    try {
        const response = await fetch('../actions/admin_actions.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'get_system_alerts'
            })
        });

        const data = await response.json();
        
        if (data.success) {
            updateSystemAlerts(data.alerts);
        }
    } catch (error) {
        console.error('Error refreshing alerts:', error);
    }
}

async function refreshSection(section) {
    const button = document.querySelector(`[data-section="${section}"]`);
    if (button) {
        button.classList.add('loading');
    }

    try {
        const response = await fetch('../actions/admin_actions.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: `refresh_${section}`
            })
        });

        const data = await response.json();
        
        if (data.success) {
            updateSectionContent(section, data.content);
        }
    } catch (error) {
        console.error(`Error refreshing ${section}:`, error);
    } finally {
        if (button) {
            button.classList.remove('loading');
        }
    }
}

// UI Updates
function updateSystemAlerts(alerts) {
    const container = document.getElementById('systemAlerts');
    container.innerHTML = alerts.map(alert => `
        <div class="alert-item alert-${alert.level}">
            <i class="${getAlertIcon(alert.level)}"></i>
            <div class="alert-content">
                <p class="alert-text">${escapeHtml(alert.message)}</p>
                <span class="alert-time">${formatTimeAgo(alert.created_at)}</span>
            </div>
        </div>
    `).join('');
}

function updateSectionContent(section, content) {
    const container = document.getElementById(`${section}Content`);
    if (container) {
        container.innerHTML = content;
    }
}

// Utility Functions
function formatTimeAgo(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);

    if (seconds < 60) {
        return 'just now';
    }

    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) {
        return `${minutes}m ago`;
    }

    const hours = Math.floor(minutes / 60);
    if (hours < 24) {
        return `${hours}h ago`;
    }

    const days = Math.floor(hours / 24);
    return `${days}d ago`;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showError(message) {
    // Implement error notification
    console.error(message);
}

function updateActiveButton(chartType, timeframe) {
    const buttons = document.querySelectorAll(`#${chartType}Chart .chart-btn`);
    buttons.forEach(button => {
        button.classList.toggle('active', button.dataset.timeframe === timeframe);
    });
}

function getAlertIcon(level) {
    const icons = {
        error: 'fas fa-exclamation-circle',
        warning: 'fas fa-exclamation-triangle',
        info: 'fas fa-info-circle'
    };
    return icons[level] || icons.info;
}