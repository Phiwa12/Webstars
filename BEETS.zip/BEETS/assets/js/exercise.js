// Initialize components when document is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeFormHandlers();
    setupModalHandlers();
    setupAutoSave();
});

// Form Handlers
function initializeFormHandlers() {
    const userDetailsForm = document.getElementById('userDetailsForm');
    const logForm = document.getElementById('logForm');

    if (userDetailsForm) {
        userDetailsForm.addEventListener('change', handleUserDetailsUpdate);
    }

    if (logForm) {
        logForm.addEventListener('submit', handleLogSubmission);
    }
}

// User Details Update Handler
function handleUserDetailsUpdate(e) {
    const formData = new FormData(e.target.form);
    
    fetch('../actions/user_exercise_actions.php', {
        method: 'POST',
        body: JSON.stringify({
            action: 'update_user_details',
            data: Object.fromEntries(formData)
        }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Profile updated successfully', 'success');
        } else {
            showNotification(data.message || 'Error updating profile', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error updating profile', 'error');
    });
}

// Workout Generation
function generateWorkout() {
    const button = event.target;
    button.disabled = true;
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';

    fetch('../actions/user_exercise_actions.php', {
        method: 'POST',
        body: JSON.stringify({
            action: 'generate_workout'
        }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateWorkoutPlan(data.workout);
            showNotification('New workout generated', 'success');
        } else {
            showNotification(data.message || 'Error generating workout', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error generating workout', 'error');
    })
    .finally(() => {
        button.disabled = false;
        button.innerHTML = 'Generate New Workout';
    });
}

// Update Workout Plan Display
function updateWorkoutPlan(workout) {
    const container = document.getElementById('workoutPlan');
    container.innerHTML = '';

    workout.forEach(section => {
        const sectionElement = document.createElement('div');
        sectionElement.className = 'workout-section bg-white p-4 rounded-lg shadow fade-in';
        
        sectionElement.innerHTML = `
            <h3 class="font-semibold text-ac4800 mb-2">${section.title}</h3>
            <ul class="list-disc list-inside space-y-2">
                ${section.exercises.map(exercise => `
                    <li class="text-gray-700">${exercise}</li>
                `).join('')}
            </ul>
        `;
        
        container.appendChild(sectionElement);
    });
}

// Exercise Log Modal Handlers
function setupModalHandlers() {
    const modal = document.getElementById('logModal');
    const closeButtons = modal.querySelectorAll('button[type="button"]');
    
    closeButtons.forEach(button => {
        button.addEventListener('click', closeLogModal);
    });

    // Close modal when clicking outside
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeLogModal();
        }
    });
}

function addLogEntry() {
    const modal = document.getElementById('logModal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function closeLogModal() {
    const modal = document.getElementById('logModal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

// Handle Log Form Submission
function handleLogSubmission(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const submitButton = e.target.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    
    fetch('../actions/user_exercise_actions.php', {
        method: 'POST',
        body: JSON.stringify({
            action: 'log_exercise',
            data: Object.fromEntries(formData)
        }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateExerciseLog(data.log);
            closeLogModal();
            showNotification('Exercise logged successfully', 'success');
        } else {
            showNotification(data.message || 'Error logging exercise', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error logging exercise', 'error');
    })
    .finally(() => {
        submitButton.disabled = false;
        e.target.reset();
    });
}

// Update Exercise Log Display
function updateExerciseLog(logEntry) {
    const logTable = document.querySelector('#exerciseLog');
    const newRow = document.createElement('tr');
    newRow.className = 'border-t fade-in';
    
    newRow.innerHTML = `
        <td class="p-4">${logEntry.date}</td>
        <td class="p-4">${logEntry.exercise_type}</td>
        <td class="p-4">${logEntry.duration} mins</td>
        <td class="p-4">
            <span class="px-2 py-1 rounded-full text-sm ${getStatusClass(logEntry.status)}">
                ${logEntry.status}
            </span>
        </td>
    `;
    
    logTable.insertBefore(newRow, logTable.firstChild);
}

// Auto-save functionality for user details
function setupAutoSave() {
    let timeout;
    const form = document.getElementById('userDetailsForm');
    
    if (form) {
        form.querySelectorAll('input, select').forEach(input => {
            input.addEventListener('input', () => {
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    handleUserDetailsUpdate({ target: input });
                }, 1000);
            });
        });
    }
}

// Utility Functions
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `fixed bottom-4 right-4 px-6 py-3 rounded-lg shadow-lg ${
        type === 'success' ? 'bg-green-500' : 'bg-red-500'
    } text-white fade-in`;
    
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function getStatusClass(status) {
    const classes = {
        'completed': 'status-completed',
        'planned': 'status-planned',
        'skipped': 'status-skipped'
    };
    return classes[status] || 'status-planned';
}

// Export functions for testing
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        updateWorkoutPlan,
        updateExerciseLog,
        getStatusClass
    };
}