
function calculateCalories(weight, height, age, sex, activityLevel) {
    // Basic Harris-Benedict equation
    let bmr;
    if (sex === 'male') {
      bmr = 88.36 + (13.4 * weight) + (4.8 * height) - (5.7 * age);
    } else {
      bmr = 447.6 + (9.2 * weight) + (3.1 * height) - (4.3 * age);
    }
    
    // Adjust for activity level
    const activityFactors = { low: 1.2, moderate: 1.55, high: 1.9 };
    return Math.round(bmr * activityFactors[activityLevel]);
}

function generatePlan() {
    const age = document.getElementById("age").value;
    const sex = document.getElementById("sex").value;
    const height = document.getElementById("height").value;
    const weight = document.getElementById("weight").value;
    const activity = document.getElementById("activity").value;
    const pregnant = document.getElementById("pregnant").value;
    const preferences = document.getElementById("preferences").value;
    const allergies = document.getElementById("allergies").value;
    const dietaryRestrictions = document.getElementById("dietaryRestrictions").value;

    // Calorie calculation
    const dailyCalories = calculateCalories(weight, height, age, sex, activity);

    // Meal plan text
    let planText = `<h3>Personalized Food Plan</h3>`;
    planText += `<p>Based on your profile:</p>`;
    planText += `<ul>
                  <li>Age: ${age}</li>
                  <li>Sex: ${sex}</li>
                  <li>Height: ${height} cm</li>
                  <li>Weight: ${weight} kg</li>
                  <li>Activity Level: ${activity}</li>
                  <li>Pregnant: ${pregnant === 'yes' ? 'Yes' : 'No'}</li>
                  <li>Calories Needed: ${dailyCalories} kcal/day</li>
                  <li>Dietary Preferences: ${preferences || 'None'}</li>
                  <li>Allergies: ${allergies || 'None'}</li>
                  <li>Dietary Restrictions: ${dietaryRestrictions}</li>
                </ul>`;

    planText += `<p>Suggested Meal Plan: <br> - Aim for balanced portions of lean proteins, healthy fats, and complex carbs.</p>`;
    planText += `<p>Include low glycemic index foods, whole grains, and vegetables. <br> Adjust according to dietary preferences and restrictions.</p>`;

    document.getElementById("mealPlan").innerHTML = planText;
}