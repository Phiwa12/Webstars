// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeDatePickers();
    setupFormValidation();
    setupExportHandlers();
    
    // Delay chart initialization to ensure proper container sizing
    setTimeout(initializeCharts, 100);
});

// Initialize Charts with size constraints
function initializeCharts() {
    try {
        // Create container divs for charts
        const metricsSection = document.querySelector('.metrics');
        
        // User Engagement Chart Container
        const userEngagementContainer = document.createElement('div');
        userEngagementContainer.className = 'chart-wrapper';
        userEngagementContainer.style.height = '300px';
        userEngagementContainer.style.marginTop = '20px';
        const userEngagementCtx = document.createElement('canvas');
        userEngagementCtx.id = 'userEngagementChart';
        userEngagementContainer.appendChild(userEngagementCtx);
        metricsSection.appendChild(userEngagementContainer);

        // Health Progress Chart Container
        const healthProgressContainer = document.createElement('div');
        healthProgressContainer.className = 'chart-wrapper';
        healthProgressContainer.style.height = '300px';
        healthProgressContainer.style.marginTop = '20px';
        const healthProgressCtx = document.createElement('canvas');
        healthProgressCtx.id = 'healthProgressChart';
        healthProgressContainer.appendChild(healthProgressCtx);
        metricsSection.appendChild(healthProgressContainer);

        // Initialize charts with proper sizing
        createUserEngagementChart();
        createHealthProgressChart();

    } catch (error) {
        console.error('Error initializing charts:', error);
        showMessage('Error initializing charts', 'error');
    }
}

function createUserEngagementChart() {
    const ctx = document.getElementById('userEngagementChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: getLast7Days(),
            datasets: [{
                label: 'Daily Active Users',
                data: generateRandomData(7, 50, 100),
                borderColor: '#ac4800',
                backgroundColor: 'rgba(172, 72, 0, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            ...getChartOptions('User Engagement Over Time'),
            maintainAspectRatio: false,
            responsive: true
        }
    });
}

function createHealthProgressChart() {
    const ctx = document.getElementById('healthProgressChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: getLast7Days(),
            datasets: [{
                label: 'Average Blood Sugar',
                data: generateRandomData(7, 80, 120),
                backgroundColor: '#ac4800',
                borderColor: '#8b3700',
                borderWidth: 1
            }]
        },
        options: {
            ...getChartOptions('Health Progress Trends'),
            maintainAspectRatio: false,
            responsive: true
        }
    });
}

// Update metrics with error handling
function updateMetrics() {
    fetch('../actions/get_metrics.php') // Updated path
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                updateMetricsDisplay(data.metrics);
            } else {
                throw new Error(data.message || 'Error updating metrics');
            }
        })
        .catch(error => {
            console.error('Error updating metrics:', error);
            // Don't show error message to user for background updates
        });
}

// Rest of your existing code...