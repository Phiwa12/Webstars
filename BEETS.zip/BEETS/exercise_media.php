<?php
// Array of exercises with their details
$exercises = [
    [
        'image' => 'images/pushups.jpg',
        'description' => 'Push-ups',
        'alt' => 'Exercise 1'
    ],
    [
        'image' => 'images/squats.jpg',
        'description' => 'Squats',
        'alt' => 'Exercise 2'
    ],
    [
        'image' => 'images/lunges.jpg',
        'description' => 'Lunges',
        'alt' => 'Exercise 3'
    ],
    [
        'image' => 'images/plank.jpg',
        'description' => 'Plank',
        'alt' => 'Exercise 4'
    ]
];

// Generate the media items
foreach ($exercises as $exercise) {
    echo "<div class='media-item'>
            <img src='{$exercise['image']}' alt='{$exercise['alt']}'>
            <div class='media-description'>{$exercise['description']}</div>
          </div>";
}
?>