<?php
session_start();
require_once '../functions/auth_functions.php';
require_once '../db/config.php';

// Check if user is admin
if (!isAdmin() && !isSuperAdmin()) {
    http_response_code(403);
    exit(json_encode(['success' => false, 'message' => 'Unauthorized']));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $isSuperAdmin = isSuperAdmin();
    
    switch ($action) {
        case 'get_user_details':
            $userId = $_POST['user_id'] ?? '';
            $user = getUserDetails($userId);
            echo json_encode($user);
            break;
            
        case 'update_user':
            // Only super admin can update users
            if (!$isSuperAdmin) {
                exit(json_encode(['success' => false, 'message' => 'Unauthorized']));
            }
            $userId = $_POST['user_id'];
            $name = $_POST['name'];
            $email = $_POST['email'];
            $role = $_POST['role'];
            $status = $_POST['status'];
            $result = updateUser($userId, $name, $email, $role, $status);
            echo json_encode($result);
            break;
            
        case 'delete_user':
            // Only super admin can delete users
            if (!$isSuperAdmin) {
                exit(json_encode(['success' => false, 'message' => 'Unauthorized']));
            }
            $userId = $_POST['user_id'];
            $result = deleteUser($userId);
            echo json_encode($result);
            break;
            
        case 'add_user':
            // Only super admin can add users
            if (!$isSuperAdmin) {
                exit(json_encode(['success' => false, 'message' => 'Unauthorized']));
            }
            $name = $_POST['name'];
            $email = $_POST['email'];
            $role = $_POST['role'];
            $password = $_POST['password'];
            $result = addUser($name, $email, $role, $password);
            echo json_encode($result);
            break;
    }
}

// Handle GET requests (e.g., for exports)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'export_users':
            // Both admin and super admin can export
            $users = getAllUsers();
            // Generate and return the export file
            break;
    }
}

// Helper functions for interacting with the database
function getUserDetails($userId) {
    global $conn; // Assuming you have a global $conn variable for the database connection

    $stmt = $conn->prepare("SELECT * FROM beets_users WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}

function updateUser($userId, $name, $email, $role, $status) {
    global $conn;

    $stmt = $conn->prepare("UPDATE beets_users SET fname = ?, lname = ?, email = ?, role = ?, updated_at = NOW() WHERE user_id = ?");
    $stmt->bind_param("sssii", $name, $name, $email, $role, $userId);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'User updated successfully'];
    } else {
        return ['success' => false, 'message' => 'Error updating user'];
    }
}

function deleteUser($userId) {
    global $conn;

    $stmt = $conn->prepare("DELETE FROM beets_users WHERE user_id = ?");
    $stmt->bind_param("i", $userId);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'User deleted successfully'];
    } else {
        return ['success' => false, 'message' => 'Error deleting user'];
    }
}

function addUser($name, $email, $role, $password) {
    global $conn;

    $stmt = $conn->prepare("INSERT INTO beets_users (fname, lname, email, password, role, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("sssis", $name, $name, $email, $password, $role);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'User added successfully'];
    } else {
        return ['success' => false, 'message' => 'Error adding user'];
    }
}

function getAllUsers() {
    global $conn;

    $stmt = $conn->prepare("SELECT * FROM beets_users");
    $stmt->execute();
    $result = $stmt->get_result();

    return $result->fetch_all(MYSQLI_ASSOC);
}