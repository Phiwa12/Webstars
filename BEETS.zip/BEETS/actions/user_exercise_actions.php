<?php
session_start();
require_once '../functions/shared_functions.php';
require_once '../utils/error_config.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated']);
    exit;
}

// Get the request data
$requestData = json_decode(file_get_contents('php://input'), true);
$action = $requestData['action'] ?? '';

switch ($action) {
    case 'update_user_details':
        handleUpdateUserDetails($requestData['data']);
        break;
    case 'generate_workout':
        handleGenerateWorkout();
        break;
    case 'log_exercise':
        handleLogExercise($requestData['data']);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}

function handleUpdateUserDetails($data) {
    global $conn;
    
    try {
        // Validate input
        if (!validateUserDetails($data)) {
            throw new Exception('Invalid user details provided');
        }

        $stmt = $conn->prepare("
            UPDATE user_details 
            SET height = :height,
                weight = :weight,
                fitness_goal = :goal,
                updated_at = NOW()
            WHERE user_id = :user_id
        ");

        $stmt->execute([
            ':height' => $data['height'],
            ':weight' => $data['weight'],
            ':goal' => $data['goal'],
            ':user_id' => $_SESSION['user_id']
        ]);

        // Log the activity
        logUserActivity('profile_update', 'Updated profile details');

        echo json_encode([
            'success' => true,
            'message' => 'Profile updated successfully'
        ]);

    } catch (Exception $e) {
        logError('handleUpdateUserDetails', $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'Error updating profile'
        ]);
    }
}

function handleGenerateWorkout() {
    try {
        // Get user details for personalized workout
        $userDetails = getUserDetails();
        
        // Generate workout based on user's profile
        $workout = generatePersonalizedWorkout($userDetails);
        
        // Save the generated workout
        saveWorkoutPlan($workout);
        
        echo json_encode([
            'success' => true,
            'workout' => $workout
        ]);

    } catch (Exception $e) {
        logError('handleGenerateWorkout', $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'Error generating workout'
        ]);
    }
}

function handleLogExercise($data) {
    global $conn;
    
    try {
        // Validate input
        if (!validateExerciseLog($data)) {
            throw new Exception('Invalid exercise log data');
        }

        $stmt = $conn->prepare("
            INSERT INTO exercise_logs 
            (user_id, exercise_type, duration, status, created_at)
            VALUES (:user_id, :type, :duration, 'completed', NOW())
        ");

        $stmt->execute([
            ':user_id' => $_SESSION['user_id'],
            ':type' => $data['exerciseType'],
            ':duration' => $data['duration']
        ]);

        // Log the activity
        logUserActivity('exercise', "Completed {$data['duration']} minutes of {$data['exerciseType']}");

        // Get the logged entry for response
        $logEntry = [
            'date' => date('M j, Y'),
            'exercise_type' => $data['exerciseType'],
            'duration' => $data['duration'],
            'status' => 'completed'
        ];

        echo json_encode([
            'success' => true,
            'log' => $logEntry
        ]);

    } catch (Exception $e) {
        logError('handleLogExercise', $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'Error logging exercise'
        ]);
    }
}

// Validation Functions
function validateUserDetails($data) {
    return (
        is_numeric($data['height']) && $data['height'] > 0 &&
        is_numeric($data['weight']) && $data['weight'] > 0 &&
        in_array($data['goal'], ['weight_loss', 'muscle_gain', 'maintenance'])
    );
}

function validateExerciseLog($data) {
    return (
        !empty($data['exerciseType']) &&
        is_numeric($data['duration']) &&
        $data['duration'] > 0
    );
}

// Helper Functions
function generatePersonalizedWorkout($userDetails) {
    // Example workout structure
    return [
        [
            'title' => 'Warm Up',
            'exercises' => [
                '5 minutes light cardio',
                'Dynamic stretching',
                'Joint mobility exercises'
            ]
        ],
        [
            'title' => 'Main Workout',
            'exercises' => [
                '3 sets of 12 pushups',
                '3 sets of 15 squats',
                '3 sets of 10 lunges per leg',
                '30 seconds plank'
            ]
        ],
        [
            'title' => 'Cool Down',
            'exercises' => [
                'Light stretching',
                'Breathing exercises',
                '5 minutes walking'
            ]
        ]
    ];
}

function saveWorkoutPlan($workout) {
    global $conn;
    
    try {
        $stmt = $conn->prepare("
            INSERT INTO workout_plans 
            (user_id, plan_data, created_at)
            VALUES (:user_id, :plan_data, NOW())
        ");

        $stmt->execute([
            ':user_id' => $_SESSION['user_id'],
            ':plan_data' => json_encode($workout)
        ]);

        return true;
    } catch (Exception $e) {
        logError('saveWorkoutPlan', $e->getMessage());
        return false;
    }
}
?>