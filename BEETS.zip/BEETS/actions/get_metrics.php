<?php
require_once '../db/config.php';
header('Content-Type: application/json');

try {
    // Fetch user engagement metrics
    $user_query = "SELECT COUNT(*) AS total_users FROM beets_users";
    $user_result = mysqli_query($conn, $user_query);
    $user_data = mysqli_fetch_assoc($user_result);

    // Fetch resource utilization
    $resource_query = "SELECT COUNT(*) AS total_resources FROM educational_resources";
    $resource_result = mysqli_query($conn, $resource_query);
    $resource_data = mysqli_fetch_assoc($resource_result);

    // Fetch forum activity
    $forum_query = "SELECT COUNT(*) AS total_posts FROM forum_posts";
    $forum_result = mysqli_query($conn, $forum_query);
    $forum_data = mysqli_fetch_assoc($forum_result);

    // Fetch health progress
    $health_query = "SELECT AVG(weight) AS avg_weight, AVG(blood_sugar_level) AS avg_blood_sugar 
                    FROM progress_logs";
    $health_result = mysqli_query($conn, $health_query);
    $health_data = mysqli_fetch_assoc($health_result);

    $metrics = [
        'total_users' => $user_data['total_users'],
        'total_resources' => $resource_data['total_resources'],
        'total_posts' => $forum_data['total_posts'],
        'avg_weight' => number_format($health_data['avg_weight'] ?? 0, 2),
        'avg_blood_sugar' => number_format($health_data['avg_blood_sugar'] ?? 0, 2)
    ];

    echo json_encode([
        'success' => true,
        'metrics' => $metrics
    ]);

} catch (Exception $e) {
    error_log("Error fetching metrics: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching metrics'
    ]);
}
?>