<?php
session_start();
require_once '../db/database.php';
require_once '../functions/user_dash_functions.php';
require_once '../utils/error_config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'complete_reminder':
            handleCompleteReminder();
            break;
        case 'log_blood_sugar':
            handleBloodSugarLog();
            break;
        case 'log_exercise':
            handleExerciseLog();
            break;
        case 'get_notifications':
            handleGetNotifications();
            break;
        case 'mark_notification_read':
            handleMarkNotificationRead();
            break;
        case 'update_medication_status':
            handleMedicationStatus();
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            break;
    }
}

function handleCompleteReminder() {
    global $conn;
    
    $reminderId = filter_input(INPUT_POST, 'reminder_id', FILTER_SANITIZE_NUMBER_INT);
    
    if (!$reminderId) {
        echo json_encode(['success' => false, 'message' => 'Invalid reminder ID']);
        return;
    }

    try {
        $conn->beginTransaction();

        // Update reminder status
        $updateQuery = "UPDATE reminders 
                       SET status = 'completed', 
                           completed_at = NOW() 
                       WHERE reminder_id = :reminder_id 
                       AND user_id = :user_id";
        
        $stmt = $conn->prepare($updateQuery);
        $stmt->execute([
            ':reminder_id' => $reminderId,
            ':user_id' => $_SESSION['user_id']
        ]);

        // Log the activity
        $activityQuery = "INSERT INTO user_activities (user_id, activity_type, description) 
                         SELECT :user_id, 'reminder', CONCAT('Completed: ', title) 
                         FROM reminders 
                         WHERE reminder_id = :reminder_id";
        
        $stmt = $conn->prepare($activityQuery);
        $stmt->execute([
            ':user_id' => $_SESSION['user_id'],
            ':reminder_id' => $reminderId
        ]);

        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Reminder completed successfully']);
        
    } catch (Exception $e) {
        $conn->rollBack();
        logError('handleCompleteReminder', $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error completing reminder']);
    }
}

function handleBloodSugarLog() {
    global $conn;
    
    $bloodSugar = filter_input(INPUT_POST, 'blood_sugar', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    $timestamp = filter_input(INPUT_POST, 'timestamp', FILTER_SANITIZE_STRING) ?? date('Y-m-d H:i:s');
    
    if (!$bloodSugar) {
        echo json_encode(['success' => false, 'message' => 'Invalid blood sugar value']);
        return;
    }

    try {
        $conn->beginTransaction();

        // Insert blood sugar reading
        $insertQuery = "INSERT INTO blood_sugar_readings (user_id, blood_sugar, measured_at) 
                       VALUES (:user_id, :blood_sugar, :measured_at)";
        
        $stmt = $conn->prepare($insertQuery);
        $stmt->execute([
            ':user_id' => $_SESSION['user_id'],
            ':blood_sugar' => $bloodSugar,
            ':measured_at' => $timestamp
        ]);

        // Log the activity
        logUserActivity('blood_sugar', "Logged blood sugar: {$bloodSugar} mg/dL");

        $conn->commit();
        echo json_encode([
            'success' => true, 
            'message' => 'Blood sugar logged successfully',
            'data' => ['value' => $bloodSugar, 'time' => formatTimeAgo($timestamp)]
        ]);
        
    } catch (Exception $e) {
        $conn->rollBack();
        logError('handleBloodSugarLog', $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error logging blood sugar']);
    }
}

function handleExerciseLog() {
    global $conn;
    
    $exerciseType = filter_input(INPUT_POST, 'exercise_type', FILTER_SANITIZE_STRING);
    $duration = filter_input(INPUT_POST, 'duration', FILTER_SANITIZE_NUMBER_INT);
    $intensity = filter_input(INPUT_POST, 'intensity', FILTER_SANITIZE_STRING);
    
    if (!$exerciseType || !$duration) {
        echo json_encode(['success' => false, 'message' => 'Invalid exercise details']);
        return;
    }

    try {
        $conn->beginTransaction();

        // Insert exercise log
        $insertQuery = "INSERT INTO exercise_logs 
                       (user_id, exercise_type, duration, intensity) 
                       VALUES (:user_id, :type, :duration, :intensity)";
        
        $stmt = $conn->prepare($insertQuery);
        $stmt->execute([
            ':user_id' => $_SESSION['user_id'],
            ':type' => $exerciseType,
            ':duration' => $duration,
            ':intensity' => $intensity
        ]);

        // Log the activity
        logUserActivity('exercise', "Completed {$duration} minutes of {$exerciseType}");

        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Exercise logged successfully']);
        
    } catch (Exception $e) {
        $conn->rollBack();
        logError('handleExerciseLog', $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error logging exercise']);
    }
}

function handleGetNotifications() {
    global $conn;
    
    try {
        $query = "SELECT notification_id, title, message, created_at, priority 
                 FROM notifications 
                 WHERE user_id = :user_id 
                 AND status = 'unread' 
                 ORDER BY priority DESC, created_at DESC 
                 LIMIT 10";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([':user_id' => $_SESSION['user_id']]);
        
        $notifications = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $notifications[] = [
                'id' => $row['notification_id'],
                'title' => $row['title'],
                'message' => $row['message'],
                'time' => formatTimeAgo($row['created_at']),
                'priority' => $row['priority']
            ];
        }
        
        echo json_encode(['success' => true, 'notifications' => $notifications]);
        
    } catch (Exception $e) {
        logError('handleGetNotifications', $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error fetching notifications']);
    }
}

function handleMarkNotificationRead() {
    global $conn;
    
    $notificationId = filter_input(INPUT_POST, 'notification_id', FILTER_SANITIZE_NUMBER_INT);
    
    if (!$notificationId) {
        echo json_encode(['success' => false, 'message' => 'Invalid notification ID']);
        return;
    }

    try {
        $updateQuery = "UPDATE notifications 
                       SET status = 'read', 
                           read_at = NOW() 
                       WHERE notification_id = :notification_id 
                       AND user_id = :user_id";
        
        $stmt = $conn->prepare($updateQuery);
        $stmt->execute([
            ':notification_id' => $notificationId,
            ':user_id' => $_SESSION['user_id']
        ]);
        
        echo json_encode(['success' => true, 'message' => 'Notification marked as read']);
        
    } catch (Exception $e) {
        logError('handleMarkNotificationRead', $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error updating notification']);
    }
}

function handleMedicationStatus() {
    global $conn;
    
    $scheduleId = filter_input(INPUT_POST, 'schedule_id', FILTER_SANITIZE_NUMBER_INT);
    $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);
    
    if (!$scheduleId || !$status) {
        echo json_encode(['success' => false, 'message' => 'Invalid medication details']);
        return;
    }

    try {
        $conn->beginTransaction();

        // Update medication status
        $updateQuery = "UPDATE medication_schedule 
                       SET status = :status, 
                           last_taken = CASE WHEN :status = 'taken' THEN NOW() ELSE last_taken END 
                       WHERE schedule_id = :schedule_id 
                       AND user_id = :user_id";
        
        $stmt = $conn->prepare($updateQuery);
        $stmt->execute([
            ':schedule_id' => $scheduleId,
            ':status' => $status,
            ':user_id' => $_SESSION['user_id']
        ]);

        // Log the activity if medication was taken
        if ($status === 'taken') {
            logUserActivity('medication', "Took scheduled medication");
        }

        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Medication status updated']);
        
    } catch (Exception $e) {
        $conn->rollBack();
        logError('handleMedicationStatus', $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error updating medication status']);
    }
}

// Helper function to log user activities
function logUserActivity($type, $description) {
    global $conn;
    
    $query = "INSERT INTO user_activities (user_id, activity_type, description) 
              VALUES (:user_id, :type, :description)";
    
    $stmt = $conn->prepare($query);
    $stmt->execute([
        ':user_id' => $_SESSION['user_id'],
        ':type' => $type,
        ':description' => $description
    ]);
}
?>