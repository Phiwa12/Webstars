// /BEETS/includes/public_footer.php
<footer class="bg-gray-800 text-white py-8 mt-auto">
    <div class="max-w-7xl mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
                <h3 class="text-xl font-bold mb-4">BEETS</h3>
                <p>Supporting your diabetes management journey</p>
            </div>
            <div>
                <h4 class="text-lg font-bold mb-4">Quick Links</h4>
                <ul class="space-y-2">
                    <li><a href="/BEETS/view/aboutUs.php" class="hover:text-orange-400">About Us</a></li>
                    <li><a href="/BEETS/view/contactUs.php" class="hover:text-orange-400">Contact</a></li>
                </ul>
            </div>
            <div>
                <h4 class="text-lg font-bold mb-4">Contact Info</h4>
                <ul class="space-y-2">
                    <li><i class="fas fa-envelope mr-2"></i>beetsSupport@gmail.com</li>
                    <li><i class="fas fa-phone mr-2"></i>053456722</li>
                    <li><i class="fas fa-exclamation-circle mr-2"></i>Emergency: 4563</li>
                </ul>
            </div>
        </div>
        <div class="mt-8 pt-8 border-t border-gray-700 text-center">
            <p>&copy; <?php echo date('Y'); ?> BEETS. All rights reserved.</p>
        </div>
    </div>
</footer>