// /BEETS/includes/public_header.php
<?php
// Common header for public pages
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'BEETS'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/BEETS/assets/css/style.css">
    <script src="https://kit.fontawesome.com/e3a39f7147.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../assets/css/aboutUs.css">
</head>
<body>
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="/BEETS/index.php" class="text-2xl font-bold text-orange-600">BEETS</a>
                </div>

                <div class="hidden md:flex items-center space-x-8">
                    <a href="/BEETS/index.php" class="nav-link text-gray-700 hover:text-orange-600">Home</a>
                    <a href="/BEETS/view/aboutUs.php" class="nav-link text-gray-700 hover:text-orange-600">About</a>
                    <a href="/BEETS/view/contactUs.php" class="nav-link text-gray-700 hover:text-orange-600">Contact</a>
                    <a href="/BEETS/view/loginbeets.php" class="px-4 py-2 text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition duration-300">Login</a>
                    <a href="/BEETS/view/signupbeets.php" class="px-4 py-2 border border-orange-600 text-orange-600 rounded-lg hover:bg-orange-600 hover:text-white transition duration-300">Sign Up</a>
                </div>

                <!-- Mobile menu button -->
                <div class="md:hidden flex items-center">
                    <button class="mobile-menu-button">
                        <i class="fa-solid fa-bars"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile menu -->
        <div class="mobile-menu hidden md:hidden">
            <a href="/BEETS/index.php" class="block py-2 px-4 text-sm hover:bg-gray-100">Home</a>
            <a href="/BEETS/view/aboutUs.php" class="block py-2 px-4 text-sm hover:bg-gray-100">About</a>
            <a href="/BEETS/view/contactUs.php" class="block py-2 px-4 text-sm hover:bg-gray-100">Contact</a>
            <a href="/BEETS/view/loginbeets.php" class="block py-2 px-4 text-sm hover:bg-gray-100">Login</a>
            <a href="/BEETS/view/signupbeets.php" class="block py-2 px-4 text-sm hover:bg-gray-100">Sign Up</a>
        </div>
    </nav>
</body>
</html>

