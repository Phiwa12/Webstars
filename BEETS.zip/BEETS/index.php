<?php
// index.php

// Initialize session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database configuration
require_once 'db/config.php';
require_once 'functions/auth_functions.php';

// Function to get appropriate redirect link based on user role
function getRedirectLink() {
    if (!isLoggedIn()) {
        return "view/loginbeets.php";
    }
    
    $role = $_SESSION['role'] ?? 0;
    return match($role) {
        1, 2 => "view/admin/admin_dashboard.php", // Super Admin and Admin
        default => "view/user/dashboard.php"      // Regular user
    };
}

$link = getRedirectLink();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BEETS - Diabetes Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/indexbeets.css">
    <style>
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)),
                        url('assets/images/hero-bg.jpg') no-repeat center center;
            background-size: cover;
            height: calc(100vh - 64px);
        }

        .nav-link {
            position: relative;
            transition: all 0.3s ease;
        }

        .nav-link::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -2px;
            left: 0;
            background-color: #4F46E5;
            transition: width 0.3s ease;
        }

        .nav-link:hover::after {
            width: 100%;
        }

        .hero-button {
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .hero-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                120deg,
                transparent,
                rgba(255, 255, 255, 0.2),
                transparent
            );
            transition: all 0.5s ease;
        }

        .hero-button:hover::before {
            left: 100%;
        }
    </style>
</head>
<body class="flex flex-col min-h-screen bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="index.php" class="text-2xl font-bold text-indigo-600">BEETS</a>
                </div>

                <div class="hidden md:flex items-center space-x-8">
                    <a href="index.php" class="nav-link text-gray-700 hover:text-indigo-600">Home</a>
                    <a href="view/aboutUs.php" class="nav-link text-gray-700 hover:text-indigo-600">About</a>
                    <a href="view/contactUs.php" class="nav-link text-gray-700 hover:text-indigo-600">Contact</a>
                    <a href="view/Resources.php" class="nav-link text-gray-700 hover:text-indigo-600">Resources</a>
                    
                    <?php if (!isLoggedIn()): ?>
                        <a href="view/loginbeets.php" class="px-4 py-2 text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition duration-300">Log In</a>
                        <a href="view/signupbeets.php" class="px-4 py-2 border border-indigo-600 text-indigo-600 rounded-lg hover:bg-indigo-600 hover:text-white transition duration-300">Sign Up</a>
                    <?php else: ?>
                        <a href="<?php echo htmlspecialchars($link); ?>" class="nav-link text-gray-700 hover:text-indigo-600">Dashboard</a>
                        <a href="actions/logout.php" class="px-4 py-2 text-white bg-red-600 rounded-lg hover:bg-red-700 transition duration-300">Logout</a>
                    <?php endif; ?>
                </div>

                <!-- Mobile menu button -->
                <div class="md:hidden flex items-center">
                    <button class="mobile-menu-button">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                        </svg>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile menu -->
        <div class="mobile-menu hidden md:hidden">
            <a href="index.php" class="block py-2 px-4 text-sm hover:bg-gray-100">Home</a>
            <a href="view/aboutUs.php" class="block py-2 px-4 text-sm hover:bg-gray-100">About</a>
            <a href="view/contactUs.php" class="block py-2 px-4 text-sm hover:bg-gray-100">Contact</a>
            <a href="view/Resources.php" class="block py-2 px-4 text-sm hover:bg-gray-100">Resources</a>
            <?php if (!isLoggedIn()): ?>
                <a href="view/loginbeets.php" class="block py-2 px-4 text-sm hover:bg-gray-100">Log In</a>
                <a href="view/signupbeets.php" class="block py-2 px-4 text-sm hover:bg-gray-100">Sign Up</a>
            <?php else: ?>
                <a href="<?php echo htmlspecialchars($link); ?>" class="block py-2 px-4 text-sm hover:bg-gray-100">Dashboard</a>
                <a href="actions/logout.php" class="block py-2 px-4 text-sm hover:bg-gray-100">Logout</a>
            <?php endif; ?>
        </div>
    </nav>

    <!-- Hero Section -->
    <main class="flex-grow">
        <div class="hero-section flex items-center justify-center">
            <div class="text-center text-white px-4">
                <h1 class="text-5xl font-bold mb-6">Welcome to Beets</h1>
                <p class="text-xl mb-4">Sweet Life, Healthy Choices!</p>
                <p class="max-w-2xl mx-auto mb-8 text-lg">
                    Helping patients with diabetes to solve problems like managing diet, keeping up with medication, 
                    staying active, preventing complications, progress tracking, and getting support from others with diabetes.
                </p>
                <a href="<?php echo htmlspecialchars($link); ?>" 
                   class="hero-button inline-block px-8 py-3 bg-indigo-600 text-white rounded-lg text-lg font-semibold hover:bg-indigo-700 transition duration-300">
                    <?php echo isLoggedIn() ? 'Go to Dashboard' : 'Get Started'; ?>
                </a>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-8">
        <div class="max-w-7xl mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                    <h3 class="text-xl font-bold mb-4">BEETS</h3>
                    <p>Supporting your diabetes management journey</p>
                </div>
                <div>
                    <h4 class="text-lg font-bold mb-4">Quick Links</h4>
                    <ul class="space-y-2">
                        <li><a href="view/aboutUs.php" class="hover:text-indigo-400">About Us</a></li>
                        <li><a href="view/contactUs.php" class="hover:text-indigo-400">Contact</a></li>
                        <li><a href="view/Resources.php" class="hover:text-indigo-400">Resources</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-lg font-bold mb-4">Connect With Us</h4>
                    <div class="flex space-x-4">
                        <a href="#" class="hover:text-indigo-400"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="hover:text-indigo-400"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="hover:text-indigo-400"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="mt-8 pt-8 border-t border-gray-700 text-center">
                <p>&copy; <?php echo date('Y'); ?> BEETS. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Mobile menu functionality
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuButton = document.querySelector('.mobile-menu-button');
            const mobileMenu = document.querySelector('.mobile-menu');

            mobileMenuButton.addEventListener('click', () => {
                mobileMenu.classList.toggle('hidden');
            });
        });
    </script>
</body>
</html>