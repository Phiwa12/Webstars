<?php
require_once '../db/config.php';
require_once '../functions/planning_function.php';
require_once '../functions/progress_function.php';

// Initialize session and check for user data
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Progress Tracking</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
    <link href="../assets/css/progress.css" rel="stylesheet">
</head>
<body class="p-4 md:p-6 lg:p-8">
    <div class="top-bar">
    <li>
                <a href="../../actions/logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </li>
        <a href="../view/services.php" class="back-button">← Back to Services</a>
    </div>
    <div class="max-w-6xl mx-auto">
        <div class="text-center mb-12">
            <h1 class="text-4xl font-bold text-#ac4800 mb-3">Progress Tracking</h1>
            <p class="text-gray-600 max-w-2xl mx-auto text-lg">Track your fitness journey with personalized workout routines tailored to your goals and needs</p>
        </div>

        <!-- Progress Tracking Section -->
        <div class="glass-effect rounded-2xl overflow-hidden mb-8">
            <div class="card-header p-6">
                <h2 class="text-xl font-semibold text-gray-800">Progress Tracking</h2>
            </div>
            <div class="p-6">
                <!-- Tabs -->
                <div class="flex space-x-4 mb-6">
                    <button onclick="switchChart('weight')" class="tab-button active px-4 py-2 rounded-lg" id="weightTab">Weight Progress</button>
                    <button onclick="switchChart('bloodSugar')" class="tab-button px-4 py-2 rounded-lg" id="bloodSugarTab">Blood Sugar Levels</button>
                </div>

                <!-- Input Form -->
                <form id="progressForm" action="save_progress.php" method="POST">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                        <div>
                            <input type="date" id="trackingDate" name="trackingDate" class="progress-input w-full px-4 py-2 rounded-lg border">
                        </div>
                        <div>
                            <input type="number" id="weightInput" name="weight" step="0.1" placeholder="Weight (kg)" class="progress-input w-full px-4 py-2 rounded-lg border">
                        </div>
                        <div>
                            <input type="number" id="bloodSugarInput" name="bloodSugar" placeholder="Blood Sugar (mg/dL)" class="progress-input w-full px-4 py-2 rounded-lg border">
                        </div>
                    </div>
                    <button type="submit" class="gradient-button text-white px-6 py-2 rounded-lg mb-6">
                        <span>Log Progress</span>
                    </button>
                </form>

                <!-- Charts -->
                <div class="chart-container">
                    <canvas id="progressChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Initial data from PHP
        const initialData = <?php echo getInitialChartData(); ?>;
    </script>
    <script src="js/progress.js"></script>
</body>
</html>