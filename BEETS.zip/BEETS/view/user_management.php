<?php
session_start();
require_once '../functions/auth_functions.php';
require_once '../functions/user_management_functions.php';
require_once '../db/config.php';

// Check if user is logged in and has admin privileges
if (!isset($_SESSION['user_id']) || $_SESSION['role'] > 2) {
    header('Location: unauthorized.php');
    exit();
}

// Set up variables
$userRole = $_SESSION['role'];
$isSuperAdmin = ($userRole === 1);
$isAdmin = ($userRole === 2);
$adminName = $_SESSION['fname'] . ' ' . $_SESSION['lname'];

// Initialize variables with default values
$searchTerm = $_GET['search'] ?? '';
$roleFilter = $_GET['role'] ?? '';
$statusFilter = $_GET['status'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));

// Fetch filtered users and total user count
$users = getFilteredUsers($searchTerm, $roleFilter, $statusFilter, $page);
$totalUsers = getTotalUsers($searchTerm, $roleFilter, $statusFilter);

// Fetch roles for role filter
$roles = getAllRoles();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Admin Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/user_management.css">
</head>
<body class="bg-gray-50">
    <!-- Admin Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-50">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-2xl font-bold text-ac4800">Admin Dashboard</h1>
                </div>
                <div class="flex items-center gap-4">
                    <span class="text-gray-600">
                        Welcome, <?php echo htmlspecialchars($adminName); ?>
                    </span>
                    <a href="../actions/logout.php" class="text-red-600 hover:text-red-800">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="pt-20 px-4">
        <div class="max-w-7xl mx-auto">
            <!-- Header Section -->
            <div class="mb-8 flex justify-between items-center">
                <div>
                    <h2 class="text-3xl font-bold text-gray-800">User Management</h2>
                    <p class="text-gray-600">Manage all system users and their permissions</p>
                </div>
                <?php if ($isSuperAdmin): ?>
                <button onclick="showAddUserModal()" class="btn-primary">
                    <i class="fas fa-user-plus"></i> Add New User
                </button>
                <?php endif; ?>
            </div>

            <!-- Filters and Search -->
            <div class="bg-white rounded-lg shadow p-6 mb-8">
                <form id="filterForm" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Search</label>
                        <input type="text" name="search" value="<?php echo htmlspecialchars($searchTerm); ?>"
                               class="search-input" placeholder="Search users...">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Role</label>
                        <select name="role" class="select-input">
                            <option value="">All Roles</option>
                            <?php foreach ($roles as $role): ?>
                                <option value="<?php echo $role['id']; ?>" 
                                        <?php echo $roleFilter == $role['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($role['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Status</label>
                        <select name="status" class="select-input">
                            <option value="">All Status</option>
                            <option value="active" <?php echo $statusFilter == 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo $statusFilter == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                            <option value="pending" <?php echo $statusFilter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                        </select>
                    </div>
                    <div class="flex items-end">
                        <button type="submit" class="btn-secondary w-full">
                            <i class="fas fa-filter"></i> Apply Filters
                        </button>
                    </div>
                </form>
            </div>

            <!-- Users Table -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <div class="flex justify-between items-center p-4 border-b">
                    <h3 class="text-lg font-semibold text-gray-800">Users List</h3>
                    <div class="flex gap-2">
                        <button onclick="exportUserData('csv')" class="btn-secondary">
                            <i class="fas fa-file-csv"></i> Export CSV
                        </button>
                        <button onclick="exportUserData('pdf')" class="btn-secondary">
                            <i class="fas fa-file-pdf"></i> Export PDF
                        </button>
                    </div>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="table-header">User</th>
                                <th class="table-header">Role</th>
                                <th class="table-header">Status</th>
                                <th class="table-header">Last Login</th>
                                <th class="table-header">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php if ($users && count($users) > 0): ?>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td class="table-cell">
                                            <div class="flex items-center">
                                                <div class="ml-4">
                                                    <div class="font-medium text-gray-900">
                                                        <?php echo htmlspecialchars($user['fname'] . ' ' . $user['lname']); ?>
                                                    </div>
                                                    <div class="text-gray-500">
                                                        <?php echo htmlspecialchars($user['email']); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="table-cell">
                                            <span class="role-badge <?php echo getRoleBadgeClass($user['role']); ?>">
                                                <?php echo htmlspecialchars($user['role_name']); ?>
                                            </span>
                                        </td>
                                        <td class="table-cell">
                                            <span class="status-badge">
                                                Active
                                            </span>
                                        </td>
                                        <td class="table-cell">
                                            <?php echo formatDateTime($user['created_at']); ?>
                                        </td>
                                        <td class="table-cell">
                                            <div class="flex gap-2">
                                                <!-- All admins can view -->
                                                <button onclick="viewUserDetails(<?php echo $user['user_id']; ?>)" 
                                                        class="action-btn view-btn" 
                                                        title="View Details">
                                                    <i class="fas fa-eye"></i>
                                                </button>

                                                <?php if ($isSuperAdmin): ?>
                                                    <!-- Only super admin can edit/delete -->
                                                    <button onclick="editUser(<?php echo $user['user_id']; ?>)" 
                                                            class="action-btn edit-btn" 
                                                            title="Edit User">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    
                                                    <?php if ($user['role'] != 1): ?>
                                                        <button onclick="confirmDeleteUser(<?php echo $user['user_id']; ?>)" 
                                                                class="action-btn delete-btn" 
                                                                title="Delete User">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4">No users found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination -->
                <div class="pagination">
                    <?php echo generatePagination($page, $totalUsers); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Only include modals for super admin -->
    <?php if ($isSuperAdmin): ?>
        <?php include 'admin/user_add_modal.php'; ?>
        <?php include 'admin/user_delete_modal.php'; ?>
        <?php include 'admin/user_edit_modal.php'; ?>
    <?php endif; ?>
    
    <!-- View modal for all admins -->
    <?php include 'admin/user_view_modal.php'; ?>

    <script src="../assets/js/user_management.js"></script>
</body>
</html>