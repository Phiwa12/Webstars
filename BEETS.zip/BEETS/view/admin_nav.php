<nav class="admin-nav">
    <ul class="nav-list">
        <li>
            <a href="admin_dashboard.php" <?php echo basename($_SERVER['PHP_SELF']) == 'admin_dashboard.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-bar"></i>
                Dashboard
            </a>
        </li>
        <li>
            <a href="AnalyticsReporting.php" <?php echo basename($_SERVER['PHP_SELF']) == 'AnalyticsReporting.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-chart-line"></i>
                Analytics & Reporting
            </a>
        </li>
        <li>
            <a href="ResourceManagement.php" <?php echo basename($_SERVER['PHP_SELF']) == 'ResourceManagement.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-book"></i>
                Resource Management
            </a>
        </li>
        <li>
            <a href="user_management.php" <?php echo basename($_SERVER['PHP_SELF']) == 'user_management.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-users"></i>
                User Management
            </a>
        </li>
        <li>
            <a href="forum_moderation.php" <?php echo basename($_SERVER['PHP_SELF']) == 'forum_moderation.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-comments"></i>
                Forum Moderation
            </a>
        </li>
        <li>
            <a href="healthcare_provider.php" <?php echo basename($_SERVER['PHP_SELF']) == 'healthcare_provider.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-heart"></i>
                Healthcare Provider
            </a>
        </li>
    </ul>
</nav>