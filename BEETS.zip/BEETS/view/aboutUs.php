
<?php
$pageTitle = "About Us - BEETS";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="../assets/css/aboutUs.css">
    <script src="https://kit.fontawesome.com/e3a39f7147.js" crossorigin="anonymous"></script>
</head>
<body>
    <header class="header">
        <a href="#" class="logo">Beets</a>

        <input type="checkbox" id="check">
        <label for="check" class="icons">
            <i class="fa-solid fa-bars" id="menu-icon"></i>
            <i class="fa-solid fa-x" id="close-icon"></i>
        </label>

        <nav class="navbar">
            <a href="../index.php" style="--i:0;">Home</a>
            <a href="aboutUs.php" style="--i:1;">About</a>
            <a href="contactUs.php" style="--i:2;">Contact</a>
            <a href="signupbeets.php" style="--i:4;">SignUp</a>
            <a href="loginbeets.php" style="--i:5;">LogIn</a>
        </nav>
    </header>

    <main>
        <section class="left-content">
            <h1>About Us</h1>
            <h2>Welcome to our platform!</h2>
            <p>We're dedicated to helping people with diabetes live healthier and easier lives. Managing diabetes can be tough, but with the right tools and support, it doesn't have to be overwhelming.</p>
            <p>Our platform offers personalized tools for managing your diet, exercise, medication, and more. We aim to help you stay on track and make diabetes management simpler.</p>
            
            <h3>Here's what we provide:</h3>
            <ul>
                <li><strong>Diet Plans:</strong> Customized meal plans and recipes that fit your needs.</li>
                <li><strong>Exercise Routines:</strong> Personalized workout plans, whether at home or in the gym.</li>
                <li><strong>Medication Reminders:</strong> Keep track of your meds with simple reminders.</li>
                <li><strong>Community Support:</strong> Connect with others for tips, encouragement, and support.</li>
            </ul>
            <p>Our goal is to help you live a full, healthy life while managing diabetes. Whether you're newly diagnosed or have been living with diabetes for years, we're here to support you every step of the way.</p>
        </section>
        
        <aside class="right-content">
            <img src="../assets/images/patient2.jpg" alt="Diabetes Management" class="centered-image">
        </aside>
    </main>

    <footer>
        <h3>Contact Us</h3>
        <p>If you have any questions or need support, feel free to reach out!</p>
        <p>Email: support@diabetesplatform.com</p>
        <p>Phone: (123) 456-7890</p>
        <p>&copy; 2024 Diabetes Management Platform. All Rights Reserved.</p>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const checkBox = document.getElementById('check');
            const menuItems = document.querySelectorAll('.navbar a');

            menuItems.forEach(item => {
                item.addEventListener('click', () => {
                    checkBox.checked = false;
                });
            });
        });
    </script>
</body>
</html>