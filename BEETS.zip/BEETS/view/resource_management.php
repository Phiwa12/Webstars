<?php
session_start();
require_once '../functions/auth_functions.php';
require_once '../db/config.php';

// Check if user is admin
if (!isAdmin() && !isSuperAdmin()) {
    header('Location: ../unauthorized.php');
    exit();
}

$message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['create'])) {
            $title = trim($_POST['title']);
            $content = trim($_POST['content']);
            $category = trim($_POST['category']);
            
            $stmt = $conn->prepare("INSERT INTO educational_resources (title, content, category) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $title, $content, $category);
            
            if ($stmt->execute()) {
                $message = "Resource created successfully!";
            }
        }
        elseif (isset($_POST['update'])) {
            $resource_id = $_POST['resource_id'];
            $title = trim($_POST['title']);
            $content = trim($_POST['content']);
            $category = trim($_POST['category']);
            
            $stmt = $conn->prepare("UPDATE educational_resources SET title=?, content=?, category=? WHERE resource_id=?");
            $stmt->bind_param("sssi", $title, $content, $category, $resource_id);
            
            if ($stmt->execute()) {
                $message = "Resource updated successfully!";
            }
        }
        elseif (isset($_POST['delete'])) {
            $resource_id = $_POST['resource_id'];
            
            $stmt = $conn->prepare("DELETE FROM educational_resources WHERE resource_id=?");
            $stmt->bind_param("i", $resource_id);
            
            if ($stmt->execute()) {
                $message = "Resource deleted successfully!";
            }
        }
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage();
    }
}

// Fetch all resources
$resources = $conn->query("SELECT * FROM educational_resources ORDER BY category, title");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resource Management - BEETS</title>
    <link rel="stylesheet" href="../assets/css/resource_management.css">
    <link rel="stylesheet" href="https://cdn.lineicons.com/2.0/LineIcons.css">
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <a href="services.php" class="back-btn">
                <i class="lni lni-arrow-left"></i> Back to Services
            </a>
            <a href="resources.php" class="view-btn" target="_blank">
                <i class="lni lni-eye"></i> View Public Page
            </a>
        </nav>

        <h1>Resource Management</h1>

        <?php if ($message): ?>
            <div class="message <?php echo strpos($message, 'Error') !== false ? 'error' : 'success'; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- Create Resource Form -->
        <form method="POST" class="form create-form">
            <h2>Create New Resource</h2>
            <div class="form-group">
                <label for="title">Title</label>
                <input type="text" id="title" name="title" required>
            </div>
            <div class="form-group">
                <label for="category">Category</label>
                <input type="text" id="category" name="category" required>
            </div>
            <div class="form-group">
                <label for="content">Content</label>
                <textarea id="content" name="content" required></textarea>
            </div>
            <button type="submit" name="create">Create Resource</button>
        </form>

        <!-- Resources Table -->
        <div class="resources-table">
            <h2>Existing Resources</h2>
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $resources->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['category']); ?></td>
                        <td class="actions">
                            <button onclick="editResource(<?php echo $row['resource_id']; ?>)" class="edit-btn">
                                <i class="lni lni-pencil"></i> Edit
                            </button>
                            <form method="POST" class="inline-form" onsubmit="return confirm('Are you sure you want to delete this resource?');">
                                <input type="hidden" name="resource_id" value="<?php echo $row['resource_id']; ?>">
                                <button type="submit" name="delete" class="delete-btn">
                                    <i class="lni lni-trash"></i> Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="modal hidden">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Edit Resource</h2>
            <form method="POST" class="edit-form">
                <input type="hidden" name="resource_id" id="edit_resource_id">
                <div class="form-group">
                    <label for="edit_title">Title</label>
                    <input type="text" id="edit_title" name="title" required>
                </div>
                <div class="form-group">
                    <label for="edit_category">Category</label>
                    <input type="text" id="edit_category" name="category" required>
                </div>
                <div class="form-group">
                    <label for="edit_content">Content</label>
                    <textarea id="edit_content" name="content" required></textarea>
                </div>
                <button type="submit" name="update">Update Resource</button>
            </form>
        </div>
    </div>

    <script>
        // Modal functionality
        const modal = document.getElementById('editModal');
        const closeBtn = document.querySelector('.close');

        closeBtn.onclick = function() {
            modal.classList.add('hidden');
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.classList.add('hidden');
            }
        }

        function editResource(resourceId) {
            // Fetch resource data and populate modal
            fetch(`get_resource.php?id=${resourceId}`)
                .then(response => response.json())
                .then(data => {
                    document.getElementById('edit_resource_id').value = data.resource_id;
                    document.getElementById('edit_title').value = data.title;
                    document.getElementById('edit_category').value = data.category;
                    document.getElementById('edit_content').value = data.content;
                    modal.classList.remove('hidden');
                });
        }
    </script>
</body>
</html>