<?php
// Initialize session and check for user data
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
error_log('Session contents: ' . print_r($_SESSION, true));

ini_set('display_errors', 1);
error_reporting(E_ALL);
// echo "Session status: " . session_status() . "<br>";
// echo "Session ID: " . session_id() . "<br>";
// var_dump($_SESSION);
// die();

// Load the database configuration file
$config_file = '../db/config.php';
if (file_exists($config_file)) {
    include $config_file;
} else {
    error_log("Database configuration file missing");
    die("System configuration error. Please contact support.");
}

// Check if the database connection exists
if (!isset($conn) || !$conn) {
    die("Database connection is not available. Please try again later.");
}

// Authentication check
if (!isset($_SESSION['user_id'])) {
    header("Location: loginbeets.php");
    exit();
}


// Handle all AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = ['success' => false, 'message' => 'Invalid action'];
    
    // Add debugging
    error_log('Action received: ' . $_POST['action']); // Log to server logs

    switch($_POST['action']) {
        case 'post_comment':
            if (empty(trim($_POST['comment']))) {
                $response = ['success' => false, 'message' => 'Please enter a comment'];
                break;
            }
            $comment = htmlspecialchars($_POST['comment']);
            $user_id = $_SESSION['user_id'];
            $post_id = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;
            
            $stmt = $conn->prepare("INSERT INTO forum_posts (user_id, post_id, content) VALUES (?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("iis", $user_id, $post_id, $comment);
                if ($stmt->execute()) {
                    $response = ['success' => true, 'message' => 'Comment posted successfully'];
                }
                $stmt->close();
            }
            break;
        
        case 'delete_story':
            $story_id = isset($_POST['story_id']) ? (int)$_POST['story_id'] : 0;
            $user_id = $_SESSION['user_id'];

            // Validate the story_id
            if ($story_id <= 0) {
                $response = ['success' => false, 'message' => 'Invalid story ID.'];
                break;
            }

            // Check if the story exists and if the current user is the owner
            $stmt = $conn->prepare("SELECT user_id FROM stories WHERE id = ?");
            $stmt->bind_param("i", $story_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result && $result->num_rows > 0) {
                $story = $result->fetch_assoc();

                // Check if the user is the owner of the story
                if ($story['user_id'] == $user_id) {
                    // Proceed with deletion
                    $deleteStmt = $conn->prepare("DELETE FROM stories WHERE id = ?");
                    $deleteStmt->bind_param("i", $story_id);
                    
                    if ($deleteStmt->execute()) {
                        $response = ['success' => true, 'message' => 'Story deleted successfully.'];
                    } else {
                        $response = ['success' => false, 'message' => 'Failed to delete the story. Please try again later.'];
                    }
                    $deleteStmt->close();
                } else {
                    $response = ['success' => false, 'message' => 'You do not have permission to delete this story.'];
                }
            } else {
                $response = ['success' => false, 'message' => 'Story not found.'];
            }
            
            $stmt->close();
            break;
        case 'post_story':
            if (empty(trim($_POST['story']))) {
                $response = ['success' => false, 'message' => 'Please enter a story'];
                break;
            }
            $story = htmlspecialchars($_POST['story']);
            $user_id = $_SESSION['user_id'];
                
            $stmt = $conn->prepare("INSERT INTO stories (user_id, content) VALUES (?, ?)");
            if ($stmt) {
                $stmt->bind_param("is", $user_id, $story);
                if ($stmt->execute()) {
                    $response = ['success' => true, 'message' => 'Story posted successfully'];
                } else {
                    $response = ['success' => false, 'message' => 'Failed to post story: ' . $stmt->error];
                }
                $stmt->close();
            } else {
                $response = ['success' => false, 'message' => 'Database error: ' . $conn->error];
            }
            break;
            
        case 'like_post':
            $post_id = (int)$_POST['post_id'];
            $user_id = $_SESSION['user_id'];
            
            // Check if user already liked the post
            $stmt = $conn->prepare("SELECT id FROM likes WHERE user_id = ? AND post_id = ?");
            $stmt->bind_param("ii", $user_id, $post_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                $stmt = $conn->prepare("INSERT INTO likes (user_id, post_id) VALUES (?, ?)");
                $stmt->bind_param("ii", $user_id, $post_id);
                if ($stmt->execute()) {
                    $response = ['success' => true, 'message' => 'Post liked successfully'];
                }
            } else {
                // Unlike the post
                $stmt = $conn->prepare("DELETE FROM likes WHERE user_id = ? AND post_id = ?");
                $stmt->bind_param("ii", $user_id, $post_id);
                if ($stmt->execute()) {
                    $response = ['success' => true, 'message' => 'Post unliked successfully'];
                }
            }
            break;
            
        case 'send_chat':
            if (empty(trim($_POST['message']))) {
                $response = ['success' => false, 'message' => 'Please enter a message'];
                break;
            }
            $message = htmlspecialchars($_POST['message']);
            $user_id = $_SESSION['user_id'];
            
            $stmt = $conn->prepare("INSERT INTO chat_messages (user_id, message) VALUES (?, ?)");
            if ($stmt) {
                $stmt->bind_param("is", $user_id, $message);
                if ($stmt->execute()) {
                    $response = ['success' => true, 'message' => 'Message sent successfully'];
                }
                $stmt->close();
            }
            break;
    }
    
    echo json_encode($response);
    exit;
}

// Fetch functions
function fetchComments($conn) {
    $sql = "SELECT fp.*, bu.fname, 
            (SELECT COUNT(*) FROM likes WHERE post_id = fp.id) as like_count
            FROM forum_posts fp 
            JOIN beets_users bu ON fp.user_id = bu.user_id 
            WHERE fp.post_id IS NULL
            ORDER BY fp.created_at DESC 
            LIMIT 50";

    $result = $conn->query($sql);
    return ($result && $result->num_rows > 0) ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

function fetchStories($conn) {
    $sql = "SELECT s.*, bu.fname
            FROM stories s
            JOIN beets_users bu ON s.user_id = bu.user_id
            ORDER BY s.created_at DESC
            LIMIT 20";

    $result = $conn->query($sql);
    return ($result && $result->num_rows > 0) ? $result->fetch_all(MYSQLI_ASSOC) : [];
}


$comments = fetchComments($conn);
$stories = fetchStories($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community Forum Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        <?php include "../assets/css/communityforum.css"; ?>
    </style>
</head>
<body>
    <section id="featured-discussions">
        <div class="top-bar">
            <a href="../view/services.php" class="back-button">← Back to Services</a>
            <li>
                <a href="../../actions/logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </li>
        </div>
        <h2>Featured Discussions</h2>
        <?php foreach ($comments as $comment): ?>
        <div class="discussion" data-post-id="<?php echo $comment['id']; ?>">
            <div class="discussion-header">
                <div class="discussion-profile-pic">
                    <img src="../assets/images/velma.jpg" alt="User Picture">
                </div>
                <h3><?php echo htmlspecialchars($comment['fname']); ?></h3>
            </div>
            <p><?php echo htmlspecialchars($comment['content']); ?></p>
            <div class="interaction">
                <button onclick="likePost(<?php echo $comment['id']; ?>)" class="like-btn">
                    👍 Like
                </button>
                <p>Likes: <span class="likes-count"><?php echo $comment['like_count']; ?></span></p>
                <div class="comments-section">
                    <textarea placeholder="Add a comment"></textarea>
                    <button onclick="postComment(this, <?php echo $comment['id']; ?>)">Post Comment</button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </section>

    <section id="add-story-section">
        <h2>Add Your Story</h2>
        <form id="story-form" onsubmit="return postStory(event)">
            <textarea id="story-input" name="story" placeholder="Write your story..." required></textarea>
            <button type="submit">Post Story</button>
        </form>
        <div id="story-list">
        <?php foreach ($stories as $story): ?>
        <div class="story" data-story-id="<?php echo htmlspecialchars($story['id']); ?>">
            <div class="story-header">
                <h3><?php echo htmlspecialchars($story['fname']); ?></h3>
                <?php if ($_SESSION['user_id'] == $story['user_id']): ?>
                    <button onclick="deleteStory(<?php echo $story['id']; ?>)" class="delete-btn">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                <?php endif; ?>
            </div>
            <p><?php echo htmlspecialchars($story['content']); ?></p>
            <small>Posted on: <?php echo date('M d, Y', strtotime($story['created_at'])); ?></small>
        </div>
        <?php endforeach; ?>
    </div>
    </section>

    <section id="chatbox-section">
        <div id="chat-icon">
            <i class="fas fa-comments"></i>
        </div>
        <div class="chatbox" id="chatbox">
            <div id="chat-window"></div>
            <input type="text" id="user-input" placeholder="Type your message here...">
            <button onclick="sendMessage()">Send</button>
        </div>
    </section>

    <script>
        // Chatbox functionality
        document.getElementById('chat-icon').addEventListener('click', function() {
            const chatbox = document.getElementById('chatbox');
            chatbox.style.display = chatbox.style.display === 'none' ? 'block' : 'none';
        });

        function sendMessage() {
            const input = document.getElementById('user-input');
            const message = input.value.trim();
            
            if (message === '') return;

            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=send_chat&message=${encodeURIComponent(message)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const chatWindow = document.getElementById('chat-window');
                    chatWindow.innerHTML += `<p><strong>You:</strong> ${message}</p>`;
                    input.value = '';
                    chatWindow.scrollTop = chatWindow.scrollHeight;
                }
            });
        }

        // Story posting functionality
        function postStory(event) {
            event.preventDefault();
            const storyInput = document.getElementById('story-input');
            const story = storyInput.value.trim();
            
            if (story === '') {
                alert('Please enter a story before posting.');
                return false;
            }

            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=post_story&story=${encodeURIComponent(story)}`
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    location.reload(); // Reload to show new story
                } else {
                    alert(data.message || 'Failed to post story');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to post story. Please try again.');
            });
    
    return false;
        }

        // Like functionality
        function likePost(postId) {
            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=like_post&post_id=${postId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const likeCount = document.querySelector(`[data-post-id="${postId}"] .likes-count`);
                    const currentLikes = parseInt(likeCount.textContent);
                    likeCount.textContent = data.message.includes('unliked') ? currentLikes - 1 : currentLikes + 1;
                }
            });
        }

        // Comment functionality
        function postComment(button, postId) {
            const commentTextArea = button.previousElementSibling;
            const comment = commentTextArea.value.trim();
            
            if (comment === '') {
                alert('Please enter a comment before posting.');
                return;
            }

            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=post_comment&comment=${encodeURIComponent(comment)}&post_id=${postId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload(); // Reload to show new comment
                } else {
                    alert(data.message);
                }
            });
        }

        function deleteStory(storyId) {
            if (confirm("Are you sure you want to delete this story?")) {
                fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=delete_story&story_id=${encodeURIComponent(storyId)}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Remove the story element from the DOM
                        const storyElement = document.querySelector(`.story[data-story-id="${storyId}"]`);
                        storyElement.remove();
                    } else {
                        alert('Failed to delete the story.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Failed to delete the story. Please try again.');
                });
            }
        }

        // Enter key functionality for chat
        document.getElementById('user-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    </script>
</body>
</html>