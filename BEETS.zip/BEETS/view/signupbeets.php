/ /BEETS/view/signupbeets.php
<?php
require_once '../db/config.php';
require_once '../functions/auth_functions.php';

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = trim(filter_input(INPUT_POST, 'fname', FILTER_SANITIZE_STRING));
    $lname = trim(filter_input(INPUT_POST, 'lname', FILTER_SANITIZE_STRING));
    $email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL));
    $password = trim($_POST['password']);
    $terms = isset($_POST['chk']);

    try {
        if (!$terms) {
            throw new Exception("You must agree to the terms and conditions.");
        }

        if (empty($fname) || empty($lname)) {
            throw new Exception("Please provide both first and last name.");
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Please provide a valid email address.");
        }

        if (strlen($password) < 8) {
            throw new Exception("Password must be at least 8 characters long.");
        }

        // Check if email exists
        $stmt = $conn->prepare("SELECT user_id FROM beets_users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            throw new Exception("This email is already registered. Please login instead.");
        }

        // Hash password and insert user
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO beets_users (fname, lname, email, password) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fname, $lname, $email, $hashedPassword);
        
        if (!$stmt->execute()) {
            throw new Exception("Registration failed. Please try again later.");
        }

        header("Location: loginbeets.php?registered=true");
        exit();

    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - BEETS</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url("../assets/images/orangephoto.jpg");
            background-size: cover;
            background-position: center;
            min-height: 100vh;
        }
        .form-container {
            background: rgba(0, 0, 0, 0.8);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 400px;
            margin: 2rem auto;
        }
        .input-field {
            background: transparent;
            border: 2px solid white;
            color: white;
            padding: 0.75rem;
            width: 100%;
            border-radius: 8px;
            margin-top: 0.5rem;
        }
        .input-field::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        .input-field:focus {
            border-color: #ac4800;
            outline: none;
        }
        .submit-btn {
            background-color: #ac4800;
            width: 100%;
            padding: 0.75rem;
            color: white;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .submit-btn:hover {
            background-color: #943e00;
            transform: translateY(-2px);
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen">
    <div class="form-container">
        <h2 class="text-3xl font-bold text-white text-center mb-6">Create Account</h2>
        
        <?php if (!empty($error)): ?>
            <div class="bg-red-500 bg-opacity-20 border-l-4 border-red-500 text-white p-4 mb-4">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="signupbeets.php" class="space-y-4">
            <div>
                <label for="fname" class="block text-white text-sm mb-1">First Name</label>
                <input type="text" id="fname" name="fname" 
                       class="input-field" 
                       placeholder="Enter your first name" 
                       required>
            </div>

            <div>
                <label for="lname" class="block text-white text-sm mb-1">Last Name</label>
                <input type="text" id="lname" name="lname" 
                       class="input-field" 
                       placeholder="Enter your last name" 
                       required>
            </div>

            <div>
                <label for="email" class="block text-white text-sm mb-1">Email</label>
                <input type="email" id="email" name="email" 
                       class="input-field" 
                       placeholder="Enter your email" 
                       required>
            </div>

            <div>
                <label for="password" class="block text-white text-sm mb-1">Password</label>
                <input type="password" id="password" name="password" 
                       class="input-field" 
                       placeholder="Enter your password" 
                       required>
                <p class="text-white text-xs mt-1 opacity-75">
                    Password must be at least 8 characters long
                </p>
            </div>

            <div class="flex items-center">
                <input type="checkbox" id="chk" name="chk" required class="rounded border-gray-300">
                <label for="chk" class="ml-2 text-white text-sm">
                    I agree to the Terms and Conditions
                </label>
            </div>

            <button type="submit" class="submit-btn">
                Create Account
            </button>

            <div class="text-center text-white text-sm">
                <p>Already have an account? 
                    <a href="loginbeets.php" class="text-orange-400 hover:text-orange-300">
                        Login here
                    </a>
                </p>
            </div>
        </form>
    </div>
</body>
</html>