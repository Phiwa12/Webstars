<?php
session_start();

// Load the database configuration file
$config_file = '../db/config.php';
if (file_exists($config_file)) {
    include $config_file;
} else {
    error_log("Database configuration file missing");
    $error_message = "System configuration error. Please contact support.";
}

// Authentication Check 
$isLoggedIn = isset($_SESSION['user_id']);

// Meal Plan Generation Function
function calculateCalories($weight, $height, $age, $sex, $activityLevel) {
    if ($sex === 'male') {
        $bmr = 88.36 + (13.4 * $weight) + (4.8 * $height) - (5.7 * $age);
    } else {
        $bmr = 447.6 + (9.2 * $weight) + (3.1 * $height) - (4.3 * $age);
    }
    
    $activityFactors = ['low' => 1.2, 'moderate' => 1.55, 'high' => 1.9];
    return round($bmr * $activityFactors[$activityLevel]);
}

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isLoggedIn) {
    // Validate and Process Form Data (sanitization)
    $age = filter_input(INPUT_POST, 'age', FILTER_VALIDATE_INT);
    $sex = htmlspecialchars($_POST['sex'] ?? '', ENT_QUOTES, 'UTF-8');
    $height = filter_input(INPUT_POST, 'height', FILTER_VALIDATE_FLOAT);
    $weight = filter_input(INPUT_POST, 'weight', FILTER_VALIDATE_FLOAT);
    $activity = htmlspecialchars($_POST['activity'] ?? '', ENT_QUOTES, 'UTF-8');
    $pregnant = htmlspecialchars($_POST['pregnant'] ?? '', ENT_QUOTES, 'UTF-8');
    $preferences = htmlspecialchars($_POST['preferences'] ?? '', ENT_QUOTES, 'UTF-8');
    $allergies = htmlspecialchars($_POST['allergies'] ?? '', ENT_QUOTES, 'UTF-8');
    $dietaryRestrictions = htmlspecialchars($_POST['dietaryRestrictions'] ?? '', ENT_QUOTES, 'UTF-8');

    // Calculate Daily Calories
    $dailyCalories = calculateCalories($weight, $height, $age, $sex, $activity);

    // Prepare Meal Plan Details
    $mealPlanDetails = [
        'age' => $age,
        'sex' => $sex,
        'height' => $height,
        'weight' => $weight,
        'activity' => $activity,
        'pregnant' => $pregnant,
        'dailyCalories' => $dailyCalories,
        'preferences' => $preferences,
        'allergies' => $allergies,
        'dietaryRestrictions' => $dietaryRestrictions
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diet Management</title>
    <style>
        <?php include "../assets/css/dietmanagement.css";?>
    </style>
</head>
<body>
    <section class="layout">
        <div class="header">
            Diet Management
            <nav class="navbar">
                <?php if ($isLoggedIn): ?>
                    <li>
                <a href="../../actions/logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </li>
                <?php else: ?>
                    <a href="loginbeets.php">Login</a>
                    <a href="signupbeets.php">Sign Up</a>
                <?php endif; ?>
            </nav>
        </div>

        <div class="main">
            <?php if (!$isLoggedIn): ?>
                <div class="info">
                    <p>Please log in to access Diet Management features.</p>
                </div>
            <?php else: ?>
                <div class="form-container">
                    <h2>Create Your Personalized Food Plan</h2>
                    <form method="POST" action="">
                        <label for="age">Age:</label>
                        <input type="number" id="age" name="age" required min="0">

                        <label for="sex">Sex:</label>
                        <select id="sex" name="sex" required>
                            <option value="">Select</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select>

                        <label for="height">Height (cm):</label>
                        <input type="number" id="height" name="height" required min="0">

                        <label for="weight">Weight (kg):</label>
                        <input type="number" id="weight" name="weight" required min="0">

                        <label for="activity">Physical Activity Level:</label>
                        <select id="activity" name="activity" required>
                            <option value="">Select</option>
                            <option value="low">Low</option>
                            <option value="moderate">Moderate</option>
                            <option value="high">High</option>
                        </select>

                        <label for="pregnant">Pregnant:</label>
                        <select id="pregnant" name="pregnant" required>
                            <option value="no">No</option>
                            <option value="yes">Yes</option>
                        </select>

                        <label for="preferences">Food Preferences (optional):</label>
                        <textarea id="preferences" name="preferences" placeholder="E.g., likes spicy food, dislikes fish"></textarea>

                        <label for="allergies">Allergies and Intolerances (optional):</label>
                        <textarea id="allergies" name="allergies" placeholder="E.g., lactose intolerant, gluten allergy"></textarea>

                        <label for="dietaryRestrictions">Cultural/Religious Dietary Restrictions:</label>
                        <select id="dietaryRestrictions" name="dietaryRestrictions" required>
                            <option value="">Select</option>
                            <option value="none">None</option>
                            <option value="vegetarian">Vegetarian</option>
                            <option value="vegan">Vegan</option>
                            <option value="halal">Halal</option>
                            <option value="kosher">Kosher</option>
                        </select>

                        <button type="submit">Generate Plan</button>
                    </form>
                </div>

                <?php if (isset($mealPlanDetails)): ?>
                    <div class="recipe-suggestions" id="mealPlan">
                        <h3>Personalized Food Plan</h3>
                        <p>Based on your profile:</p>
                        <ul>
                            <li>Daily Calories: <?php echo $mealPlanDetails['dailyCalories']; ?> kcal</li>
                            <li>Age: <?php echo $mealPlanDetails['age']; ?></li>
                            <li>Sex: <?php echo $mealPlanDetails['sex']; ?></li>
                            <li>Height: <?php echo $mealPlanDetails['height']; ?> cm</li>
                            <li>Weight: <?php echo $mealPlanDetails['weight']; ?> kg</li>
                            <li>Activity Level: <?php echo $mealPlanDetails['activity']; ?></li>
                            <li>Pregnant: <?php echo $mealPlanDetails['pregnant']; ?></li>
                            <li>Dietary Restrictions: <?php echo $mealPlanDetails['dietaryRestrictions']; ?></li>
                        </ul>

                        <h4>Nutritional Recommendations:</h4>
                        <p>Suggested Meal Plan:</p>
                        <ul>
                            <li>Aim for balanced portions of lean proteins, healthy fats, and complex carbs</li>
                            <li>Include low glycemic index foods, whole grains, and vegetables</li>
                            <li>Adjust according to dietary preferences and restrictions</li>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="footer">
            © 2024 Diet Management
        </div>
    </section>
</body>
</html>

<?php
// Close database connection
$conn->close();
?>