<?php

// Initialize session and check for user data
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Load the database configuration file
$config_file = '../db/config.php';
if (file_exists($config_file)) {
    include $config_file;
} else {
    error_log("Database configuration file missing");
    die("System configuration error. Please contact support.");
}

$user_id = 1; // Example user ID (replace with session-based user ID)

// Variables for messages
$success_message = $error_message = '';
$water_intake_today = 0; // Track water intake for the day

// Initialize water intake if not set
if (!isset($_SESSION['water_intake_today'])) {
    $_SESSION['water_intake_today'] = 0;
}

// Reset water intake at the start of each day
if (!isset($_SESSION['last_intake_date']) || $_SESSION['last_intake_date'] != date('Y-m-d')) {
    $_SESSION['water_intake_today'] = 0;
    $_SESSION['last_intake_date'] = date('Y-m-d');
}

$water_intake_today = $_SESSION['water_intake_today'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_medication'])) {
        $medication = mysqli_real_escape_string($conn, $_POST['medication']);
        $dosage = mysqli_real_escape_string($conn, $_POST['dosage']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);

        $query = "INSERT INTO medications (name, dosage, description) VALUES ('$medication', '$dosage', '$description')";
        $success_message = mysqli_query($conn, $query) ? "Medication added successfully!" : "Error: " . mysqli_error($conn);
    } elseif (isset($_POST['add_reminder'])) {
        $medication_id = mysqli_real_escape_string($conn, $_POST['medication_id']);
        $reminder_time = mysqli_real_escape_string($conn, $_POST['reminder_time']);
        $frequency = mysqli_real_escape_string($conn, $_POST['frequency']);

        $query = "INSERT INTO med_reminders (user_id, medication_id, reminder_time, frequency) VALUES ($user_id, $medication_id, '$reminder_time', '$frequency')";
        $success_message = mysqli_query($conn, $query) ? "Reminder added successfully!" : "Error: " . mysqli_error($conn);
    } elseif (isset($_POST['add_water_intake'])) {
        $_SESSION['water_intake_today']++;
        $water_intake_today = $_SESSION['water_intake_today'];
        $success_message = "You've had $water_intake_today glass(es) of water today!";
    }
}

// Fetch medications
$medications = [];
$query = "SELECT * FROM medications ORDER BY name ASC";
$result = mysqli_query($conn, $query);
$medications = $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];

// Fetch reminders
$reminders = [];
$query = "
    SELECT r.reminder_id, r.reminder_time, r.frequency, m.name AS medication_name, m.dosage
    FROM med_reminders r
    JOIN medications m ON r.medication_id = m.medication_id
    WHERE r.user_id = $user_id";
$result = mysqli_query($conn, $query);
$reminders = $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];

// Health tips
$health_tips = [
    "Drink at least 2 liters of water daily to stay hydrated.",
    "Eat a balanced diet with fruits and vegetables.",
    "Exercise for at least 30 minutes daily.",
    "Get enough sleep; aim for 7-8 hours each night.",
    "Practice stress management through yoga or meditation.",
    "Avoid smoking and limit alcohol consumption.",
    "Take regular breaks if working long hours.",
    "Keep your surroundings clean for better mental health."
];

$current_tip_index = $_POST['current_tip'] ?? 0;
$next_tip_index = ($current_tip_index + 1) % count($health_tips);
$current_tip = $health_tips[$current_tip_index];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/medicalTracking.css">
    <title>Medication Tracking</title>
</head>
<body>
    <div class="container">
        <div class="top-bar">
        <li>
                <a href="../../actions/logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </li>
            <a href="../view/services.php" class="back-button">← Back to Services</a>
            <div></div> <!-- Empty div for flex spacing -->
        </div>
        <!-- Medication Section -->
        <div class="medication-section">
            <h2>Track Your Medications</h2>
            <form method="POST" action="">
                <label for="medication">Medication:</label>
                <input type="text" id="medication" name="medication" required>
                <label for="dosage">Dosage:</label>
                <input type="text" id="dosage" name="dosage" required>
                <label for="description">Description:</label>
                <textarea id="description" name="description"></textarea>
                <button type="submit" name="add_medication">Add Medication</button>
            </form>

            <h3>Medication List:</h3>
            <ul>
                <?php foreach ($medications as $med): ?>
                    <li><?= htmlspecialchars($med['name']) ?> - <?= htmlspecialchars($med['dosage']) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Reminders Section -->
        <div class="reminder-section">
            <h2>Add Reminders</h2>
            <form method="POST" action="">
                <label for="medication_id">Medication:</label>
                <select id="medication_id" name="medication_id" required>
                    <?php foreach ($medications as $med): ?>
                        <option value="<?= $med['medication_id'] ?>"><?= htmlspecialchars($med['name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <label for="reminder_time">Reminder Time:</label>
                <input type="time" id="reminder_time" name="reminder_time" required>
                <label for="frequency">Frequency:</label>
                <input type="text" id="frequency" name="frequency" required placeholder="e.g., daily, weekly">
                <button type="submit" name="add_reminder">Add Reminder</button>
            </form>

            <h3>Reminders List:</h3>
            <ul>
                <?php foreach ($reminders as $reminder): ?>
                    <li><?= htmlspecialchars($reminder['medication_name']) ?> - <?= htmlspecialchars($reminder['reminder_time']) ?> (<?= htmlspecialchars($reminder['frequency']) ?>)</li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Water Intake Section -->
        <div class="water-intake-section">
            <h2>Water Intake Tracker</h2>
            <form method="POST" action="">
                <button type="submit" name="add_water_intake">Add Water Intake</button>
            </form>
            <p>You have drunk <?= $water_intake_today ?> glasses of water today.</p>
        </div>

        <!-- Health Tip Section -->
        <div class="health-tips-section">
            <h2>Health Tip of the Day</h2>
            <p><?= $current_tip ?></p>
            <form method="POST" action="">
                <input type="hidden" name="current_tip" value="<?= $next_tip_index ?>">
                <button type="submit">Next Tip</button>
            </form>
        </div>
    </div>
</body>
</html>
