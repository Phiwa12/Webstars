<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: loginbeets.php');
    exit();
}

$userName = htmlspecialchars($_SESSION['fname'] ?? 'Guest');
$userRole = $_SESSION['role'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BEETS Services</title>
    <link rel="stylesheet" href="https://cdn.lineicons.com/2.0/LineIcons.css">
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            margin: 0;
            padding: 20px;
            background-color: white;
        }

        .welcome-message {
            text-align: center;
            color: #ac4800;
            margin-bottom: 30px;
            font-size: 40px;
        }

        .layout {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .layout div {
            background-color: #e2e5de;
            height: 70px;
            padding: 30px;
            border-radius: 8px;
            text-align: center;
            transition: transform 0.3s ease;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }

        .layout div:hover {
            transform: scale(1.05);
        }

        .layout a {
            text-decoration: none;
            color: #ac4800;
            font-size: 18px;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .layout a:hover {
            text-decoration: underline;
        }

        .admin-section {
            margin-top: 30px;
            border-top: 2px solid #ac4800;
            padding-top: 20px;
        }

        .admin-section h2 {
            color: #ac4800;
            text-align: center;
            margin-bottom: 20px;
        }

        .logout-btn {
            background-color: #fff0f0 !important;
        }

        .logout-btn a {
            color: #ff4444 !important;
        }
    </style>
</head>
<body>
    <div class="welcome-message">
        Welcome <?php echo $userName; ?>! Explore our services
    </div>

    <!-- User Services Section -->
    <section class="layout">
        <div>
            <a href="user_dashboard.php">
                <i class="lni lni-dashboard"></i> My Dashboard
            </a>
        </div>
        
        <div>
            <a href="resources.php">
                <i class="lni lni-book"></i> Resources
            </a>
        </div>
        
        <div>
            <a href="communityforum.php">
                <i class="lni lni-comments"></i> Community Forum
            </a>
        </div>
        
        <div>
            <a href="dietmanagement.php">
                <i class="lni lni-restaurant"></i> Diet Management
            </a>
        </div>
        
        <div>
            <a href="exercisePlanning.php">
                <i class="lni lni-heart"></i> Exercise Planning
            </a>
        </div>
        
        <div>
            <a href="progressTracking.php">
                <i class="lni lni-graph"></i> Progress Tracking
            </a>
        </div>
    </section>

    <?php if ($userRole <= 2): // Admin and Super Admin section ?>
    <div class="admin-section">
        <h2>Administration</h2>
        <section class="layout">
            <div>
                <a href="AnalyticsReporting.php">
                    <i class="lni lni-dashboard"></i> Admin Analytics
                </a>
            </div>
            
            <div>
                <a href="forumModeration.php">
                    <i class="lni lni-shield"></i> Forum Moderation
                </a>
            </div>

            <div>
                <a href="resource_management.php">
                    <i class="lni lni-library"></i> Resource Management
                </a>
            </div>

            <div>
                <a href="healthcareProvider.php">
                    <i class="lni lni-hospital"></i> Healthcare Provider
                </a>
            </div>

            <?php if ($userRole <= 2): // Both Super Admin (1) and Admin (2) can access ?>
    <div>
        <a href="user_management.php">
            <i class="lni lni-users"></i> User Management
        </a>
    </div>
    <div>
        <a href="admin/admin_dashboard.php"> 
            <i class="lni lni-dashboard"></i> Admin Dashboard
        </a>
    </div>
<?php endif; ?>
        </section>
    </div>
    <?php endif; ?>

    <!-- Logout Button -->
    <section class="layout" style="margin-top: 20px;">
        <div class="logout-btn">
            <a href="../actions/logout.php">
                <i class="lni lni-exit"></i> Logout
            </a>
        </div>
    </section>
</body>
</html>