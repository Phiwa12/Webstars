<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Debug information
echo "<div style='background: #f0f0f0; padding: 10px; margin: 10px;'>";
echo "Current File: " . __FILE__ . "<br>";
echo "Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "<br>";
echo "Script Name: " . $_SERVER['SCRIPT_NAME'] . "<br>";
echo "Request URI: " . $_SERVER['REQUEST_URI'] . "<br>";
echo "<br>Session Data:<br>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";
echo "</div>";

require_once '../../functions/auth_functions.php';
require_once '../../functions/admin_function.php';
require_once '../../db/config.php';


// Log access attempt
error_log("Admin dashboard access attempt - User Role: " . ($_SESSION['role'] ?? 'none'));

if (!isset($_SESSION['user_id']) || $_SESSION['role'] > 2) {
    error_log("Access denied - User ID: " . ($_SESSION['user_id'] ?? 'none') . ", Role: " . ($_SESSION['role'] ?? 'none'));
    header('Location: ../unauthorized.php');
    exit();
}


/// Set up variables
$userRole = $_SESSION['role'];
$isSuperAdmin = ($userRole === 1);
$isAdmin = ($userRole === 2);
$adminName = $_SESSION['fname'] . ' ' . $_SESSION['lname'];

// Initialize variables with default values
$searchTerm = $_GET['search'] ?? '';
$roleFilter = $_GET['role'] ?? '';
$statusFilter = $_GET['status'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));

// Fetch filtered users and total user count
$users = getFilteredUsers($searchTerm, $roleFilter, $statusFilter, $page);
$totalUsers = getTotalUsers($searchTerm, $roleFilter, $statusFilter);

// Fetch roles for role filter
$roles = getAllRoles();


// Function to get dashboard statistics
function getDashboardStatistics() {
    global $conn;
    
    $stats = array();
    
    // Get total users
    $query = "SELECT COUNT(*) as total FROM beets_users";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $stats['total_users'] = $row['total'];
    
    // Get active users in last 24 hours
    $query = "SELECT COUNT(DISTINCT user_id) as active FROM user_activity WHERE timestamp > DATE_SUB(NOW(), INTERVAL 24 HOUR)";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $stats['active_users_24h'] = $row['active'] ?? 0;
    
    // Get new users this week
    $query = "SELECT COUNT(*) as new_users FROM beets_users WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 WEEK)";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $stats['new_users_week'] = $row['new_users'];
    
    // Get forum stats
    $query = "SELECT COUNT(*) as total FROM stories";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $stats['total_posts'] = $row['total'];
    
    return $stats;
}

// Function to get recent activities
function getRecentActivities() {
    global $conn;
    
    $activities = array();
    
    $query = "SELECT * FROM beets_users ORDER BY created_at DESC LIMIT 5";
    $result = mysqli_query($conn, $query);
    
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $activities[] = array(
                'icon' => 'fas fa-user-plus',
                'description' => "New user registered: " . htmlspecialchars($row['fname']) . " " . htmlspecialchars($row['lname']),
                'created_at' => $row['created_at']
            );
        }
    }
    
    return $activities;
}

// Get dashboard data
$dashboardStats = getDashboardStatistics();
$recentActivities = getRecentActivities();

// Helper function for time ago format
function formatTimeAgo($timestamp) {
    $datetime = new DateTime($timestamp);
    $now = new DateTime();
    $interval = $now->diff($datetime);
    
    if ($interval->y > 0) return $interval->y . ' years ago';
    if ($interval->m > 0) return $interval->m . ' months ago';
    if ($interval->d > 0) return $interval->d . ' days ago';
    if ($interval->h > 0) return $interval->h . ' hours ago';
    if ($interval->i > 0) return $interval->i . ' minutes ago';
    return 'Just now';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - BEETS</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin_dashboard.css">
    <style>
        .sidebar {
            min-height: calc(100vh - 4rem);
            background-color: #1a1a1a;
        }
        .nav-link {
            color: #ffffff;
            padding: 1rem;
            display: flex;
            align-items: center;
            transition: background-color 0.3s;
        }
        .nav-link:hover {
            background-color: #333333;
        }
        .nav-link i {
            margin-right: 0.75rem;
        }
        .active {
            background-color: #ac4800;
        }
        .stats-card {
            transition: transform 0.3s;
        }
        .stats-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Top Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-50">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-2xl font-bold text-ac4800">BEETS Admin</h1>
                </div>
                <div class="flex items-center gap-4">
                    <span class="text-gray-600">
                        Welcome, <?php echo $userName; ?>
                        (<?php echo $userRole; ?>)
                    </span>
                    <a href="../actions/logout.php" class="text-red-600 hover:text-red-800">
    <i class="fas fa-sign-out-alt"></i> Logout
</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="flex pt-16">
        <!-- Sidebar -->
        <div class="w-64 fixed sidebar">
            <nav class="mt-5">
                <a href="admin_dashboard.php" class="nav-link active">
                    <i class="fas fa-chart-bar"></i>
                    Dashboard
                    </a>
                
                    <a href="../AnalyticsReporting.php" class="nav-link">
                    <i class="fas fa-chart-line"></i>
                    Analytics & Reporting
                </a>

                <?php if ($isSuperAdmin): ?>
                <a href="../user_management.php" class="nav-link">
                    <i class="fas fa-users"></i>
                    User Management
                </a>
                <?php endif; ?>

                <a href="../forumModeration.php" class="nav-link">
                    <i class="fas fa-comments"></i>
                    Forum Moderation
                </a>

                <a href="../healthcareProvider.php" class="nav-link">
                    <i class="fas fa-heart"></i>
                    Healthcare Provider
                </a>

                <a href="../resource_management.php" class="nav-link">
                    <i class="fas fa-book"></i>
                    Resource Management
                </a>
            </nav>
        </div>

        <!-- Content Area -->
        <div class="ml-64 w-full p-8">
            <!-- Stats Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <!-- Total Users Card -->
                <div class="bg-white rounded-lg shadow p-6 stats-card">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-blue-100">
                            <i class="fas fa-users text-blue-500 text-xl"></i>
                        </div>
                        <div class="mx-4">
                            <h4 class="text-2xl font-semibold">
                                <?php echo number_format($dashboardStats['total_users']); ?>
                            </h4>
                            <p class="text-gray-600">Total Users</p>
                        </div>
                    </div>
                </div>

                <!-- Active Users Card -->
                <div class="bg-white rounded-lg shadow p-6 stats-card">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-green-100">
                            <i class="fas fa-user-clock text-green-500 text-xl"></i>
                        </div>
                        <div class="mx-4">
                            <h4 class="text-2xl font-semibold">
                                <?php echo number_format($dashboardStats['active_users_24h']); ?>
                            </h4>
                            <p class="text-gray-600">Active Users (24h)</p>
                        </div>
                    </div>
                </div>

                <!-- Forum Posts Card -->
                <div class="bg-white rounded-lg shadow p-6 stats-card">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-purple-100">
                            <i class="fas fa-comments text-purple-500 text-xl"></i>
                        </div>
                        <div class="mx-4">
                            <h4 class="text-2xl font-semibold">
                                <?php echo number_format($dashboardStats['total_posts']); ?>
                            </h4>
                            <p class="text-gray-600">Total Posts</p>
                        </div>
                    </div>
                </div>

                <!-- New Users Card -->
                <div class="bg-white rounded-lg shadow p-6 stats-card">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-yellow-100">
                            <i class="fas fa-user-plus text-yellow-500 text-xl"></i>
                        </div>
                        <div class="mx-4">
                            <h4 class="text-2xl font-semibold">
                                <?php echo number_format($dashboardStats['new_users_week']); ?>
                            </h4>
                            <p class="text-gray-600">New Users (Week)</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Activity Section -->
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-xl font-semibold mb-4">Recent Activity</h3>
                <div class="space-y-4">
                    <?php foreach ($recentActivities as $activity): ?>
                    <div class="flex items-start border-b border-gray-100 pb-4">
                        <div class="p-2 rounded-full bg-gray-100">
                            <i class="<?php echo $activity['icon']; ?> text-gray-500"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-gray-700"><?php echo $activity['description']; ?></p>
                            <span class="text-sm text-gray-500">
                                <?php echo formatTimeAgo($activity['created_at']); ?>
                            </span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize any components or add event listeners
    });
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>

    <script src="../assets/js/admin_dashboard.js"></script>
</body>
</html>