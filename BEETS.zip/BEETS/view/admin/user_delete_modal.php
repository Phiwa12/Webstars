<div id="deleteUserModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title text-danger">Delete User</h3>
            <button type="button" class="modal-close" onclick="closeModal('deleteUserModal')">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal-body">
            <div class="text-center">
                <i class="fas fa-exclamation-triangle text-warning text-5xl mb-4"></i>
                <h4 class="text-lg font-semibold mb-2">Are you sure you want to delete this user?</h4>
                <p class="text-gray-600">
                    This action cannot be undone. All data associated with this user will be permanently deleted.
                </p>
                <div class="mt-4 p-4 bg-gray-50 rounded-lg">
                    <p class="font-medium" id="deleteUserName"></p>
                    <p class="text-gray-500" id="deleteUserEmail"></p>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn-secondary" onclick="closeModal('deleteUserModal')">Cancel</button>
            <button type="button" class="btn-danger" onclick="handleDeleteUser()">
                <i class="fas fa-trash"></i> Delete User
            </button>
        </div>
    </div>
</div>