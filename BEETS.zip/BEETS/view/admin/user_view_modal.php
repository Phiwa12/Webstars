<div id="viewUserModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">User Details</h3>
            <button type="button" class="modal-close" onclick="closeModal('viewUserModal')">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal-body">
            <!-- User Profile Section -->
            <div class="user-profile">
                <img src="" alt="User Avatar" id="viewUserAvatar" class="user-avatar">
                <div class="user-info">
                    <h4 class="user-name" id="viewUserName"></h4>
                    <p class="user-email" id="viewUserEmail"></p>
                    <div class="flex gap-2">
                        <span class="role-badge" id="viewUserRole"></span>
                        <span class="status-badge" id="viewUserStatus"></span>
                    </div>
                </div>
            </div>

            <!-- Tabs for different sections -->
            <div class="tabs">
                <button class="tab-btn active" onclick="switchTab('details')">Details</button>
                <button class="tab-btn" onclick="switchTab('medical')">Medical History</button>
                <button class="tab-btn" onclick="switchTab('activity')">Activity Log</button>
            </div>

            <!-- Details Tab -->
            <div id="detailsTab" class="tab-content active">
                <div class="info-grid">
                    <div class="info-item">
                        <span class="info-label">Member Since</span>
                        <span class="info-value" id="viewUserJoinDate"></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Last Login</span>
                        <span class="info-value" id="viewUserLastLogin"></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Phone</span>
                        <span class="info-value" id="viewUserPhone"></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Location</span>
                        <span class="info-value" id="viewUserLocation"></span>
                    </div>
                </div>
            </div>

            <!-- Medical History Tab -->
            <div id="medicalTab" class="tab-content">
                <div class="medical-history">
                    <div class="medical-info">
                        <h5>Diabetes Type</h5>
                        <p id="viewUserDiabetesType"></p>
                    </div>
                    <div class="medical-info">
                        <h5>Diagnosis Date</h5>
                        <p id="viewUserDiagnosisDate"></p>
                    </div>
                    <div class="medical-info">
                        <h5>Current Medications</h5>
                        <ul id="viewUserMedications"></ul>
                    </div>
                    <div class="medical-info">
                        <h5>Recent Blood Sugar Readings</h5>
                        <div id="bloodSugarChart" class="chart-container"></div>
                    </div>
                </div>
            </div>

            <!-- Activity Log Tab -->
            <div id="activityTab" class="tab-content">
                <div class="activity-log" id="userActivityLog"></div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn-secondary" onclick="closeModal('viewUserModal')">Close</button>
            <button type="button" class="btn-primary" onclick="editUser(currentUserId)">
                <i class="fas fa-edit"></i> Edit User
            </button>
        </div>
    </div>
</div>