<?php
session_start();
require_once '../functions/auth_functions.php';
require_once '../db/config.php';

// Check authentication
if (!isLoggedIn()) {
    header('Location: loginbeets.php');
    exit();
}

$userRole = $_SESSION['role'] ?? 0;
$isSuperAdmin = ($userRole == 1);
$isAdmin = ($userRole == 2);

// Fetch resources from database
$query = "SELECT * FROM educational_resources ORDER BY category, title";
$resources = mysqli_query($conn, $query);

// Group resources by category
$groupedResources = [];
while ($row = mysqli_fetch_assoc($resources)) {
    $groupedResources[$row['category']][] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resources - BEETS</title>
    <link rel="stylesheet" href="../assets/css/Resources.css">
    <link rel="stylesheet" href="https://cdn.lineicons.com/2.0/LineIcons.css">
</head>
<body>
    <div class="page-container">
        <nav class="navigation">
            <a href="services.php" class="back-btn">
                <i class="lni lni-arrow-left"></i> Back to Services
            </a>
            <?php if ($isAdmin || $isSuperAdmin): ?>
                <a href="admin/resource_management.php" class="admin-btn">
                    <i class="lni lni-cog"></i> Manage Resources
                </a>
            <?php endif; ?>
        </nav>

        <header>
            <h1>Resources</h1>
            <div class="search-box">
                <input type="text" id="searchInput" placeholder="Search resources...">
                <i class="lni lni-search-alt"></i>
            </div>
        </header>

        <section class="articles-section">
            <?php foreach ($groupedResources as $category => $articles): ?>
                <h2><?php echo htmlspecialchars($category); ?></h2>
                <?php foreach ($articles as $index => $article): ?>
                    <div class="article" data-id="<?php echo $article['resource_id']; ?>">
                        <h3><?php echo htmlspecialchars($article['title']); ?></h3>
                        <p class="article-content hidden">
                            <?php echo nl2br(htmlspecialchars($article['content'])); ?>
                        </p>
                    </div>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </section>

        <section class="tips-section">
            <h2>Quick Tips</h2>
            <ul>
                <li>Stay hydrated with water throughout the day.</li>
                <li>Eat fiber-rich foods to help manage blood sugar levels.</li>
                <li>Incorporate light exercise daily for better circulation.</li>
                <li>Monitor your blood sugar levels regularly.</li>
            </ul>
        </section>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle article content
        document.querySelectorAll('.article').forEach(article => {
            article.addEventListener('click', function() {
                const content = this.querySelector('.article-content');
                content.classList.toggle('hidden');
            });
        });

        // Search functionality
        const searchInput = document.getElementById('searchInput');
        searchInput.addEventListener('input', function() {
            const searchText = this.value.toLowerCase();
            document.querySelectorAll('.article').forEach(article => {
                const title = article.querySelector('h3').textContent.toLowerCase();
                const content = article.querySelector('.article-content').textContent.toLowerCase();
                
                if (title.includes(searchText) || content.includes(searchText)) {
                    article.style.display = 'block';
                } else {
                    article.style.display = 'none';
                }
            });
        });
    });
    </script>
</body>
</html>
