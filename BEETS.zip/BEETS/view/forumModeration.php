<?php
// Initialize session and check for user data
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Assume we have user role stored in session
$userRole = $_SESSION['user_role'] ?? 0; // Default to 0 if not set

// Function to check if user has required role
function hasAccess($requiredRole) {
    global $userRole;
    return $userRole >= $requiredRole;
}

// Load the database configuration file
$config_file = '../db/config.php';
if (file_exists($config_file)) {
    include $config_file;
} else {
    error_log("Database configuration file missing");
    die("System configuration error. Please contact support.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum Moderation Panel</title>
    <style>
        <?php include "../assets/css/forumModeration.css"; ?>
    </style>
</head>
<body>
    <header class="header">
        <div class="top-bar">
            <a href="../view/services.php" class="back-button">← Back to Services</a>
            <div></div> <!-- Empty div for flex spacing -->
            <li>
                <a href="../../actions/logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </li>
        </div>
        <h1>Forum Moderation Panel</h1>
        <p>Welcome, <?php echo $_SESSION['fname'] ?? 'Moderator'; ?></p>
    </header>

    <nav class="nav">
        <ul class="nav-list">
            <li><a href="#posts">Posts</a></li>
            <li><a href="#reports">Reports</a></li>
            <?php if ($userRole == 1): ?>
            <li><a href="#users">Users</a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <main class="container">
        <?php if ($userRole == 1): // Super Admin ?>
            <div class="mod-tools">
                <h2>Moderation Tools</h2>
                <button class="tool-button">View All Posts</button>
                <button class="tool-button">User Reports</button>
                <button class="tool-button">Flagged Content</button>
                <button class="tool-button">Pinned Discussions</button>
            </div>

            <!-- All users' posts section -->
            <section id="posts">
                <h2>All Forum Posts</h2>
                <!-- Example post -->
                <?php
                // Fetch all posts
                $query = "SELECT st.content, st.created_at, bu.fname AS poster_name 
                        FROM stories st 
                        JOIN beets_users bu ON fp.user_id = bu.user_id";
                $result = $conn->query($query);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <div class="post">
                            <div class="post-actions">
                                <span class="flag-btn" title="Flag content">🚩</span>
                                <span class="pin-btn" title="Pin post">📌</span>
                            </div>
                            <p><?= nl2br(htmlspecialchars($row['content'])); ?></p>
                            <small>Posted by: <?= htmlspecialchars($row['poster_name']); ?> on <?= htmlspecialchars($row['created_at']); ?></small>
                        </div>
                        <?php
                    }
                } else {
                    echo "<p>No posts available.</p>";
                }
                ?>
            </section>


        <?php else: // Regular Admin ?>
            <div class="mod-tools">
                <h2>Moderation Tools</h2>
                <button class="tool-button">View My Posts</button>
                <button class="tool-button">Flagged Content</button>
                <button class="tool-button">Pinned Discussions</button>
            </div>

            <!-- User's own posts section -->
            <section id="posts">
            <h2>My Posts</h2>
            <?php
                $user_id = $_SESSION['user_id']; // Assuming the logged-in user's ID is stored in session

                // Fetch posts for the logged-in user
                // Change your retrieval query to use the stories table
                $query = "SELECT id, content, created_at FROM stories WHERE user_id = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <div class="post">
                            <div class="post-actions">
                                <span class="flag-btn" title="Flag content">🚩</span>
                                <span class="pin-btn" title="Pin post">📌</span>
                            </div>
                            <p><?= nl2br(htmlspecialchars($row['content'])); ?></p>
                            <small>Posted on: <?= htmlspecialchars($row['created_at']); ?></small>
                        </div>
                        <?php
                    }
                } else {
                    echo "<p>No posts yet.</p>";
                }
            ?>
            </section>
        <?php endif; ?>

        <?php
        // Include database connection
        require_once '../db/config.php'; // Update the path to your connection file
        
        if (!defined('MAX_MESSAGE_LENGTH')) {
            define('MAX_MESSAGE_LENGTH', 255);
        }
        
        if (!defined('ADMIN_EMAIL')) {
            define('ADMIN_EMAIL', 'admin@example.com');
        }
        
        // Fetch reported stories from the stories table
        $query = "SELECT id,  content, created_at FROM stories WHERE is_reported = 1";
        $result = $conn->query($query);
        ?>

        <!-- Shared functionality for both roles -->
        <section id="reports">
            <h2>Content Reports</h2>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="post">
                            <div class="post-actions">
                                <form method="post" action="review_or_dismiss.php" style="display: inline;">
                                    <input type="hidden" name="story_id" value="<?= htmlspecialchars($row['story_id']); ?>">
                                    <button type="submit" name="action" value="review" class="tool-button">Review</button>
                                    <button type="submit" name="action" value="dismiss" class="tool-button">Dismiss</button>
                                </form>
                            </div>
                        <p><?= nl2br(htmlspecialchars($row['content'])); ?></p>
                        <small>Reported on: <?= htmlspecialchars($row['created_at']); ?></small>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No reported content at the moment.</p>
            <?php endif; ?>
        </section>

    </main>

    <?php
    // Process form submissions would go here
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['flag_post'])) {
            // Handle flagging
        } elseif (isset($_POST['pin_post'])) {
            // Handle pinning
        }
    }
    ?>
</body>
</html>