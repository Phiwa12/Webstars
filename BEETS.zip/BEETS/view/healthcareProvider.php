<?php
// Initialize session and check for user data
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Load the database configuration file
$config_file = '../db/config.php';
if (file_exists($config_file)) {
    include $config_file;
} else {
    error_log("Database configuration file missing");
    die("System configuration error. Please contact support.");
}

// Add this function at the top of your file
function scheduleConsultation($conn) {
    $provider_id = mysqli_real_escape_string($conn, $_POST['provider_id']);
    $patient_id = mysqli_real_escape_string($conn, $_POST['patient_id']);
    $consultation_date = mysqli_real_escape_string($conn, $_POST['consultation_date']);
    
    // Check if the provider is available at the selected time
    $check_availability = "SELECT * FROM consultations 
                         WHERE provider_id = '$provider_id' 
                         AND consultation_date = '$consultation_date'
                         AND status != 'Cancelled'";
    $result = mysqli_query($conn, $check_availability);
    
    if (mysqli_num_rows($result) > 0) {
        $_SESSION['error'] = "Provider is not available at the selected time. Please choose a different time.";
        return false;
    }
    
    // Insert the consultation with initial status as 'Pending'
    $query = "INSERT INTO consultations (provider_id, patient_id, consultation_date, status, created_at) 
              VALUES ('$provider_id', '$patient_id', '$consultation_date', 'Pending', NOW())";
    
    if (mysqli_query($conn, $query)) {
        $consultation_id = mysqli_insert_id($conn);
        
        // Get provider and patient details for notification
        $provider_query = "SELECT bu.email, bu.fname, bu.lname 
                          FROM healthcare_providers hp 
                          JOIN beets_users bu ON hp.user_id = bu.user_id 
                          WHERE hp.provider_id = '$provider_id'";
        $provider_result = mysqli_query($conn, $provider_query);
        $provider = mysqli_fetch_assoc($provider_result);
        
        $patient_query = "SELECT email, fname, lname FROM beets_users WHERE user_id = '$patient_id'";
        $patient_result = mysqli_query($conn, $patient_query);
        $patient = mysqli_fetch_assoc($patient_result);
        
        // Insert notification for provider
        $provider_notification = "INSERT INTO notifications (user_id, type, message, related_id, created_at) 
                                VALUES (
                                    '$provider_id',
                                    'consultation_scheduled',
                                    'New consultation scheduled with {$patient['fname']} {$patient['lname']} on " . date('Y-m-d H:i', strtotime($consultation_date)) . "',
                                    '$consultation_id',
                                    NOW()
                                )";
        mysqli_query($conn, $provider_notification);
        
        // Insert notification for patient
        $patient_notification = "INSERT INTO notifications (user_id, type, message, related_id, created_at) 
                               VALUES (
                                   '$patient_id',
                                   'consultation_scheduled',
                                   'Consultation scheduled with Dr. {$provider['fname']} {$provider['lname']} on " . date('Y-m-d H:i', strtotime($consultation_date)) . "',
                                   '$consultation_id',
                                   NOW()
                               )";
        mysqli_query($conn, $patient_notification);
        
        // Send email notifications (you'll need to implement your email sending function)
        $provider_email_content = "Dear Dr. {$provider['fname']} {$provider['lname']},\n\n";
        $provider_email_content .= "A new consultation has been scheduled with {$patient['fname']} {$patient['lname']} ";
        $provider_email_content .= "on " . date('Y-m-d H:i', strtotime($consultation_date)) . ".\n\n";
        $provider_email_content .= "Please login to your dashboard to view the details.";
        
        $patient_email_content = "Dear {$patient['fname']} {$patient['lname']},\n\n";
        $patient_email_content .= "Your consultation with Dr. {$provider['fname']} {$provider['lname']} ";
        $patient_email_content .= "has been scheduled for " . date('Y-m-d H:i', strtotime($consultation_date)) . ".\n\n";
        $patient_email_content .= "Please login to your dashboard to view the details.";
        
        // Send emails (implement your email sending function)
        // mail($provider['email'], 'New Consultation Scheduled', $provider_email_content);
        // mail($patient['email'], 'Consultation Confirmation', $patient_email_content);
        
        $_SESSION['success'] = "Consultation scheduled successfully. Notifications have been sent to both parties.";
        return true;
    } else {
        $_SESSION['error'] = "Error scheduling consultation: " . mysqli_error($conn);
        return false;
    }
}
// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'schedule_consultation':
                scheduleConsultation($conn);
                // Redirect to prevent form resubmission
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            case 'add_provider':
                $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
                $specialization = mysqli_real_escape_string($conn, $_POST['specialization']);
                $license = mysqli_real_escape_string($conn, $_POST['license']);
                
                $query = "INSERT INTO healthcare_providers (user_id, specialization, license_number) VALUES ('$user_id', '$specialization', '$license')";
                mysqli_query($conn, $query);
                break;
                
            case 'assign_patient':
                $provider_id = mysqli_real_escape_string($conn, $_POST['provider_id']);
                $patient_id = mysqli_real_escape_string($conn, $_POST['patient_id']);
                
                $query = "INSERT INTO provider_patient_assignments (provider_id, patient_id) VALUES ('$provider_id', '$patient_id')";
                mysqli_query($conn, $query);
                break;
                
            case 'schedule_consultation':
                $provider_id = mysqli_real_escape_string($conn, $_POST['provider_id']);
                $patient_id = mysqli_real_escape_string($conn, $_POST['patient_id']);
                $consultation_date = mysqli_real_escape_string($conn, $_POST['consultation_date']);
                
                $query = "INSERT INTO consultations (provider_id, patient_id, consultation_date) VALUES ('$provider_id', '$patient_id', '$consultation_date')";
                mysqli_query($conn, $query);
                break;
        }
    }
}

// Fetch providers with their metrics
$query = "
    SELECT hp.*, bu.fname, bu.lname, bu.email,
    (SELECT COUNT(*) FROM provider_patient_assignments WHERE provider_id = hp.provider_id) as patient_count,
    (SELECT COUNT(*) FROM consultations WHERE provider_id = hp.provider_id AND status = 'Completed') as completed_consultations
    FROM healthcare_providers hp
    JOIN beets_users bu ON hp.user_id = bu.user_id
";
$result = mysqli_query($conn, $query);
$providers = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Get total consultations for metrics
$query = "SELECT COUNT(*) as total FROM consultations WHERE status = 'Completed'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$totalConsultations = $row['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare Provider Management</title>
    <style>
        <?php include "../assets/css/healthcareProvider.css"; ?>
    </style>
</head>
<body>
    <div class="messages">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($_SESSION['success']); ?>
                <?php unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($_SESSION['error']); ?>
                <?php unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>
    </div>
    <div class="container">
    <div class="top-bar">
    <li>
                <a href="../../actions/logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </li>
            <a href="../view/services.php" class="back-button">← Back to Services</a>
            <div></div> <!-- Empty div for flex spacing -->
        </div>
        <div class="header">
            <h1>Healthcare Provider Management</h1>
        </div>

        <div class="grid">
            <!-- Add Provider Form -->
            <div class="card">
                <h2>Add New Provider</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="add_provider">
                    <div class="form-group">
                        <label>Select User</label>
                        <select name="user_id" class="form-control" required>
                            <?php
                            $users_query = "SELECT user_id, fname, lname FROM beets_users WHERE role = 2";
                            $users_result = mysqli_query($conn, $users_query);
                            while ($user = mysqli_fetch_assoc($users_result)) {
                                echo "<option value='{$user['user_id']}'>{$user['fname']} {$user['lname']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Specialization</label>
                        <input type="text" name="specialization" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>License Number</label>
                        <input type="text" name="license" class="form-control" required>
                    </div>
                    <button type="submit" class="btn">Add Provider</button>
                </form>
            </div>

            <!-- Assign Patient Form -->
            <div class="card">
                <h2>Assign Patient to Provider</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="assign_patient">
                    <div class="form-group">
                        <label>Select Provider</label>
                        <select name="provider_id" class="form-control" required>
                            <?php foreach ($providers as $provider): ?>
                                <option value="<?= htmlspecialchars($provider['provider_id']) ?>">
                                    <?= htmlspecialchars($provider['fname'] . ' ' . $provider['lname']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Select Patient</label>
                        <select name="patient_id" class="form-control" required>
                            <?php
                            $patients_query = "SELECT user_id, fname, lname FROM beets_users WHERE role = 2";
                            $patients_result = mysqli_query($conn, $patients_query);
                            while ($patient = mysqli_fetch_assoc($patients_result)) {
                                echo "<option value='" . htmlspecialchars($patient['user_id']) . "'>" . 
                                     htmlspecialchars($patient['fname'] . ' ' . $patient['lname']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <button type="submit" class="btn">Assign Patient</button>
                </form>
            </div>

            <!-- Schedule Consultation -->
            <div class="card">
                <h2>Schedule Consultation</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="schedule_consultation">
                    <div class="form-group">
                        <label>Select Provider</label>
                        <select name="provider_id" class="form-control" required>
                            <?php foreach ($providers as $provider): ?>
                                <option value="<?= htmlspecialchars($provider['provider_id']) ?>">
                                    <?= htmlspecialchars($provider['fname'] . ' ' . $provider['lname']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Select Patient</label>
                        <select name="patient_id" class="form-control" required>
                            <?php
                            $patients_result = mysqli_query($conn, $patients_query);
                            while ($patient = mysqli_fetch_assoc($patients_result)) {
                                echo "<option value='" . htmlspecialchars($patient['user_id']) . "'>" . 
                                     htmlspecialchars($patient['fname'] . ' ' . $patient['lname']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Consultation Date & Time</label>
                        <input type="datetime-local" name="consultation_date" class="form-control" required>
                    </div>
                    <button type="submit" class="btn">Schedule Consultation</button>
                </form>
            </div>
        </div>

        <!-- Provider List and Metrics -->
        <div class="card">
            <h2>Healthcare Providers Overview</h2>
            <div class="metrics">
                <div class="metric-card">
                    <div class="metric-value"><?= count($providers) ?></div>
                    <div class="metric-label">Total Providers</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value"><?= $totalConsultations ?></div>
                    <div class="metric-label">Total Consultations</div>
                </div>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Specialization</th>
                        <th>License</th>
                        <th>Patients</th>
                        <th>Consultations</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($providers as $provider): ?>
                    <tr>
                        <td><?= htmlspecialchars($provider['fname'] . ' ' . $provider['lname']) ?></td>
                        <td><?= htmlspecialchars($provider['specialization']) ?></td>
                        <td><?= htmlspecialchars($provider['license_number']) ?></td>
                        <td><?= $provider['patient_count'] ?></td>
                        <td><?= $provider['completed_consultations'] ?></td>
                        <td><?= htmlspecialchars($provider['status']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>