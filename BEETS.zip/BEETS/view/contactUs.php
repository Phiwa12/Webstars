<?php
require_once '../utils/init.php';

// Initialize error message variable
$error_message = '';
$success_message = '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once '../functions/contact_handler.php';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="../assets/css/contactUs.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <?php if (!isLoggedIn()): ?>
            <a href="<?php echo APP_URL; ?>/view/loginbeets.php">Log In</a>
            <a href="<?php echo APP_URL; ?>/view/signupbeets.php">Sign Up</a>
        <?php endif; ?>
        <a href="<?php echo APP_URL; ?>/view/aboutUs.php">About Us</a>
    </nav>

    <!-- Contact Form Section -->
    <div class="contact-container">
        <div class="contact-header">Contact Us</div>
        
        <?php if (!empty($error_message)): ?>
            <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
        
        <?php if (!empty($success_message)): ?>
            <div class="success-message"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>

        <form class="contact-form" id="contactForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" placeholder="Your Name" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Your Email" required>

            <label for="message">Message</label>
            <textarea id="message" name="message" rows="4" placeholder="Your message here..." required></textarea>

            <button type="submit" name="submit">Submit</button>
        </form>
        
        <div class="contact-info">
            <p><i class="fas fa-envelope"></i>Email: beetsSupport@gmail.com</p>
            <p><i class="fas fa-phone"></i>Phone: 053456722</p>
            <p><i class="fas fa-facebook"></i>Facebook: realBeetsSupport</p>
            <p><i class="fas fa-exclamation-circle"></i>Emergency Contact: 4563</p>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        &copy; <?php echo date("Y"); ?> Beets Support. All rights reserved.
    </footer>

    <script src="../assets/js/contactUs.js"></script>
    <script>
        // Add event listeners for navigation
        document.addEventListener('DOMContentLoaded', function() {
            // Navigation handling
            const navLinks = document.querySelectorAll('nav a');
            navLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    window.location.href = this.href;
                });
            });
        });
    </script>
</body>
</html>