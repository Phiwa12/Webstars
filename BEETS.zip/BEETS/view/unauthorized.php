<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unauthorized Access - BEETS</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 h-screen flex items-center justify-center">
    <div class="bg-white p-8 rounded-lg shadow-md max-w-md w-full">
        <div class="text-center">
            <h1 class="text-2xl font-bold text-red-600 mb-4">Unauthorized Access</h1>
            <p class="text-gray-600 mb-6">
                You don't have permission to access this page.
                <?php if (!isset($_SESSION['user_id'])): ?>
                    Please log in with appropriate credentials.
                <?php else: ?>
                    Please contact an administrator if you believe this is an error.
                <?php endif; ?>
            </p>
            <div class="space-y-4">
                <?php if (!isset($_SESSION['user_id'])): ?>
                    <a href="loginbeets.php" 
                       class="block w-full bg-orange-600 text-white py-2 px-4 rounded hover:bg-orange-700 transition duration-300">
                        Login
                    </a>
                <?php endif; ?>
                <a href="services.php" 
                   class="block w-full bg-gray-200 text-gray-800 py-2 px-4 rounded hover:bg-gray-300 transition duration-300">
                    Return to Services
                </a>
            </div>
        </div>
    </div>
</body>
</html>