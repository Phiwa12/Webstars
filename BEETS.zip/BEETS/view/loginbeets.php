<?php
require_once '../db/config.php';
require_once '../functions/auth_functions.php';

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL));
    $password = trim($_POST['password']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif (empty($password)) {
        $error = "Password is required.";
    } else {
        $stmt = $conn->prepare("SELECT user_id, email, fname, lname, password, role FROM beets_users WHERE email = ?");
        if ($stmt) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                if (password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['fname'] = $user['fname'];
                    $_SESSION['lname'] = $user['lname'];
                    $_SESSION['role'] = $user['role'];
                    

                    // Always redirect to services.php after successful login
                    header("Location: services.php");
                    exit();
                } else {
                    $error = "Incorrect password.";
                }
            } else {
                $error = "Email not registered. Please sign up first.";
            }
            $stmt->close();
        } else {
            $error = "System error. Please try again later.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In - BEETS</title>
    <link rel="stylesheet" href="../assets/css/loginbeets.css">
</head>
<body>
    <div class="container">
        <div class="form-box">
            <div class="login-box form">
                <h2>Log In</h2>
                <?php if (!empty($error)): ?>
                    <p class="error-message"><?= htmlspecialchars($error) ?></p>
                <?php endif; ?>
                <form id="loginForm" method="POST" action="loginbeets.php">
                    <div class="input-box">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="Enter your email" required>
                    </div>
                    <div class="input-box">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" placeholder="Enter your password" required>
                    </div>
                    <button type="submit" class="button button1">Log In</button>
                    <div class="remember-forgot">
                        <input type="checkbox" id="chk" name="chk">
                        <label for="chk">Remember me</label>
                        <a href="#" class="forgot-link">Forgot Password?</a>
                    </div>
                    <div class="sign-up link">
                        <a href="signupbeets.php">Create a new account</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const loginForm = document.getElementById('loginForm');
        
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(loginForm);
            
            fetch('loginbeets.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                if (data.includes('success')) {
                    window.location.href = 'services.php';
                } else {
                    // If there's an error, the page will be reloaded with the error message
                    loginForm.submit();
                }
            })
            .catch(error => {
                console.error('Error:', error);
                loginForm.submit();
            });
        });
    });
    </script>
</body>
</html>