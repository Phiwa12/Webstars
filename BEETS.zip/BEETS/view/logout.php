<?php
session_start();
$userName = isset($_SESSION['fname']) ? $_SESSION['fname'] : 'Guest';

// Logout handling
if (isset($_GET['logout'])) {
    // Unset all session variables
    $_SESSION = array();

    // Destroy the session
    session_destroy();

    // Redirect to login page
    header("Location: ../index.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Layout</title>
    <!-- Include Line Awesome CDN -->
    <link rel="stylesheet" href="https://cdn.lineicons.com/2.0/LineIcons.css">
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            margin: 0;
            padding: 20px;
            background-image:url('../assets/images/orangephoto.jpg');
        }

        .welcome-message {
            text-align: center;
            color: #ac4800;
            margin-bottom: 30px;
            font-size: 40px;
        }

        .layout {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .layout div {
            background-color: #e2e5de;
            height: 70px;
            padding: 30px;
            border-radius: 8px;
            text-align: center;
            transition: transform 0.3s ease;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }

        .layout div:hover {
            transform: scale(1.05);
        }

        .layout a {
            text-decoration: none;
            color: #ac4800;
            font-size: 18px;
            font-weight: bold;
        }

        .layout a:hover {
            text-decoration: underline;
        }
        .logout-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #ac4800;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
        }

        .logout-btn:hover {
            background-color: #8c3a00;
        }
    </style>
</head>
<body>
    <a href="?logout=true" class="logout-btn">
        <i class="lni lni-exit"></i> Logout
    </a>
    <div class="welcome-message">
        Welcome <?php echo htmlspecialchars($userName); ?>! Explore our services
    </div>

    <section class="layout">
        <div><!--which one is the user_dashboard?-->
            <a href="../view/admin/modals/admin_dashboard.php">
                <i class="lni lni-dashboard"></i> Admin Dashboard
            </a>
        </div>
        <div>
            <a href="../view/communityforum.php">
                <i class="lni lni-comments"></i> Community Forum
            </a>
        </div>
        <div>
            <a href="../view/dietmanagement.php">
                <i class="lni lni-heart"></i> Diet Management
            </a>
        </div>
        <div>
            <a href="../view/exercisePlanning.php">
                <i class="lni lni-bolt"></i> Exercise Planning
            </a>
        </div>
        <div>
            <a href="../view/medicalTracking.php">
                <i class="lni lni-medical"></i> Medication Tracking
            </a>
        </div>
        <div>
            <a href="../view/progressTracking.php">
                <i class="lni lni-analytics"></i> Progress Tracking
            </a>
        </div>
        <div>
            <a href="../view/forumModeration.php">
                <i class="lni lni-cog"></i> Forum Moderation and other Settings
            </a>
        </div>
        <div>
            <a href="../view/healthcareProvider.php">
                <i class="las la-heartbeat"></i> Healthcare Provider Management
            </a>
        </div>
        <div>
            <a href="../view/user_management.php">
                <i class="las la-tasks"></i> User Management
            </a>
        </div>
    </section>
</body>
</html>
