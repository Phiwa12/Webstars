<?php
// Include your database configuration
require_once '../functions/user_dash_function.php';
require_once '../functions/auth_functions.php';
require_once '../db/config.php';

// Fetch user engagement metrics (e.g., number of users, active users)
$user_engagement_query = "SELECT COUNT(*) AS total_users FROM beets_users";
$user_engagement_result = mysqli_query($conn, $user_engagement_query);

// Check if the query was successful
if ($user_engagement_result) {
    $user_engagement = mysqli_fetch_assoc($user_engagement_result);
} else {
    // Handle error if the query fails
    die("Error fetching user engagement data: " . mysqli_error($conn));
}

// Fetch resource utilization statistics (e.g., number of educational resources)
$resource_utilization_query = "SELECT COUNT(*) AS total_resources FROM educational_resources";
$resource_utilization_result = mysqli_query($conn, $resource_utilization_query);

// Check if the query was successful
if ($resource_utilization_result) {
    $resource_utilization = mysqli_fetch_assoc($resource_utilization_result);
} else {
    // Handle error if the query fails
    die("Error fetching resource utilization data: " . mysqli_error($conn));
}

// Fetch forum activity analysis (e.g., number of forum posts)
$forum_activity_query = "SELECT COUNT(*) AS total_posts FROM forum_posts";
$forum_activity_result = mysqli_query($conn, $forum_activity_query);

// Check if the query was successful
if ($forum_activity_result) {
    $forum_activity = mysqli_fetch_assoc($forum_activity_result);
} else {
    // Handle error if the query fails
    die("Error fetching forum activity data: " . mysqli_error($conn));
}

// Fetch health progress trends (e.g., average weight and blood sugar levels)
$health_progress_query = "SELECT AVG(weight) AS avg_weight, AVG(blood_sugar_level) AS avg_blood_sugar FROM progress_logs";
$health_progress_result = mysqli_query($conn, $health_progress_query);

// Check if the query was successful
if ($health_progress_result) {
    $health_progress = mysqli_fetch_assoc($health_progress_result);
} else {
    // Handle error if the query fails
    die("Error fetching health progress data: " . mysqli_error($conn));
}

// Fetch user stats (make sure the variables are set before using them)
$userStats = [
    'blood_sugar' => [
        'latest' => 120,    // Replace with actual value from your database
        'time' => '12:30 PM',  // Replace with actual value from your database
        'weekly_avg' => 115,   // Replace with actual value from your database
        'trend_class' => 'positive',  // Replace with actual value from your database
        'trend' => 'Improving', // Replace with actual value from your database
    ],
    'medication' => [
        'next_name' => 'Insulin',    // Replace with actual value from your database
        'next_time' => '2:00 PM',   // Replace with actual value from your database
    ],
    'exercise' => [
        'completion' => 75,  // Replace with actual value from your database
    ],
];

// Fetch recent activities
$recentActivitiesQuery = "SELECT * FROM recent_activities";  // Replace with actual query
$recentActivitiesResult = mysqli_query($conn, $recentActivitiesQuery);
$recentActivities = [];
if ($recentActivitiesResult) {
    while ($row = mysqli_fetch_assoc($recentActivitiesResult)) {
        $recentActivities[] = $row;
    }
} else {
    // Handle error if the query fails
    die("Error fetching recent activities data: " . mysqli_error($conn));
}

// Fetch upcoming reminders
$upcomingRemindersQuery = "SELECT * FROM med_reminders WHERE reminder_time >= CURDATE()";  // Replace with actual query
$upcomingRemindersResult = mysqli_query($conn, $upcomingRemindersQuery);
$upcomingReminders = [];
if ($upcomingRemindersResult) {
    while ($row = mysqli_fetch_assoc($upcomingRemindersResult)) {
        $upcomingReminders[] = $row;
    }
} else {
    // Handle error if the query fails
    die("Error fetching upcoming reminders data: " . mysqli_error($conn));
}

// Handle custom report generation based on a selected date range (if applicable)
$custom_report_data = [];
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['generate_report'])) {
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    
    $custom_report_query = "SELECT * FROM progress_logs WHERE log_date BETWEEN '$start_date' AND '$end_date'";
    $custom_report_result = mysqli_query($conn, $custom_report_query);
    if ($custom_report_result) {
        while ($row = mysqli_fetch_assoc($custom_report_result)) {
            $custom_report_data[] = $row;
        }
    } else {
        // Handle error if the query fails
        die("Error fetching custom report data: " . mysqli_error($conn));
    }
}

// Function to export data to CSV
function export_to_csv($data, $filename) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $output = fopen('php://output', 'w');
    if (!empty($data)) {
        fputcsv($output, array_keys($data[0]));
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
    }
    fclose($output);
}

if (isset($_POST['export_csv'])) {
    export_to_csv($custom_report_data, 'custom_report.csv');
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics & Reporting</title>
    <link rel="stylesheet" href="../assets/css/AnalyticsReporting.css">
    <link rel="stylesheet" href="../assets/css/user_dash.css">
</head>
<body>
    <li>
        <a href="../../actions/logout.php">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>
    </li>

    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <img src="../assets/images/user-avatar.png" alt="User Avatar" class="avatar">
            <h2><?php echo htmlspecialchars($_SESSION['fname'] . ' ' . $_SESSION['lname'] ?? 'User'); ?></h2>
        </div>
        <nav class="sidebar-nav">
            <a href="../index.php"><i class="fas fa-home"></i> Home</a>
            <a href="#overview" class="active"><i class="fas fa-chart-line"></i> Overview</a>
            <a href="progressTracking.php"><i class="fas fa-chart-bar"></i> Progress</a>
            <a href="exercisePlanning.php"><i class="fas fa-dumbbell"></i> Exercise</a>
            <a href="medicalTracking.php"><i class="fas fa-pills"></i> Medication</a>
            <a href="../actions/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <header class="dashboard-header">
            <h1>           '                '          '    Welcome Back, <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User'); ?>!</h1>
            <div class="header-actions">
                <button id="notificationBtn" class="icon-button">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge">3</span>
                </button>
                <button id="profileBtn" class="icon-button">
                    <i class="fas fa-user"></i>
                </button>
            </div>
        </header>

        <div class="dashboard-grid">
            <!-- Quick Stats -->
            <section class="dashboard-card stats-card">
                <h3>Quick Stats</h3>
                <div class="stats-grid">
                    <div class="stat-item">
                        <span class="stat-label">Latest Blood Sugar</span>
                        <span class="stat-value"><?php echo $userStats['blood_sugar']['latest']; ?> mg/dL</span>
                        <span class="stat-time"><?php echo $userStats['blood_sugar']['time']; ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Weekly Average</span>
                        <span class="stat-value"><?php echo $userStats['blood_sugar']['weekly_avg']; ?> mg/dL</span>
                        <span class="trend-indicator <?php echo $userStats['blood_sugar']['trend_class']; ?>">
                            <?php echo $userStats['blood_sugar']['trend']; ?>
                        </span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Next Medication</span>
                        <span class="stat-value"><?php echo $userStats['medication']['next_name']; ?></span>
                        <span class="stat-time"><?php echo $userStats['medication']['next_time']; ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Exercise Goal</span>
                        <span class="stat-value"><?php echo $userStats['exercise']['completion']; ?>%</span>
                        <div class="progress-bar">
                            <div style="width: <?php echo $userStats['exercise']['completion']; ?>%"></div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Recent Activities -->
            <section class="dashboard-card activities-card">
                <h3>Recent Activities</h3>
                <div class="activity-list">
                    <?php foreach ($recentActivities as $activity): ?>
                        <div class="activity-item">
                            <i class="<?php echo $activity['icon']; ?>"></i>
                            <div class="activity-details">
                                <p class="activity-title"><?php echo htmlspecialchars($activity['title']); ?></p>
                                <span class="activity-time"><?php echo $activity['time']; ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Upcoming Reminders -->
            <section class="dashboard-card reminders-card">
                <h3>Upcoming Reminders</h3>
                <ul class="reminder-list">
                    <?php foreach ($upcomingReminders as $reminder): ?>
                        <li>
                            <span class="reminder-title"><?php echo htmlspecialchars($reminder['title']); ?></span>
                            <span class="reminder-time"><?php echo $reminder['reminder_date']; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </section>

            <!-- Custom Report Generation -->
            <section class="dashboard-card report-card">
                <h3>Generate Custom Report</h3>
                <form method="POST">
                    <label for="start_date">Start Date</label>
                    <input type="date" name="start_date" required>

                    <label for="end_date">End Date</label>
                    <input type="date" name="end_date" required>

                    <button type="submit" name="generate_report" class="btn">Generate Report</button>
                </form>

                <!-- Display Generated Report -->
                <?php if (!empty($custom_report_data)): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Log Date</th>
                                <th>Weight</th>
                                <th>Blood Sugar Level</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($custom_report_data as $report): ?>
                                <tr>
                                    <td><?php echo $report['log_date']; ?></td>
                                    <td><?php echo $report['weight']; ?> kg</td>
                                    <td><?php echo $report['blood_sugar_level']; ?> mg/dL</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <!-- Export Button -->
                    <form method="POST">
                        <button type="submit" name="export_csv" class="btn">Export to CSV</button>
                    </form>
                <?php endif; ?>
            </section>
        </div>
    </main>

</body>
</html>


