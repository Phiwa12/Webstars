<?php
session_start();
require_once '../functions/user_dash_function.php';
require_once '../functions/auth_functions.php';
require_once '../db/config.php';

// Check if user is logged in
checkUserAuth();

$userStats = getUserDashboardStats();
$recentActivities = getUserActivities();
$upcomingReminders = getUserReminders();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diabetes Management Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/user_dash.css">
    
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <img src="../assets/images/user-avatar.png" alt="User Avatar" class="avatar">
                <h2><?php echo htmlspecialchars($_SESSION['fname'] . ' ' . $_SESSION['lname'] ?? 'User'); ?></h2>
            </div>
            <nav class="sidebar-nav">
                <a href="../index.php"><i class="fas fa-home"></i> Home</a>
                <a href="#overview" class="active"><i class="fas fa-chart-line"></i> Overview</a>
                <a href="progressTracking.php"><i class="fas fa-chart-bar"></i> Progress</a>
                <a href="exercisePlanning.php"><i class="fas fa-dumbbell"></i> Exercise</a>
                <a href="medicalTracking.php"><i class="fas fa-pills"></i> Medication</a>
                <a href="../actions/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="dashboard-header">
                <h1>Welcome Back, <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User'); ?>!</h1>
                <div class="header-actions">
                    <button id="notificationBtn" class="icon-button">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge">3</span>
                    </button>
                    <button id="profileBtn" class="icon-button">
                        <i class="fas fa-user"></i>
                    </button>
                </div>
            </header>

            <div class="dashboard-grid">
                <!-- Quick Stats -->
                <section class="dashboard-card stats-card">
                    <h3>Quick Stats</h3>
                    <div class="stats-grid">
                        <div class="stat-item">
                            <span class="stat-label">Latest Blood Sugar</span>
                            <span class="stat-value"><?php echo $userStats['blood_sugar']['latest']; ?> mg/dL</span>
                            <span class="stat-time"><?php echo $userStats['blood_sugar']['time']; ?></span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Weekly Average</span>
                            <span class="stat-value"><?php echo $userStats['blood_sugar']['weekly_avg']; ?> mg/dL</span>
                            <span class="trend-indicator <?php echo $userStats['blood_sugar']['trend_class']; ?>">
                                <?php echo $userStats['blood_sugar']['trend']; ?>
                            </span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Next Medication</span>
                            <span class="stat-value"><?php echo $userStats['medication']['next_name']; ?></span>
                            <span class="stat-time"><?php echo $userStats['medication']['next_time']; ?></span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Exercise Goal</span>
                            <span class="stat-value"><?php echo $userStats['exercise']['completion']; ?>%</span>
                            <div class="progress-bar">
                                <div style="width: <?php echo $userStats['exercise']['completion']; ?>%"></div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Recent Activities -->
                <section class="dashboard-card activities-card">
                    <h3>Recent Activities</h3>
                    <div class="activity-list">
                        <?php foreach ($recentActivities as $activity): ?>
                            <div class="activity-item">
                                <i class="<?php echo $activity['icon']; ?>"></i>
                                <div class="activity-details">
                                    <p class="activity-title"><?php echo htmlspecialchars($activity['title']); ?></p>
                                    <span class="activity-time"><?php echo $activity['time']; ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <!-- Upcoming Reminders -->
                <section class="dashboard-card reminders-card">
                    <h3>Upcoming Reminders</h3>
                    <div class="reminder-list">
                        <?php foreach ($upcomingReminders as $reminder): ?>
                            <div class="reminder-item" data-id="<?php echo $reminder['id']; ?>">
                                <div class="reminder-time"><?php echo $reminder['time']; ?></div>
                                <div class="reminder-details">
                                    <p class="reminder-title"><?php echo htmlspecialchars($reminder['title']); ?></p>
                                    <span class="reminder-type"><?php echo $reminder['type']; ?></span>
                                </div>
                                <button class="reminder-action" onclick="completeReminder(<?php echo $reminder['id']; ?>)">
                                    <i class="fas fa-check"></i>
                                </button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <!-- Weekly Overview Chart -->
                <section class="dashboard-card chart-card">
                    <h3>Weekly Overview</h3>
                    <div class="chart-container">
                        <canvas id="weeklyChart"></canvas>
                    </div>
                </section>
            </div>
        </main>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
    <script src="../assets/js/user_dash.js"></script>
</body>
</html>