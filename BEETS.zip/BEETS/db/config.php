<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username = "phiwayinkhosi.lukhele";
$password = "780316";
$dbname = "webtech_fall2024_phiwayinkhosi_lukhele";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set charset
$conn->set_charset("utf8mb4");

// Error reporting for development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Constants
define('MAX_MESSAGE_LENGTH', 1000);
define('ADMIN_EMAIL', 'beetsSupport@gmail.com');
define('BEETS_ROOT', dirname(__DIR__));