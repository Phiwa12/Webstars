<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate input
    $userDetails = [
        'height' => filter_input(INPUT_POST, 'height', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION),
        'age' => filter_input(INPUT_POST, 'age', FILTER_SANITIZE_NUMBER_INT),
        'weight' => filter_input(INPUT_POST, 'weight', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION),
        'goal' => filter_input(INPUT_POST, 'goal', FILTER_SANITIZE_STRING),
        'diabetes' => filter_input(INPUT_POST, 'diabetes', FILTER_SANITIZE_STRING),
        'limitations' => filter_input(INPUT_POST, 'limitations', FILTER_SANITIZE_STRING)
    ];

    
    // Validate the input
    $errors = validateUserInput($userDetails);

    if (empty($errors)) {
        try {
            // Save to database
            $stmt = $conn->prepare("INSERT INTO user_profile (height, weight, age, goal, diabetes_type) 
                                  VALUES (:height, :weight, :age, :goal, :diabetes_type)");
            
            $stmt->execute($userDetails);
            
            // Save to session
            $_SESSION['user_profile'] = $userDetails;
            
            // Calculate BMI
            $_SESSION['bmi'] = calculateBMI($userDetails['weight'], $userDetails['height']);
            
            // Redirect with success message
            header('Location: ../exercisePlanning.php?status=success&message=Details saved successfully');
            exit;
            
        } catch (PDOException $e) {
            error_log("Error saving user details: " . $e->getMessage());
            header('Location: ../exercisePlanning.php?status=error&message=Error saving details');
            exit;
        }
    } else {
        // Redirect with error messages
        $errorString = urlencode(implode(', ', $errors));
        header("Location: ../exercisePlanning.php?status=error&message=$errorString");
        exit;
    }
}
?>