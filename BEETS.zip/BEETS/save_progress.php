<?php
require_once 'db/config.php';
require_once 'functions/progress_function.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Debug line to check incoming data
    error_log('Received POST data: ' . print_r($_POST, true));

    $data = [
        'log_date' => isset($_POST['trackingDate']) ? date('Y-m-d', strtotime($_POST['trackingDate'])) : null,
        'weight' => filter_input(INPUT_POST, 'weight', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION),
        'blood_sugar_level' => filter_input(INPUT_POST, 'bloodSugar', FILTER_SANITIZE_NUMBER_INT)
    ];
    
    // Validate the date first
    if (empty($data['log_date'])) {
        echo json_encode([
            'success' => false,
            'message' => 'Date is required'
        ]);
        exit;
    }

    // Make sure the date is valid
    if (!strtotime($data['log_date'])) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid date format'
        ]);
        exit;
    }
    
    $errors = validateProgressData($data);
    
    if (empty($errors)) {
        try {
            $stmt = $conn->prepare("INSERT INTO progress_logs (log_date, weight, blood_sugar_level) 
                                  VALUES (?, ?, ?)");
            
            if (!$stmt->execute([
                $data['log_date'],
                $data['weight'] ?: null,
                $data['blood_sugar_level'] ?: null
            ])) {
                throw new Exception("Failed to execute statement: " . $stmt->error);
            }
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'log_date' => date('M j', strtotime($data['log_date'])),
                    'weight' => $data['weight'],
                    'blood_sugar_level' => $data['blood_sugar_level']
                ],
                'message' => 'Progress saved successfully'
            ]);
            
        } catch (Exception $e) {
            error_log("Error saving progress: " . $e->getMessage());
            echo json_encode([
                'success' => false,
                'message' => 'Database error occurred: ' . $e->getMessage()
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => implode(', ', $errors)
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}
?>