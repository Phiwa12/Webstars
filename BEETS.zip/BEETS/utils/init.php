<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Define base paths
define('BASE_PATH', dirname(__DIR__));
define('VIEW_PATH', BASE_PATH . '/view');
define('FUNCTIONS_PATH', BASE_PATH . '/functions');
define('ACTIONS_PATH', BASE_PATH . '/actions');
define('UTILS_PATH', BASE_PATH . '/utils');
define('ASSETS_PATH', BASE_PATH . '/assets');

// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'beets');
define('DB_USER', 'root');
define('DB_PASS', '');

// Application settings
define('APP_NAME', 'BEETS');
define('APP_URL', 'http://localhost/BEETS'); 

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', BASE_PATH . '/logs/error.log');

// Common Functions
function redirect($path) {
    $fullPath = APP_URL . $path;
    header("Location: " . $fullPath);
    exit();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getCurrentPage() {
    return basename($_SERVER['PHP_SELF']);
}
?>