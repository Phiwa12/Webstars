<?php
// Ensure logs directory exists
$logsDir = __DIR__ . '/../logs';
if (!file_exists($logsDir)) {
    mkdir($logsDir, 0777, true);
}

// Error reporting configuration
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', $logsDir . '/error.log');

// Constants for Messages
define('ERROR_MESSAGES', [
    'DB_CONNECTION' => 'Database connection error occurred.',
    'INVALID_INPUT' => 'Invalid input provided.',
    'UNAUTHORIZED' => 'Unauthorized access.',
    'NOT_FOUND' => 'Requested resource not found.',
    'SERVER_ERROR' => 'Internal server error occurred.',
    'VALIDATION_ERROR' => 'Data validation failed.',
]);

define('SUCCESS_MESSAGES', [
    'REMINDER_COMPLETED' => 'Reminder completed successfully.',
    'DATA_SAVED' => 'Data saved successfully.',
    'RECORD_UPDATED' => 'Record updated successfully.',
    'RECORD_DELETED' => 'Record deleted successfully.',
]);

/**
 * Custom error handler for PHP errors
 */
function customErrorHandler($errno, $errstr, $errfile, $errline) {
    $error_message = date('Y-m-d H:i:s') . " - Error [$errno]: $errstr in $errfile on line $errline\n";
    error_log($error_message);
    return false; // Allow PHP's internal error handler to continue
}

/**
 * Custom exception handler for uncaught exceptions
 */
function customExceptionHandler($exception) {
    $error_message = date('Y-m-d H:i:s') . " - Exception: " . $exception->getMessage() . 
                    " in " . $exception->getFile() . 
                    " on line " . $exception->getLine() . "\n";
    error_log($error_message);
    
    // Show user-friendly message if headers haven't been sent
    if (!headers_sent()) {
        header('HTTP/1.1 500 Internal Server Error');
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'An unexpected error occurred. Please try again later.'
        ]);
    }
}

/**
 * Function to log errors with additional context
 */
function logError($function, $message, $context = []) {
    $log_message = [
        'timestamp' => date('Y-m-d H:i:s'),
        'function' => $function,
        'message' => $message,
        'user_id' => $_SESSION['user_id'] ?? 'not_logged_in',
        'context' => $context
    ];
    
    error_log(json_encode($log_message) . "\n");
}

/**
 * Function to display user-friendly error messages
 */
function displayUserError($error_code) {
    if (array_key_exists($error_code, ERROR_MESSAGES)) {
        return ERROR_MESSAGES[$error_code];
    }
    return ERROR_MESSAGES['SERVER_ERROR'];
}

/**
 * Function to validate input data
 */
function validateInput($data, $rules) {
    $errors = [];
    
    foreach ($rules as $field => $rule) {
        if (!isset($data[$field])) {
            $errors[] = "Field '$field' is required.";
            continue;
        }
        
        $value = $data[$field];
        
        switch ($rule) {
            case 'numeric':
                if (!is_numeric($value)) {
                    $errors[] = "Field '$field' must be numeric.";
                }
                break;
            case 'email':
                if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $errors[] = "Field '$field' must be a valid email.";
                }
                break;
            case 'date':
                if (!strtotime($value)) {
                    $errors[] = "Field '$field' must be a valid date.";
                }
                break;
            case 'string':
                if (!is_string($value) || trim($value) === '') {
                    $errors[] = "Field '$field' must be a non-empty string.";
                }
                break;
        }
    }
    
    return $errors;
}

/**
 * Function to sanitize output
 */
function sanitizeOutput($data) {
    if (is_array($data)) {
        return array_map('sanitizeOutput', $data);
    }
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

// Set the custom error and exception handlers
set_error_handler('customErrorHandler');
set_exception_handler('customExceptionHandler');

// Set default timezone
date_default_timezone_set('UTC');

?>