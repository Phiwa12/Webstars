<?php
// Database configuration
require_once 'config.php';

if (isset($_POST['submit'])) {
    // Get form data and sanitize
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);
    
    // Validate inputs
    if (empty($name) || empty($email) || empty($message)) {
        $error_message = "All fields are required.";
        return;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format.";
        return;
    }

    try {
        // Connect to database
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepare SQL and bind parameters
        $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, message, created_at) 
                              VALUES (:name, :email, :message, NOW())");
        
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':message', $message);

        // Execute the query
        $stmt->execute();

        // Send email notification
        $to = "phiwalukhele551@gmail.com";
        $subject = "New Contact Form Submission";
        $email_content = "Name: $name\n";
        $email_content .= "Email: $email\n\n";
        $email_content .= "Message:\n$message";
        
        $headers = "From: $email";

        mail($to, $subject, $email_content, $headers);

        $success_message = "Thank you for your message. We'll get back to you soon!";
        
    } catch(PDOException $e) {
        $error_message = "Sorry, there was an error sending your message. Please try again later.";
        error_log("Error: " . $e->getMessage());
    }

    $conn = null;
}
?>