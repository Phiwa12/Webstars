<?php
// Get default workout routine
function getDefaultRoutine() {
    return '<li>Warm-Up: 10 minutes of cardio</li>
            <li>Strength Training: 3 sets of squats, push-ups, and lunges</li>
            <li>Core Workout: 3 sets of crunches and planks</li>
            <li>Cool-Down: 5 minutes of stretching</li>';
}

// Get exercise logs from database
function getExerciseLogs() {
    global $conn;
    $logs = '';
    
    try {
        // Check if connection exists
        if (!$conn) {
            throw new Exception("Database connection failed.");
        }

        $query = "SELECT * FROM exercise_logs ORDER BY timestamp DESC LIMIT 10";
        $stmt = $conn->prepare($query);

        // Validate query preparation
        if (!$stmt) {
            throw new Exception("Failed to prepare query: " . $conn->error);
        }

        $stmt->execute();
        $result = $stmt->get_result();

        // Fetch logs
        while ($row = $result->fetch_assoc()) {
            $logs .= "<li>" . htmlspecialchars($row['log_entry']) . " - " . 
                     date('Y-m-d H:i:s', strtotime($row['timestamp'])) . "</li>";
        }
    } catch (Exception $e) {
        error_log("Exception: " . $e->getMessage());
    }
    
    // Return logs or a default message
    return $logs ? $logs : '<li>No exercise logs yet</li>';
}



// Generate personalized workout based on user details
function generatePersonalizedWorkout($userDetails) {
    $workouts = [];
    
    // Basic workout structure
    $workouts['weight_loss'] = [
        'Warm-Up: 15 minutes cardio',
        'HIIT: 20 minutes',
        'Strength: 20 minutes',
        'Cool-Down: 5 minutes stretching'
    ];
    
    $workouts['muscle_gain'] = [
        'Warm-Up: 10 minutes light cardio',
        'Strength: 40 minutes',
        'Core: 10 minutes',
        'Cool-Down: 5 minutes'
    ];
    
    $workouts['maintain_fitness'] = [
        'Warm-Up: 10 minutes',
        'Mixed cardio and strength: 30 minutes',
        'Flexibility: 10 minutes',
        'Cool-Down: 5 minutes'
    ];
    
    $goal = $userDetails['goal'] ?? 'maintain_fitness';
    return $workouts[$goal];
}

// Validate user input
function validateUserInput($data) {
    $errors = [];
    
    if (!is_numeric($data['height']) || $data['height'] <= 0) {
        $errors[] = "Invalid height value";
    }
    
    if (!is_numeric($data['age']) || $data['age'] <= 0) {
        $errors[] = "Invalid age value";
    }
    
    if (!is_numeric($data['weight']) || $data['weight'] <= 0) {
        $errors[] = "Invalid weight value";
    }
    
    return $errors;
}

// Calculate BMI
function calculateBMI($weight, $height) {
    $heightInMeters = $height / 100;
    return round($weight / ($heightInMeters * $heightInMeters), 1);
}

function validateProgressData($data) {
    $errors = [];
    
    // Validate date
    if (empty($data['log_date'])) {
        $errors[] = 'Date is required';
    }
    
    // Validate weight if provided
    if (isset($data['weight']) && $data['weight'] !== null) {
        if (!is_numeric($data['weight']) || $data['weight'] < 0) {
            $errors[] = 'Weight must be a positive number';
        }
    }
    
    // Validate blood sugar if provided
    if (isset($data['blood_sugar_level']) && $data['blood_sugar_level'] !== null) {
        if (!is_numeric($data['blood_sugar_level']) || $data['blood_sugar_level'] < 0) {
            $errors[] = 'Blood sugar level must be a positive number';
        }
    }
    
    return $errors;
}
?>