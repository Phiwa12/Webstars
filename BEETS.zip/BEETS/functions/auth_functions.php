<?php
require_once dirname(__DIR__) . '/db/config.php';

/**
 * Authentication Functions
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isSuperAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] == 1;
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] == 2;
}

function checkAdminAuth() {
    if (!isLoggedIn()) {
        header('Location: /BEETS/view/loginbeets.php');
        exit();
    }

    // Allow both role 1 (Super Admin) and role 2 (Admin)
    if ($_SESSION['role'] > 2) {
        header('Location: /BEETS/view/unauthorized.php');
        exit();
    }
}

function checkSuperAdminAuth() {
    if (!isLoggedIn()) {
        header('Location: ../loginbeets.php');
        exit();
    }

    if (!isSuperAdmin()) {
        header('Location: ../admin_dashboard.php?error=unauthorized');
        exit();
    }
}

/**
 * Session Management
 */
function initSession($userData) {
    session_regenerate_id(true);
    $_SESSION['user_id'] = $userData['user_id'];
    $_SESSION['email'] = $userData['email'];
    $_SESSION['fname'] = $userData['fname'];
    $_SESSION['lname'] = $userData['lname'];
    $_SESSION['role'] = $userData['role'];
    
    // Log successful login
    logLoginAttempt($userData['email'], true);
}

/**
 * Security Functions
 */

function logLoginAttempt($email, $success = false) {
    global $conn;
    try {
        // First check if the login_attempts table exists
        $check_table = "SHOW TABLES LIKE 'login_attempts'";
        $table_exists = $conn->query($check_table);
        
        if ($table_exists->num_rows == 0) {
            // Create the table if it doesn't exist
            $create_table = "CREATE TABLE IF NOT EXISTS login_attempts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(255) NOT NULL,
                ip_address VARCHAR(45) NOT NULL,
                user_agent VARCHAR(255),
                status VARCHAR(10) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";
            $conn->query($create_table);
        }

        $stmt = $conn->prepare("INSERT INTO login_attempts (email, ip_address, user_agent, status) VALUES (?, ?, ?, ?)");
        if ($stmt === false) {
            error_log("Prepare failed: " . $conn->error);
            return false;
        }

        $ipAddress = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $status = $success ? 'success' : 'failed';

        $stmt->bind_param("ssss", $email, $ipAddress, $userAgent, $status);
        $result = $stmt->execute();
        if (!$result) {
            error_log("Execute failed: " . $stmt->error);
        }
        $stmt->close();

        if (!$success) {
            checkBruteForce($email);
        }
    } catch (Exception $e) {
        error_log("Login attempt logging failed: " . $e->getMessage());
    }
}

function checkBruteForce($email) {
    global $conn;
    try {
        $stmt = $conn->prepare("
            SELECT COUNT(*) as attempt_count 
            FROM login_attempts 
            WHERE email = ? 
            AND status = 'failed' 
            AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
        ");
        
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $attempts = $result->fetch_assoc()['attempt_count'];

        if ($attempts >= 5) {
            $stmt = $conn->prepare("
                UPDATE beets_users 
                SET status = 'locked', 
                    locked_at = NOW() 
                WHERE email = ?
            ");
            $stmt->bind_param("s", $email);
            $stmt->execute();

            logSecurityEvent($email, 'account_locked', 'Account locked due to multiple failed login attempts');
        }
    } catch (Exception $e) {
        logError('checkBruteForce', $e->getMessage());
    }
}

function logSecurityEvent($email, $event_type, $description) {
    global $conn;
    try {
        $stmt = $conn->prepare("
            INSERT INTO security_events (
                email,
                event_type,
                description,
                ip_address,
                created_at
            ) VALUES (?, ?, ?, ?, NOW())
        ");

        $ipAddress = $_SERVER['REMOTE_ADDR'];
        $stmt->bind_param("ssss", $email, $event_type, $description, $ipAddress);
        $stmt->execute();
    } catch (Exception $e) {
        logError('logSecurityEvent', $e->getMessage());
    }
}

/**
 * Password Management
 */
function verifyPassword($password, $hashedPassword) {
    return password_verify($password, $hashedPassword);
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

function validatePasswordStrength($password) {
    if (strlen($password) < 8) return false;
    if (!preg_match('/[A-Z]/', $password)) return false;
    if (!preg_match('/[a-z]/', $password)) return false;
    if (!preg_match('/[0-9]/', $password)) return false;
    if (!preg_match('/[!@#$%^&*()\-_=+{};:,<.>]/', $password)) return false;
    return true;
}

/**
 * Token Management
 */
function generateToken($length = 32) {
    try {
        return bin2hex(random_bytes($length));
    } catch (Exception $e) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $token = '';
        for ($i = 0; $i < $length * 2; $i++) {
            $token .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $token;
    }
}

/**
 * Session Security
 */
function regenerateSession() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    session_regenerate_id(true);
    
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        session_id(),
        [
            'expires' => 0,
            'path' => $params['path'],
            'domain' => $params['domain'],
            'secure' => true,
            'httponly' => true,
            'samesite' => 'Lax'
        ]
    );
}

function destroySession() {
    $_SESSION = array();
    
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', [
            'expires' => time() - 3600,
            'path' => '/',
            'domain' => '',
            'secure' => true,
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
    }
    
    session_destroy();
}

/**
 * Role Management
 */
function getUserRole($userId) {
    global $conn;
    try {
        $stmt = $conn->prepare("SELECT role FROM beets_users WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            return $row['role'];
        }
        return false;
    } catch (Exception $e) {
        logError('getUserRole', $e->getMessage());
        return false;
    }
}

function hasPermission($permission) {
    if (!isLoggedIn()) {
        return false;
    }

    $userRole = $_SESSION['role'];

    $rolePermissions = [
        1 => [ // Super Admin
            'manage_users',
            'manage_roles',
            'view_stats',
            'manage_content',
            'manage_settings'
        ],
        2 => [ // Admin
            'view_stats',
            'manage_content'
        ]
    ];

    return isset($rolePermissions[$userRole]) && 
           in_array($permission, $rolePermissions[$userRole]);
}

function checkUserAccess() {
    if (!isset($_SESSION['user_id'])) {
        // Store the current URL for redirect after login
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header("Location: /BEETS/view/loginbeets.php");
        exit();
    }

    // Check if user has required role
    $requiredRole = determineRequiredRole();
    if ($requiredRole > $requiredRole && $_SESSION['role'] > $requiredRole) {
        header("Location: /BEETS/view/unauthorized.php");
        exit();
    }
}

function determineRequiredRole() {
    $currentPath = $_SERVER['REQUEST_URI'];
    
    // Admin paths require role 1 or 2
    if (strpos($currentPath, '/admin/') !== false) {
        return 2;
    }
    
    // Super admin paths require role 1
    if (strpos($currentPath, '/superadmin/') !== false) {
        return 1;
    }
    
    // Regular user paths require role 3 or less
    return 3;
}

?>