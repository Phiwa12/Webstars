<?php
// /functions/dashboard_stats.php

require_once '../db/config.php';

/**
 * Dashboard Statistics
 */
function getDashboardStatistics() {
    try {
        return [
            'user_stats' => getUserStatistics(),
            'forum_stats' => getForumStatistics(),
            'health_stats' => getHealthStatistics(),
            'system_stats' => getSystemStatistics()
        ];
    } catch (Exception $e) {
        logError('getDashboardStatistics', $e->getMessage());
        return [];
    }
}

function getUserStatistics() {
    global $conn;
    try {
        // Total Users
        $stmt = $conn->prepare("SELECT COUNT(*) as total FROM beets_users WHERE status = 'active'");
        $stmt->execute();
        $totalUsers = $stmt->get_result()->fetch_assoc()['total'];

        // Active Users in Last 24 Hours
        $stmt = $conn->prepare("
            SELECT COUNT(DISTINCT user_id) as active_users
            FROM user_activity_logs 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ");
        $stmt->execute();
        $activeUsers = $stmt->get_result()->fetch_assoc()['active_users'];

        // New Users This Week
        $stmt = $conn->prepare("
            SELECT COUNT(*) as new_users,
                   ROUND(
                       ((COUNT(*) - (
                           SELECT COUNT(*) 
                           FROM beets_users 
                           WHERE created_at BETWEEN 
                               DATE_SUB(NOW(), INTERVAL 2 WEEK) AND 
                               DATE_SUB(NOW(), INTERVAL 1 WEEK)
                       )) / (
                           SELECT COUNT(*) 
                           FROM beets_users 
                           WHERE created_at BETWEEN 
                               DATE_SUB(NOW(), INTERVAL 2 WEEK) AND 
                               DATE_SUB(NOW(), INTERVAL 1 WEEK)
                       ) * 100), 
                   1) as growth_rate
            FROM beets_users 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)
        ");
        $stmt->execute();
        $newUsersData = $stmt->get_result()->fetch_assoc();

        return [
            'total_users' => $totalUsers,
            'active_users_24h' => $activeUsers,
            'new_users_week' => $newUsersData['new_users'],
            'user_growth_percentage' => $newUsersData['growth_rate'],
            'user_growth_trend' => $newUsersData['growth_rate'] > 0 ? 'up' : 'down'
        ];
    } catch (Exception $e) {
        logError('getUserStatistics', $e->getMessage());
        return [];
    }
}

function getForumStatistics() {
    global $conn;
    try {
        $query = "
            SELECT 
                (SELECT COUNT(*) FROM forum_posts WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) as total_posts,
                (SELECT COUNT(*) FROM forum_comments WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) as total_comments,
                (SELECT COUNT(DISTINCT post_id) FROM forum_posts p 
                 JOIN forum_comments c ON p.id = c.post_id 
                 WHERE c.created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as active_discussions
        ";
        $result = $conn->query($query);
        return $result->fetch_assoc();
    } catch (Exception $e) {
        logError('getForumStatistics', $e->getMessage());
        return [
            'total_posts' => 0,
            'total_comments' => 0,
            'active_discussions' => 0
        ];
    }
}

function getHealthStatistics() {
    global $conn;
    try {
        $query = "
            SELECT 
                AVG(blood_sugar) as avg_blood_sugar,
                COUNT(DISTINCT user_id) as tracking_users
            FROM blood_sugar_readings
            WHERE measured_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        ";
        $result = $conn->query($query);
        return $result->fetch_assoc();
    } catch (Exception $e) {
        logError('getHealthStatistics', $e->getMessage());
        return [
            'avg_blood_sugar' => 0,
            'tracking_users' => 0
        ];
    }
}

function getSystemStatistics() {
    try {
        // Server Load
        $load = sys_getloadavg();
        $serverLoad = ($load[0] / getcores()) * 100;

        // Memory Usage
        $memoryTotal = memory_get_total();
        $memoryFree = memory_get_free();
        $memoryUsage = ($memoryTotal - $memoryFree) / $memoryTotal * 100;

        // Disk Usage
        $diskTotal = disk_total_space('/');
        $diskFree = disk_free_space('/');
        $diskUsage = ($diskTotal - $diskFree) / $diskTotal * 100;

        return [
            'server_load' => round($serverLoad, 2),
            'memory_usage' => round($memoryUsage, 2),
            'disk_usage' => round($diskUsage, 2),
            'status' => determineSystemStatus($serverLoad, $memoryUsage, $diskUsage),
            'alerts' => getSystemAlerts()
        ];
    } catch (Exception $e) {
        logError('getSystemStatistics', $e->getMessage());
        return [];
    }
}

/**
 * Helper Functions
 */
function determineSystemStatus($serverLoad, $memoryUsage, $diskUsage) {
    if ($serverLoad > 90 || $memoryUsage > 90 || $diskUsage > 90) {
        return 'Critical';
    } elseif ($serverLoad > 70 || $memoryUsage > 70 || $diskUsage > 70) {
        return 'Warning';
    }
    return 'Healthy';
}

function getSystemAlerts() {
    $alerts = [];
    
    // Check server metrics
    if (function_exists('sys_getloadavg')) {
        $load = sys_getloadavg();
        if ($load[0] > 80) {
            $alerts[] = [
                'level' => 'error',
                'message' => 'High server load detected',
                'created_at' => date('Y-m-d H:i:s')
            ];
        }
    }

    // Check disk space
    $diskFree = disk_free_space('/');
    $diskTotal = disk_total_space('/');
    $diskUsage = ($diskTotal - $diskFree) / $diskTotal * 100;
    
    if ($diskUsage > 90) {
        $alerts[] = [
            'level' => 'error',
            'message' => 'Low disk space warning',
            'created_at' => date('Y-m-d H:i:s')
        ];
    }

    return $alerts;
}
?>