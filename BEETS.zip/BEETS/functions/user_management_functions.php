
<?php
require_once dirname(__DIR__) . '/db/config.php';

function getAllRoles() {
    global $conn;
    try {
        // Since we're using direct role values in beets_users table
        return [
            ['id' => 1, 'name' => 'Super Admin'],
            ['id' => 2, 'name' => 'Admin'],
            ['id' => 3, 'name' => 'User']
        ];
    } catch (Exception $e) {
        error_log("Error getting roles: " . $e->getMessage());
        return [];
    }
}

function getFilteredUsers($searchTerm = '', $roleFilter = '', $statusFilter = '', $page = 1) {
    global $conn;
    $limit = 10; // Users per page
    $offset = ($page - 1) * $limit;
    
    $query = "SELECT u.user_id, u.fname, u.lname, u.email, u.role, u.created_at,
              CASE 
                WHEN u.role = 1 THEN 'Super Admin'
                WHEN u.role = 2 THEN 'Admin'
                ELSE 'User'
              END as role_name
              FROM beets_users u
              WHERE 1=1";
    
    $params = [];
    $types = "";
    
    if ($searchTerm) {
        $query .= " AND (u.fname LIKE ? OR u.lname LIKE ? OR u.email LIKE ?)";
        $searchTerm = "%$searchTerm%";
        $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);
        $types .= "sss";
    }
    
    if ($roleFilter) {
        $query .= " AND u.role = ?";
        $params[] = $roleFilter;
        $types .= "i";
    }
    
    $query .= " ORDER BY u.created_at DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $types .= "ii";
    
    $stmt = $conn->prepare($query);
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

function getTotalUsers($searchTerm = '', $roleFilter = '', $statusFilter = '') {
    global $conn;
    
    $query = "SELECT COUNT(*) as total FROM beets_users WHERE 1=1";
    $params = [];
    $types = "";
    
    if ($searchTerm) {
        $query .= " AND (fname LIKE ? OR lname LIKE ? OR email LIKE ?)";
        $searchTerm = "%$searchTerm%";
        $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);
        $types .= "sss";
    }
    
    if ($roleFilter) {
        $query .= " AND role = ?";
        $params[] = $roleFilter;
        $types .= "i";
    }
    
    $stmt = $conn->prepare($query);
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    return $row['total'];
}

function generatePagination($currentPage, $totalItems, $itemsPerPage = 10) {
    $totalPages = ceil($totalItems / $itemsPerPage);
    
    if ($totalPages <= 1) return '';
    
    $html = '<div class="flex justify-center space-x-2 my-4">';
    
    // Previous button
    if ($currentPage > 1) {
        $html .= '<a href="?page=' . ($currentPage - 1) . '" class="px-4 py-2 border rounded hover:bg-gray-100">&laquo;</a>';
    }
    
    // Page numbers
    for ($i = 1; $i <= $totalPages; $i++) {
        if ($i == $currentPage) {
            $html .= '<span class="px-4 py-2 bg-blue-500 text-white rounded">' . $i . '</span>';
        } else {
            $html .= '<a href="?page=' . $i . '" class="px-4 py-2 border rounded hover:bg-gray-100">' . $i . '</a>';
        }
    }
    
    // Next button
    if ($currentPage < $totalPages) {
        $html .= '<a href="?page=' . ($currentPage + 1) . '" class="px-4 py-2 border rounded hover:bg-gray-100">&raquo;</a>';
    }
    
    $html .= '</div>';
    return $html;
}

function getRoleBadgeClass($role) {
    switch ($role) {
        case 1:
            return 'bg-purple-100 text-purple-800';
        case 2:
            return 'bg-blue-100 text-blue-800';
        default:
            return 'bg-gray-100 text-gray-800';
    }
}

function formatDateTime($datetime) {
    return date('M j, Y g:i A', strtotime($datetime));
}

function createUser($userData) {
    global $conn;
    try {
        $hashedPassword = password_hash($userData['password'], PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("
            INSERT INTO beets_users (fname, lname, email, password, role)
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $stmt->bind_param("ssssi", 
            $userData['fname'],
            $userData['lname'],
            $userData['email'],
            $hashedPassword,
            $userData['role']
        );
        
        return $stmt->execute();
    } catch (Exception $e) {
        error_log("Error creating user: " . $e->getMessage());
        return false;
    }
}

function updateUser($userData) {
    global $conn;
    try {
        $stmt = $conn->prepare("
            UPDATE beets_users 
            SET fname = ?, lname = ?, email = ?, role = ?
            WHERE user_id = ?
        ");
        
        $stmt->bind_param("sssii",
            $userData['fname'],
            $userData['lname'],
            $userData['email'],
            $userData['role'],
            $userData['user_id']
        );
        
        return $stmt->execute();
    } catch (Exception $e) {
        error_log("Error updating user: " . $e->getMessage());
        return false;
    }
}

function deleteUser($userId) {
    global $conn;
    try {
        $stmt = $conn->prepare("DELETE FROM beets_users WHERE user_id = ? AND role != 1");
        $stmt->bind_param("i", $userId);
        return $stmt->execute();
    } catch (Exception $e) {
        error_log("Error deleting user: " . $e->getMessage());
        return false;
    }
}

function getUserById($userId) {
    global $conn;
    try {
        $stmt = $conn->prepare("
            SELECT user_id, fname, lname, email, role, created_at
            FROM beets_users 
            WHERE user_id = ?
        ");
        
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    } catch (Exception $e) {
        error_log("Error getting user: " . $e->getMessage());
        return null;
    }
}