<?php
require_once '../db/database.php';
require_once '../utils/error_config.php';

/**
 * User Authentication & Authorization Functions
 */
function isSuperAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'super_admin';
}

function checkSuperAdminAuth() {
    if (!isSuperAdmin()) {
        header('Location: ../login.php?error=unauthorized');
        exit();
    }
}

/**
 * User Management Functions
 */
function getFilteredUsers($searchTerm = '', $roleFilter = '', $statusFilter = '', $page = 1, $limit = 10) {
    global $conn;
    
    try {
        $offset = ($page - 1) * $limit;
        $params = [];
        $whereConditions = [];
        
        if (!empty($searchTerm)) {
            $whereConditions[] = "(u.name LIKE :search OR u.email LIKE :search)";
            $params[':search'] = "%{$searchTerm}%";
        }
        
        if (!empty($roleFilter)) {
            $whereConditions[] = "u.role_id = :role";
            $params[':role'] = $roleFilter;
        }
        
        if (!empty($statusFilter)) {
            $whereConditions[] = "u.status = :status";
            $params[':status'] = $statusFilter;
        }
        
        $whereClause = !empty($whereConditions) ? "WHERE " . implode(" AND ", $whereConditions) : "";
        
        $query = "
            SELECT 
                u.*,
                r.name as role_name,
                COALESCE(al.last_login, 'Never') as last_login
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            LEFT JOIN (
                SELECT user_id, MAX(login_time) as last_login
                FROM activity_log
                WHERE activity_type = 'login'
                GROUP BY user_id
            ) al ON u.id = al.user_id
            {$whereClause}
            ORDER BY u.created_at DESC
            LIMIT :limit OFFSET :offset
        ";
        
        $params[':limit'] = $limit;
        $params[':offset'] = $offset;
        
        $stmt = $conn->prepare($query);
        $stmt->execute($params);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        logError('getFilteredUsers', $e->getMessage());
        return [];
    }
}

function getUserFullDetails($userId) {
    global $conn;
    
    try {
        // Get basic user information
        $query = "
            SELECT 
                u.*,
                r.name as role_name,
                ud.phone,
                ud.address,
                ud.city,
                ud.country,
                ud.diabetes_type,
                ud.diagnosis_date,
                ud.emergency_contact,
                ud.medical_conditions
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            LEFT JOIN user_details ud ON u.id = ud.user_id
            WHERE u.id = :user_id
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([':user_id' => $userId]);
        $userInfo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$userInfo) {
            return null;
        }
        
        // Get user's medications
        $userInfo['medications'] = getUserMedications($userId);
        
        // Get blood sugar readings
        $userInfo['blood_sugar_readings'] = getBloodSugarReadings($userId);
        
        // Get recent activities
        $userInfo['activities'] = getUserActivities($userId);
        
        // Get login history
        $userInfo['login_history'] = getLoginHistory($userId);
        
        return $userInfo;
    } catch (Exception $e) {
        logError('getUserFullDetails', $e->getMessage());
        return null;
    }
}

function getUserMedications($userId) {
    global $conn;
    
    try {
        $query = "
            SELECT 
                medication_name,
                dosage,
                frequency,
                start_date,
                end_date,
                status
            FROM user_medications
            WHERE user_id = :user_id
            ORDER BY start_date DESC
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([':user_id' => $userId]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        logError('getUserMedications', $e->getMessage());
        return [];
    }
}

function getBloodSugarReadings($userId, $limit = 30) {
    global $conn;
    
    try {
        $query = "
            SELECT 
                reading_value,
                reading_time,
                reading_type,
                notes
            FROM blood_sugar_readings
            WHERE user_id = :user_id
            ORDER BY reading_time DESC
            LIMIT :limit
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([
            ':user_id' => $userId,
            ':limit' => $limit
        ]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        logError('getBloodSugarReadings', $e->getMessage());
        return [];
    }
}

function getUserActivities($userId, $limit = 20) {
    global $conn;
    
    try {
        $query = "
            SELECT 
                activity_type,
                description,
                created_at,
                ip_address
            FROM activity_log
            WHERE user_id = :user_id
            ORDER BY created_at DESC
            LIMIT :limit
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([
            ':user_id' => $userId,
            ':limit' => $limit
        ]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        logError('getUserActivities', $e->getMessage());
        return [];
    }
}

function getLoginHistory($userId, $limit = 10) {
    global $conn;
    
    try {
        $query = "
            SELECT 
                login_time,
                ip_address,
                user_agent,
                status
            FROM login_history
            WHERE user_id = :user_id
            ORDER BY login_time DESC
            LIMIT :limit
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([
            ':user_id' => $userId,
            ':limit' => $limit
        ]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        logError('getLoginHistory', $e->getMessage());
        return [];
    }
}

/**
 * Export Functions
 */
function exportUsersCSV($users) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="users_export_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // Add BOM for Excel UTF-8 compatibility
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // Headers
    fputcsv($output, [
        'Name',
        'Email',
        'Role',
        'Status',
        'Registration Date',
        'Last Login',
        'Phone',
        'Location'
    ]);
    
    // Data
    foreach ($users as $user) {
        fputcsv($output, [
            $user['name'],
            $user['email'],
            $user['role_name'],
            $user['status'],
            formatDate($user['created_at']),
            formatDate($user['last_login']),
            $user['phone'] ?? 'N/A',
            formatLocation($user)
        ]);
    }
    
    fclose($output);
    exit;
}

/**
 * Utility Functions 
 */
function formatLocation($user) {
    $location = [];
    if (!empty($user['city'])) $location[] = $user['city'];
    if (!empty($user['country'])) $location[] = $user['country'];
    
    return empty($location) ? 'N/A' : implode(', ', $location);
}

function formatDate($date) {
    return $date ? date('Y-m-d H:i:s', strtotime($date)) : 'N/A';
}

function generatePasswordResetToken($userId) {
    global $conn;
    
    try {
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));
        
        $query = "
            INSERT INTO password_reset_tokens (user_id, token, expiry)
            VALUES (:user_id, :token, :expiry)
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([
            ':user_id' => $userId,
            ':token' => $token,
            ':expiry' => $expiry
        ]);
        
        return $token;
    } catch (Exception $e) {
        logError('generatePasswordResetToken', $e->getMessage());
        return null;
    }
}

function getRoleBadgeClass($role) {
    $classes = [
        'super_admin' => 'role-badge super-admin',
        'admin' => 'role-badge admin',
        'moderator' => 'role-badge moderator',
        'provider' => 'role-badge provider',
        'user' => 'role-badge user'
    ];
    
    return $classes[$role] ?? 'role-badge user';
}

function getStatusBadgeClass($status) {
    $classes = [
        'active' => 'status-badge active',
        'inactive' => 'status-badge inactive',
        'pending' => 'status-badge pending'
    ];
    
    return $classes[$status] ?? 'status-badge inactive';
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Notification Functions
 */
function sendUserNotification($userId, $title, $message, $type = 'info') {
    global $conn;
    
    try {
        $query = "
            INSERT INTO user_notifications (user_id, title, message, type)
            VALUES (:user_id, :title, :message, :type)
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([
            ':user_id' => $userId,
            ':title' => $title,
            ':message' => $message,
            ':type' => $type
        ]);
        
        return true;
    } catch (Exception $e) {
        logError('sendUserNotification', $e->getMessage());
        return false;
    }
}

/**
 * Audit Trail Functions
 */
function logUserChange($userId, $changedBy, $changeType, $oldData, $newData) {
    global $conn;
    
    try {
        $query = "
            INSERT INTO user_change_log (
                user_id,
                changed_by,
                change_type,
                old_data,
                new_data,
                ip_address
            ) VALUES (
                :user_id,
                :changed_by,
                :change_type,
                :old_data,
                :new_data,
                :ip_address
            )
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([
            ':user_id' => $userId,
            ':changed_by' => $changedBy,
            ':change_type' => $changeType,
            ':old_data' => json_encode($oldData),
            ':new_data' => json_encode($newData),
            ':ip_address' => $_SERVER['REMOTE_ADDR']
        ]);
        
        return true;
    } catch (Exception $e) {
        logError('logUserChange', $e->getMessage());
        return false;
    }
}
?>