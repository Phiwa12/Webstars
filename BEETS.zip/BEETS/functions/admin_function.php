
<?php
// Role checking logic
    session_start();
    if ($_SESSION['role'] != 'admin') {
        header("Location: unauthorized.php");
        exit();
    }
    

require_once '../db/config.php';



function getAllUsers($limit = null, $offset = 0) {
    global $conn;
    try {
        // Only super admin can see other super admins
        $roleFilter = $_SESSION['role'] == 1 ? "" : "WHERE role > 1";
        
        $query = "SELECT u.*, 
                         CASE 
                             WHEN u.role = 1 THEN 'Super Admin'
                             WHEN u.role = 2 THEN 'Admin'
                             ELSE 'User'
                         END as role_name
                  FROM beets_users u
                  $roleFilter
                  ORDER BY u.created_at DESC";
        
        if ($limit !== null) {
            $query .= " LIMIT ?, ?";
        }

        $stmt = $conn->prepare($query);
        
        if ($limit !== null) {
            $stmt->bind_param("ii", $offset, $limit);
        }

        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        logError('getAllUsers', $e->getMessage());
        return [];
    }
}

function createUser($userData) {
    global $conn;
    try {
        $conn->begin_transaction();

        $stmt = $conn->prepare("
            INSERT INTO beets_users (fname, lname, email, password, role, status, created_at)
            VALUES (?, ?, ?, ?, ?, 'active', NOW())
        ");

        $stmt->bind_param("ssssi", 
            $userData['fname'],
            $userData['lname'],
            $userData['email'],
            password_hash($userData['password'], PASSWORD_DEFAULT),
            $userData['role']
        );

        $stmt->execute();
        $userId = $conn->insert_id;

        logAdminActivity("Created new user: {$userData['email']}");
        $conn->commit();
        
        return $userId;
    } catch (Exception $e) {
        $conn->rollback();
        logError('createUser', $e->getMessage());
        return false;
    }
}

function updateUser($userData) {
    global $conn;
    try {
        $conn->begin_transaction();

        $query = "UPDATE beets_users SET 
                    fname = ?,
                    lname = ?,
                    email = ?,
                    role = ?,
                    status = ?
                 WHERE user_id = ?";

        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssisi",
            $userData['fname'],
            $userData['lname'],
            $userData['email'],
            $userData['role'],
            $userData['status'],
            $userData['user_id']
        );

        $stmt->execute();
        logAdminActivity("Updated user: {$userData['email']}");
        $conn->commit();
        
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        logError('updateUser', $e->getMessage());
        return false;
    }
}

function deleteUser($userId) {
    global $conn;
    try {
        $conn->begin_transaction();

        // Check if user exists and get email for logging
        $stmt = $conn->prepare("SELECT email, role FROM beets_users WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if (!$user) {
            throw new Exception("User not found");
        }

        if ($user['role'] == 1) { // Super Admin
            throw new Exception("Cannot delete Super Admin");
        }

        // Delete user
        $stmt = $conn->prepare("DELETE FROM beets_users WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();

        logAdminActivity("Deleted user: {$user['email']}");
        $conn->commit();
        
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        logError('deleteUser', $e->getMessage());
        return false;
    }
}

/**
 * Activity Logging
 */
function logAdminActivity($description) {
    global $conn;
    try {
        $stmt = $conn->prepare("
            INSERT INTO admin_activity_log (admin_id, description, ip_address)
            VALUES (?, ?, ?)
        ");

        $stmt->bind_param("iss", 
            $_SESSION['user_id'],
            $description,
            $_SERVER['REMOTE_ADDR']
        );

        return $stmt->execute();
    } catch (Exception $e) {
        logError('logAdminActivity', $e->getMessage());
        return false;
    }
}

/**
 * Error Logging
 */
function logError($function, $message) {
    $logFile = __DIR__ . '/../logs/admin_errors.log';
    $timestamp = date('Y-m-d H:i:s');
    $userId = $_SESSION['user_id'] ?? 'not_logged_in';
    $logMessage = "[$timestamp] User: $userId, Function: $function, Error: $message\n";
    error_log($logMessage, 3, $logFile);
}

/**
 * Resource Management Functions
 */
function getAllResources() {
    global $conn;
    try {
        $query = "SELECT * FROM educational_resources ORDER BY created_at DESC";
        $result = $conn->query($query);
        return $result->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        logError('getAllResources', $e->getMessage());
        return [];
    }
}

function createResource($data) {
    global $conn;
    try {
        $stmt = $conn->prepare("
            INSERT INTO educational_resources (title, content, category, created_by)
            VALUES (?, ?, ?, ?)
        ");

        $stmt->bind_param("sssi", 
            $data['title'],
            $data['content'],
            $data['category'],
            $_SESSION['user_id']
        );

        if ($stmt->execute()) {
            logAdminActivity("Created new resource: {$data['title']}");
            return $conn->insert_id;
        }
        return false;
    } catch (Exception $e) {
        logError('createResource', $e->getMessage());
        return false;
    }
}

/**
 * Utility Functions
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function getAllRoles() {
    global $db; // Ensure $db is your database connection object
    $query = "SELECT id, name FROM roles"; // Replace 'roles' with your actual roles table name
    $result = mysqli_query($db, $query);

    $roles = [];
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $roles[] = $row;
        }
    }
    return $roles;
}

?>