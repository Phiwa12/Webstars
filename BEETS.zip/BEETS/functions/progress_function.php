<?php
function getInitialChartData() {
    global $conn;
    
    try {
        // Get weight data
        $weightQuery = "SELECT date, weight FROM progress_tracking 
                       WHERE weight IS NOT NULL 
                       ORDER BY date ASC";
        $weightStmt = $conn->query($weightQuery);
        $weightData = [
            'labels' => [],
            'weights' => []
        ];
        
        while ($row = $weightStmt->fetch(PDO::FETCH_ASSOC)) {
            $weightData['labels'][] = date('M j', strtotime($row['date']));
            $weightData['weights'][] = floatval($row['weight']);
        }
        
        // Get blood sugar data
        $sugarQuery = "SELECT date, blood_sugar FROM progress_tracking 
                      WHERE blood_sugar IS NOT NULL 
                      ORDER BY date ASC";
        $sugarStmt = $conn->query($sugarQuery);
        $bloodSugarData = [
            'labels' => [],
            'levels' => []
        ];
        
        while ($row = $sugarStmt->fetch(PDO::FETCH_ASSOC)) {
            $bloodSugarData['labels'][] = date('M j', strtotime($row['date']));
            $bloodSugarData['levels'][] = intval($row['blood_sugar']);
        }
        
        return json_encode([
            'weightData' => $weightData,
            'bloodSugarData' => $bloodSugarData
        ]);
        
    } catch (PDOException $e) {
        error_log("Error fetching chart data: " . $e->getMessage());
        return json_encode([
            'weightData' => ['labels' => [], 'weights' => []],
            'bloodSugarData' => ['labels' => [], 'levels' => []]
        ]);
    }
}

function validateProgressData($data) {
    $errors = [];
    
    if (empty($data['date'])) {
        $errors[] = "Date is required";
    }
    
    if (empty($data['weight']) && empty($data['bloodSugar'])) {
        $errors[] = "At least one measurement (weight or blood sugar) is required";
    }
    
    if (!empty($data['weight']) && (!is_numeric($data['weight']) || $data['weight'] <= 0)) {
        $errors[] = "Invalid weight value";
    }
    
    if (!empty($data['bloodSugar']) && (!is_numeric($data['bloodSugar']) || $data['bloodSugar'] <= 0)) {
        $errors[] = "Invalid blood sugar value";
    }
    
    return $errors;
}
?>