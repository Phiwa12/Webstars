<?php
require_once dirname(__DIR__) . '/db/config.php';

function checkUserAuth() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: loginbeets.php');
        exit();
    }
}

function getUserDashboardStats() {
    global $conn;
    
    // Initialize default stats
    $stats = [
        'blood_sugar' => [
            'latest' => '120',
            'time' => 'Today 8:00 AM',
            'weekly_avg' => '118',
            'trend' => '↓ 2%',
            'trend_class' => 'trend-down'
        ],
        'medication' => [
            'next_name' => 'Metformin',
            'next_time' => 'In 2 hours'
        ],
        'exercise' => [
            'completion' => '75'
        ]
    ];

    try {
        // Get latest blood sugar reading
        $stmt = $conn->prepare("
            SELECT blood_sugar_level, log_date 
            FROM progress_logs 
            WHERE user_id = ? 
            ORDER BY log_date DESC 
            LIMIT 1
        ");
        
        if ($stmt) {
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($row = $result->fetch_assoc()) {
                $stats['blood_sugar']['latest'] = number_format($row['blood_sugar_level'], 1);
                $stats['blood_sugar']['time'] = date('M j, g:i A', strtotime($row['log_date']));
            }
        }

        // Calculate weekly average
        $stmt = $conn->prepare("
            SELECT AVG(blood_sugar_level) as avg_level
            FROM progress_logs
            WHERE user_id = ? 
            AND log_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        ");
        
        if ($stmt) {
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($row = $result->fetch_assoc()) {
                $stats['blood_sugar']['weekly_avg'] = number_format($row['avg_level'] ?? 0, 1);
            }
        }

    } catch (Exception $e) {
        error_log("Error fetching dashboard stats: " . $e->getMessage());
    }

    return $stats;
}

function getUserActivities() {
    global $conn;
    
    $activities = [];
    
    try {
        $stmt = $conn->prepare("
            SELECT 'blood_sugar' as type, log_date as date, blood_sugar_level as value
            FROM progress_logs
            WHERE user_id = ?
            UNION ALL
            SELECT 'exercise' as type, created_at as date, NULL as value
            FROM exercise_routines
            WHERE user_id = ?
            ORDER BY date DESC
            LIMIT 5
        ");
        
        if ($stmt) {
            $stmt->bind_param("ii", $_SESSION['user_id'], $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            while ($row = $result->fetch_assoc()) {
                $activities[] = [
                    'icon' => getActivityIcon($row['type']),
                    'title' => formatActivityTitle($row['type'], $row['value']),
                    'time' => formatActivityTime($row['date'])
                ];
            }
        }
    } catch (Exception $e) {
        error_log("Error fetching user activities: " . $e->getMessage());
    }

    // If no activities found, return some default activities
    if (empty($activities)) {
        $activities = [
            [
                'icon' => 'fas fa-tachometer-alt',
                'title' => 'Logged blood sugar reading: 120 mg/dL',
                'time' => '2 hours ago'
            ],
            [
                'icon' => 'fas fa-running',
                'title' => 'Completed 30 min walking exercise',
                'time' => '4 hours ago'
            ],
            [
                'icon' => 'fas fa-pills',
                'title' => 'Took morning medication',
                'time' => 'Today 8:00 AM'
            ]
        ];
    }

    return $activities;
}

function getUserReminders() {
    global $conn;
    
    $reminders = [];
    
    try {
        $stmt = $conn->prepare("
            SELECT reminder_id as id, reminder_time as time, 'medication' as type
            FROM med_reminders
            WHERE user_id = ? AND reminder_time > NOW()
            ORDER BY reminder_time
            LIMIT 5
        ");
        
        if ($stmt) {
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            while ($row = $result->fetch_assoc()) {
                $reminders[] = [
                    'id' => $row['id'],
                    'time' => formatReminderTime($row['time']),
                    'title' => getReminderTitle($row['type']),
                    'type' => ucfirst($row['type'])
                ];
            }
        }
    } catch (Exception $e) {
        error_log("Error fetching user reminders: " . $e->getMessage());
    }

    // If no reminders found, return some default reminders
    if (empty($reminders)) {
        $reminders = [
            [
                'id' => 1,
                'time' => '09:00 AM',
                'title' => 'Take morning medication',
                'type' => 'Medication'
            ],
            [
                'id' => 2,
                'time' => '02:00 PM',
                'title' => 'Check blood sugar',
                'type' => 'Health Check'
            ],
            [
                'id' => 3,
                'time' => '06:00 PM',
                'title' => 'Evening walk',
                'type' => 'Exercise'
            ]
        ];
    }

    return $reminders;
}

// Helper functions
function getActivityIcon($type) {
    $icons = [
        'blood_sugar' => 'fas fa-tachometer-alt',
        'exercise' => 'fas fa-running',
        'medication' => 'fas fa-pills'
    ];
    return $icons[$type] ?? 'fas fa-check';
}

function formatActivityTitle($type, $value) {
    switch ($type) {
        case 'blood_sugar':
            return "Logged blood sugar reading: $value mg/dL";
        case 'exercise':
            return "Completed exercise routine";
        default:
            return "Completed activity";
    }
}

function formatActivityTime($timestamp) {
    $time = strtotime($timestamp);
    $now = time();
    $diff = $now - $time;
    
    if ($diff < 3600) {
        $mins = floor($diff / 60);
        return "$mins minutes ago";
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return "$hours hours ago";
    } else {
        return date('M j, g:i A', $time);
    }
}

function formatReminderTime($time) {
    return date('h:i A', strtotime($time));
}

function getReminderTitle($type) {
    $titles = [
        'medication' => 'Take medication',
        'health_check' => 'Check blood sugar',
        'exercise' => 'Exercise routine'
    ];
    return $titles[$type] ?? 'Reminder';
}