<?php
require_once '../db/database.php';
require_once '../utils/error_config.php';

// Blood Sugar Related Functions
function getLatestBloodSugar() {
    global $conn;
    try {
        $query = "SELECT blood_sugar, measured_at 
                 FROM blood_sugar_readings 
                 WHERE user_id = :user_id 
                 ORDER BY measured_at DESC 
                 LIMIT 1";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([':user_id' => $_SESSION['user_id']]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return [
            'value' => $result['blood_sugar'] ?? null,
            'time' => $result['measured_at'] ?? null,
            'formatted_time' => formatTimeAgo($result['measured_at'] ?? null)
        ];
    } catch (Exception $e) {
        logError('getLatestBloodSugar', $e->getMessage());
        return null;
    }
}

// Exercise Related Functions
function getExerciseStats($timeframe = 'week') {
    global $conn;
    try {
        $query = "SELECT 
                    COUNT(*) as total_exercises,
                    COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
                    ROUND(AVG(CASE WHEN status = 'completed' THEN duration END)) as avg_duration
                 FROM exercise_logs 
                 WHERE user_id = :user_id 
                 AND created_at >= DATE_SUB(NOW(), INTERVAL 1 $timeframe)";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([':user_id' => $_SESSION['user_id']]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $completion_rate = $result['total_exercises'] > 0 
            ? ($result['completed'] / $result['total_exercises']) * 100 
            : 0;
            
        return [
            'total' => $result['total_exercises'],
            'completed' => $result['completed'],
            'completion_rate' => round($completion_rate, 1),
            'avg_duration' => $result['avg_duration'] ?? 0
        ];
    } catch (Exception $e) {
        logError('getExerciseStats', $e->getMessage());
        return null;
    }
}

// Progress Tracking Functions
function getProgressStats($type = 'all') {
    global $conn;
    try {
        $stats = [];
        
        if ($type == 'all' || $type == 'weight') {
            $stats['weight'] = getWeightProgress();
        }
        
        if ($type == 'all' || $type == 'blood_sugar') {
            $stats['blood_sugar'] = getBloodSugarProgress();
        }
        
        if ($type == 'all' || $type == 'exercise') {
            $stats['exercise'] = getExerciseProgress();
        }
        
        return $stats;
    } catch (Exception $e) {
        logError('getProgressStats', $e->getMessage());
        return null;
    }
}

// Utility Functions
function formatTimeAgo($timestamp) {
    if (!$timestamp) return 'N/A';
    
    $difference = time() - strtotime($timestamp);
    
    if ($difference < 60) {
        return "Just now";
    } elseif ($difference < 3600) {
        return round($difference / 60) . " minutes ago";
    } elseif ($difference < 86400) {
        return round($difference / 3600) . " hours ago";
    } else {
        return round($difference / 86400) . " days ago";
    }
}

function calculateBMI($weight, $height) {
    if (!$weight || !$height) return null;
    $heightInMeters = $height / 100;
    return round($weight / ($heightInMeters * $heightInMeters), 1);
}

function getWeightProgress() {
    global $conn;
    try {
        $query = "SELECT weight, measured_at 
                 FROM weight_measurements 
                 WHERE user_id = :user_id 
                 ORDER BY measured_at DESC 
                 LIMIT 7";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([':user_id' => $_SESSION['user_id']]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        logError('getWeightProgress', $e->getMessage());
        return [];
    }
}

function getBloodSugarProgress() {
    global $conn;
    try {
        $query = "SELECT blood_sugar, measured_at 
                 FROM blood_sugar_readings 
                 WHERE user_id = :user_id 
                 ORDER BY measured_at DESC 
                 LIMIT 7";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([':user_id' => $_SESSION['user_id']]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        logError('getBloodSugarProgress', $e->getMessage());
        return [];
    }
}

function getExerciseProgress() {
    global $conn;
    try {
        $query = "SELECT 
                    DATE(created_at) as date,
                    COUNT(*) as total_exercises,
                    SUM(duration) as total_duration
                 FROM exercise_logs 
                 WHERE user_id = :user_id 
                 GROUP BY DATE(created_at)
                 ORDER BY date DESC 
                 LIMIT 7";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([':user_id' => $_SESSION['user_id']]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        logError('getExerciseProgress', $e->getMessage());
        return [];
    }
}

// Activity Logging Functions
function logUserActivity($type, $description) {
    global $conn;
    try {
        $query = "INSERT INTO user_activities (user_id, activity_type, description) 
                 VALUES (:user_id, :type, :description)";
        
        $stmt = $conn->prepare($query);
        return $stmt->execute([
            ':user_id' => $_SESSION['user_id'],
            ':type' => $type,
            ':description' => $description
        ]);
    } catch (Exception $e) {
        logError('logUserActivity', $e->getMessage());
        return false;
    }
}

// Reminder Functions
function getUserReminders($limit = 5) {
    global $conn;
    try {
        $query = "SELECT * FROM reminders 
                 WHERE user_id = :user_id 
                 AND reminder_time >= NOW()
                 AND status = 'pending'
                 ORDER BY reminder_time ASC 
                 LIMIT :limit";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([
            ':user_id' => $_SESSION['user_id'],
            ':limit' => $limit
        ]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        logError('getUserReminders', $e->getMessage());
        return [];
    }
}
?>