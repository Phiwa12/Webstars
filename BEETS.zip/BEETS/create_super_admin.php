<?php
// create_super_admin.php

// Include database configuration
require_once 'db/config.php';

// Super admin details
$superAdmin = [
    'fname' => 'Super',
    'lname' => 'Admin',
    'email' => 'superadmin@beets.com',
    'password' => 'SuperAdmin123!', // This will be hashed
    'role' => 1 // 1 for super admin
];

function createSuperAdmin($conn, $adminData) {
    try {
        // Check if super admin already exists
        $checkQuery = "SELECT user_id FROM beets_users WHERE email = ? OR role = 1";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bind_param("s", $adminData['email']);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($result->num_rows > 0) {
            return "Super admin already exists.";
        }

        // Hash the password
        $hashedPassword = password_hash($adminData['password'], PASSWORD_DEFAULT);

        // Prepare the insert statement
        $insertQuery = "INSERT INTO beets_users (fname, lname, email, password, role, created_at) 
                       VALUES (?, ?, ?, ?, ?, NOW())";
        
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("ssssi", 
            $adminData['fname'],
            $adminData['lname'],
            $adminData['email'],
            $hashedPassword,
            $adminData['role']
        );

        // Execute the statement
        if ($stmt->execute()) {
            return "Super admin created successfully! ID: " . $stmt->insert_id;
        } else {
            return "Error creating super admin: " . $stmt->error;
        }

    } catch (Exception $e) {
        return "Error: " . $e->getMessage();
    }
}

// Ensure the beets_users table has the required structure
$createTableSQL = "CREATE TABLE IF NOT EXISTS beets_users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    fname VARCHAR(50) NOT NULL,
    lname VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active'
)";

// Execute table creation/update
if ($conn->query($createTableSQL) === FALSE) {
    die("Error creating/updating table: " . $conn->error);
}

// Add role column if it doesn't exist
$checkRoleColumn = "SHOW COLUMNS FROM beets_users LIKE 'role'";
$result = $conn->query($checkRoleColumn);
if ($result->num_rows === 0) {
    $addRoleColumn = "ALTER TABLE beets_users ADD COLUMN role INT DEFAULT 0";
    if ($conn->query($addRoleColumn) === FALSE) {
        die("Error adding role column: " . $conn->error);
    }
}

// Create the super admin
$result = createSuperAdmin($conn, $superAdmin);
echo $result;

// Close connection
$conn->close();
?>